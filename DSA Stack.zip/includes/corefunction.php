<?php
session_start();
error_reporting(1); 

$today = date('Y-m-d H:i:s');
include_once("define.php");  

// if(!isset($_SESSION['user_id'])) {
//     $user_id = 0;
//     $user_type = 0; 
// }
// else {
//     $user_id = $_SESSION['user_id'];
// 	$user_type = $_SESSION['user_type'];
// }
$calc = $_GET['calc'];

if($calc == 'getcallbackuser') {
    $input_array = array();
    $input_array['mobileno'] = $_POST['mobileno'];
    $input_array['source_from']=$_POST['source_from'];
    $json_encoded_array = json_encode($input_array,true);

    $url = API_URL.'workflow/browsing.php?call=getcallbackuser';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    $_SESSION['mobile_no'] = $_POST['mobileno'];
    echo json_encode($output,true);
    return false;
}
else if($calc == 'generate_documentclist1')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=generate_documentclist1';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'mob_verify')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'gsk-integration/gsk_integration.php?call=mob_verify';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'create_netbankurl') { 
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=create_netbankurl';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if($calc=='getloantypeusecate') {
    $input_array = array();
    $input_array['categoryid'] = $_POST['category_id'];
   
    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'meeseva/meeseva.php?call=getloantypeusecate';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'update_bankstatedet') { 
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=update_bankstatedet';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if($calc == 'check_docupload')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=check_docupload';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'get_documentcklistquick')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=get_documentcklist';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='get_applicantname1') {

    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'gsk-integration/gsk_integration.php?call=get_applicantname1';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'sendto_bank')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=sendto_bank';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'insert_quickpersonalnew1')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=insert_quickpersonalnew1';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'insert_quickbasicnew1')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=insert_quickbasicnew1_part';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='send_otp_quickapp')
{
    $mobile_number = $_POST['mobile'];  
    $otp = mt_rand(10000, 99999); 
    
    $message = $otp." is your OTP for Mobile Verification at Loanwiser.";
    $otpStatus = SendMsgCons($mobile_number, $message,$otp);
    $json_verify = json_decode($otpStatus,true); 
    // $json_verify['type'] = 'success';
    if($json_verify['type'] == 'success'){
        $allresult = 1;
    }
    else{
        $allresult = 2;
    }
    echo $allresult;
}
else if($calc == 'quickapp_signin')
{
    
    $mobileno = $_POST["mobileno"];
    $otp_entered = $_POST["otp"];
    $json_verify = verifyOtp($mobileno, $otp_entered); //need to uncomment
    $json_verify1 = json_decode($json_verify,true); //need to uncomment
    //  $json_verify1['type'] = 'success';
    if($json_verify1['type'] == 'success'){
        $json_encoded_array = json_encode($_POST,true);
        $url = API_URL.'workflow/workflow.php?call=create_quickapply_partner'; 
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        $output = json_decode($response->body,true);
        $_SESSION['user_id'] = $output['user_id'];
        $output['user_id'] = my_simple_crypt( $output["user_id"], 'e' );;
        echo json_encode($output,true);
        return false;
    }
    else{
        echo 2;
    }
}
else if ($calc == 'sendOtplogin') {
    
    $mobile_number = $_POST['mobile_number'];   
    $partnertype = $_POST['partnertype'];   
    $otp = mt_rand(10000, 99999);
    $input_array = [
        'mobile_no' => $mobile_number,
        'partnertype' => $partnertype,
        'email_id' => $_POST['mail']
    ];
    $json_encoded_array = json_encode($input_array);
        
    $url = API_URL.'workflow/partner.php?call=alreadycheckpartner';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();

        $output = json_decode($response->body,true);
        
       if($output==0){
            $message = $otp." is your OTP for Loanwiser Partner Verification Process.";
            $otpStatus = SendMsg($mobile_number, $message,$otp);
            $json_verify = json_decode($otpStatus,true); 
            // $json_verify['type']="success";
            if($json_verify['type'] == 'success'){
                $allresult = 1;
                
            }else{
              $allresult = 2;
          }
       } else {
           $allresult = 3;
       }
  echo $allresult;
}
else if ($calc == 'confirmlogin_otp') {
    $mobile_number = $_POST['mobile_number'];
    $partnertype = $_POST['partnertype'];
    $otp_entered = $_POST['login_otp_entered'];
    $json_verify = verifyOtp($mobile_number, $otp_entered);
    $json_verify1 = json_decode($json_verify,true);
    // $json_verify1['type'] = 'success';
    if($json_verify1['type'] == 'success'){
        $input_array = [
            'mobile_no' => $mobile_number,
            'source_name' => $partnertype
        ];
        $json_encoded_array = json_encode($input_array);
        $url = API_URL.'workflow/partner.php?call=login_partner';
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = $response->body;
        $result1 = json_decode($result,true);
        // $_SESSION["b2b_userid"]=$result1["id"];
        $result1["b2b_hash"]=my_simple_crypt($result1['id'],'e');
        
        echo json_encode($result1,true);
        return false;
    }
    else{
      echo 0;
    }
}
else if($calc=='SendRegOTP') {
    // print_r($_POST);
    //     return false;
    $mobile_number = $_POST['mob_number'];
    // $mobile_number = "8220402007";
    $username = $_POST['username'];
    $otp = mt_rand(10000, 99999);
        $input_array = [
            'mobile_no' => $_POST['mob_number'],
            'kiosk_name' => $_POST['username'],
            'contact_person' => $_POST['username'],
            'email_id' => $_POST['email'],
            'source_name' => $_POST['partnertype'],
            'state_id' => $_POST['statename'],
            'district_id' => $_POST['cityname'],
            'service_offered' => $_POST['courses_offered'],
            'profile_address' => $_POST['address'],
            'business_name' => $_POST['bussiness'],
            'office_address' => $_POST['address'],
            'avg_fees' => $_POST['avg_fees'],
            'pincode' => $_POST['pincode'],
            'verify_by' => 1,
            'mail_verify' => 0
        ];
        $json_encoded_array = json_encode($input_array);
        
         $url = API_URL.'workflow/partner.php?call=alreadycheckpartner';
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = json_decode($response->body);
        
        if($result != 0)
        {
             $message = $otp." is your OTP for Loanwiser Partner Verification Process.";
            $otpStatus = SendMsg($mobile_number, $message,$otp);
            $json_verify = json_decode($otpStatus,true); 
            // $json_verify['type']="success";
            if($json_verify['type'] == 'success'){
                $allresult = 1;
                
            }else{
              $allresult = 2;
          }
          echo $allresult;
          return false;
        }
        else
        {
           echo "fail";
           return false;
        }
    
}
else if($calc=='sendMailVerpartner') {
    // print_r($_POST);
    // return false;
     $mobile_number = $_POST['mob_number'];
    //  $mobile_number = "8220402007";
    $partnertype = $_POST['partnertype'];
    $otp_entered = $_POST['otp'];
    $json_verify = verifyOtp($mobile_number, $otp_entered);
    $json_verify1 = json_decode($json_verify,true);
    // $json_verify1['type'] = 'success';
    if($json_verify1['type'] == 'success'){
    $input_array = [
            'mobile_no' => $_POST['mob_number'],
            'kiosk_name' => $_POST['username'],
            'contact_person' => $_POST['username'],
            'email_id' => $_POST['email'],
            'source_name' => $_POST['partnertype'],
            'state_id' => $_POST['statename'],
            'district_id' => $_POST['cityname'],
            'service_offered' => $_POST['courses_offered'],
            'profile_address' => $_POST['address'],
            'business_name' => $_POST['bussiness'],
            'office_address' => $_POST['address'],
            'avg_fees' => $_POST['avg_fees'],
            'pincode' => $_POST['pincode'],
            'camp_id' => $_POST['camp_id'],
            'i_agree' => $_POST['i_agree'],
            'verify_by' => 1,
            'mail_verify' => 0
        ];
        $json_encoded_array = json_encode($input_array);
        $url = API_URL.'workflow/partner.php?call=createapplication';
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = json_decode($response->body, true);
        
        // echo $response->body;
        // return false;
        // $_SESSION["b2b_userid"]=$result['id'];
        $b2b_hash = my_simple_crypt($result['id'], 'e' );
        $mail_array=[
         'b2b_id' =>$b2b_hash,
         'email' =>$input_array["email_id"],
         'mobile' =>$_POST['mob_number'],
         'partner_code' =>$result["data"]["source_from"],
         'profile_address' =>$result["data"]["profile_address"],
         'state_name' =>$result["data"]["state_name"],
         'district_name' =>$result["data"]["district_name"],
         'source_name' =>$result["data"]["source_name"],
         'company_name' =>$result["data"]["business_name"],
         'pincode' =>$result["data"]["pincode"],
         'name' => $_POST['username'],
         'send_mail' => 'reg'
     ];
     
     $json_encoded_array1 = json_encode($mail_array);
     $url1 = BASE_URL.'includes/mail_verify.php';
    //  echo $url1;
    // return false;
     $response = \Httpful\Request::post($url1)
     ->sendsJson()
     ->body($json_encoded_array1)
     ->send();
     
     $result = $response->body;
    echo $b2b_hash;
    return false;
        }
        else
        {
           echo "fail";
           return false;
        }
    
}
else if($calc=='reset_mail_send') {
    // print_r($_POST);
    //     return false;
    // $mobile_number = $_POST['mob_number'];
    // $username = $_POST['username'];
    // $email = $_POST['email'];
    // $partnertype = $_POST['partnertype'];
    // $statename = $_POST['statename'];
    // $acityname = $_POST['acityname'];
    // $inst_address = $_POST['inst_address'];
    // $courses = $_POST['courses'];
    // $avg_fees = $_POST['avg_fees'];
    

        $input_array = [
            'email_id' => $_POST['emailId'],
        ];
        $json_encoded_array = json_encode($input_array);
        
         $url = API_URL.'workflow/partner.php?call=alreadycheckpartnerbymail';
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = json_decode($response->body,true);
        // print_r($result);
        // return false;
        if($result["result"] != 1)
        {
        
        // echo $response->body;
        // return false;
        // $_SESSION["b2b_userid"]=$result['id'];
        $b2b_hash = my_simple_crypt($result["data"]['id'], 'e' );
        $mail_array=[
         'b2b_id' =>$b2b_hash,
         'email' =>$input_array["email_id"],
         'mobile' =>$result["data"]["mobile_no"],
         'partner_code' =>$result["data"]["source_from"],
         'name' => $result["data"]["kiosk_name"],
         'send_mail' => 'reset'
     ];
     
     $json_encoded_array1 = json_encode($mail_array);
     $url1 = BASE_URL.'includes/mail_verify.php';
    //  echo $url1;
    // return false;
     $response = \Httpful\Request::post($url1)
     ->sendsJson()
     ->body($json_encoded_array1)
     ->send();
     $result = $response->body;
    echo $result;
    return false;
        }
        else
        {
           echo "fail";
           return false;
        }
    
}
else if($calc=='loginusing_mail') {
    // print_r($_POST);
    //     return false;
    
    $email = $_POST['email'];
    
    $password = $_POST['password'];

        $input_array = [
            
            'email_id' => $email,
            'password' => $password
        ];
        $json_encoded_array = json_encode($input_array);
        // echo $json_encoded_array;
        // return false;
         $url = API_URL.'workflow/partner.php?call=loginusing_mail';
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = $response->body;
        $result1 = json_decode($response->body,true);
        if($result1['valid'] == '1')
        {
        // $_SESSION["b2b_userid"]=$result1['b2b_id'];
        $result1["b2b_hash"]=my_simple_crypt($result1['b2b_id'],'e');
        // $result1["b2b_hash"]=my_simple_crypt(53418,'e');
        }
    echo json_encode($result1,true);
    return false;
        // echo $result;
        // return false;
        
        
}
//for ASK
else if ($calc == 'getAsklist') {
    // $input_array = $_POST;
    // print_r($_POST);
    $json_encoded_array = json_encode($_POST, true);
    
    $url = API_URL . 'individual-partner/gsk_integration.php?call=getAsklist';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    echo $response->body;
    return false;
}
else if ($calc == 'password_update') {
    // $input_array = $_POST;
    // print_r($_POST);
    $json_encoded_array = json_encode($_POST, true);
    
    $url = API_URL . 'workflow/partner.php?call=password_update';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    echo $response->body;
    return false;
}
else if ($calc == 'ask_submit_loanw') {
    // $input_array = $_POST;
    // print_r($_POST);
    $json_encoded_array = json_encode($_POST, true);
    
    $url = API_URL . 'individual-partner/gsk_integration.php?call=ask_submit_loanw';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    echo $response->body;
    return false;
}
else if ($calc == 'ask_docfetch') {
    // $input_array = $_POST;
    // print_r($_POST);
    $json_encoded_array = json_encode($_POST, true);
    
    $url = API_URL . 'individual-partner/gsk_integration.php?call=ask_docfetch';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    echo $response->body;
    return false;
}
else if ($calc == 'ask_countdisp') {
    // $input_array = $_POST;
    // print_r($_POST);
    $json_encoded_array = json_encode($_POST, true);
    
    $url = API_URL . 'individual-partner/gsk_integration.php?call=ask_countdisp';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    echo $response->body;
    return false;
}
    // for NewSysytem
else if($calc=='generate_token')
{
    
    $input_array["order_id"] = $_POST["order_id"];
    $json_encoded_array = json_encode($input_array, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=get_paymentamount';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
  
    $PAY_appId = $_POST["appId"]; 
    $PAY_secretKey = "dacdf5b91cce43d5b0d9631379d73d1fde43de87";
    $PAY_orderId = $_POST["order_id"];
    $PAY_orderAmount = $output[0]["total_amount"];
    $PAY_returnUrl = $_POST["returnUrl"];; 
    $PAY_paymentModes = ""; //keep it blank to display all supported modes
    $PAY_tokenData = "appId=".$PAY_appId."&orderId=".$PAY_orderId."&orderAmount=".$PAY_orderAmount."&returnUrl=".$PAY_returnUrl."&paymentModes=".$PAY_paymentModes;
    $PAY_token = hash_hmac('sha256', $PAY_tokenData, $PAY_secretKey, true);
    $PAY_paymentToken = base64_encode($PAY_token); 
    $arr["order_amt"]=$PAY_orderAmount;
    $arr["payment_token"]=$PAY_paymentToken;
    echo json_encode($arr,true);
    return false;
}
else if($calc=='lead_creation')
{
    
        // print_r($_POST);
        // return false;
        $mobile_number = $_POST['info_mobile'];  
        $otp = mt_rand(10000, 99999); 
        $_SESSION['last_otp'] = $otp;
        $_SESSION['last_mobile_number'] = $_POST['info_mobile'];
        
        $message = $otp . " is your OTP for Mobile Verification at GSK.";
       

            $otpStatus = SendMsg($mobile_number, $message,$otp);
             $json_verify = json_decode($otpStatus,true); 
            // $json_verify['type'] = 'success';
              if($json_verify['type'] == 'success'){
                        $allresult = 1;
                       
              }else{
                  $allresult = 2;
              }
           
            echo $allresult;
}
else if ($calc == 'upload_legaldocumentnew') {
    $input_array = array();
    $file_name = str_replace("'",'',$_FILES["doc_file"]["name"]);
    $image = $_FILES["doc_file"]["name"];
    $target_dir = "../../emitra_doc/";
    $target_file = $target_dir . basename(str_replace("'",'',$_FILES["doc_file"]["name"]));
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $hashvalue = md5($data);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo(str_replace("'",'',$_FILES["doc_file"]["name"]), PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $dbfilename = $target_dir.$finalfilename; 
    
    $input_array["legal_id"] = $_POST["legal_id"];
    $input_array["file_name"] = $file_name;
    $input_array["imageFileType"] = $imageFileType;
    $input_array["finalfilename"] = $finalfilename;
    $input_array["hashvalue"] = $hashvalue;
    $input_array["file_upload"] = 0;
    if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename)){
        $input_array["file_upload"]=1;
    }
    $json_encoded_array = json_encode($input_array, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=upload_legaldocumentnew';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'upload_legaldocument') {
    $input_array = array();
    $file_name = str_replace("'",'',$_FILES["doc_file"]["name"]);
    $image = $_FILES["doc_file"]["name"];
    $target_dir = "../../emitra_doc/";
    $target_file = $target_dir . basename(str_replace("'",'',$_FILES["doc_file"]["name"]));
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $hashvalue = md5($data);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo(str_replace("'",'',$_FILES["doc_file"]["name"]), PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $dbfilename = $target_dir.$finalfilename; 
    
    $input_array["legal_id"] = $_POST["legal_id"];
    $input_array["file_name"] = $file_name;
    $input_array["imageFileType"] = $imageFileType;
    $input_array["finalfilename"] = $finalfilename;
    $input_array["hashvalue"] = $hashvalue;
    $input_array["file_upload"] = 0;
    if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename)){
        $input_array["file_upload"]=1;
    }
    $json_encoded_array = json_encode($input_array, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=upload_legaldocument';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'family_detailsinscrif') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=insert_familycrif';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output);
    return false;
}
else if ($calc == 'update_status') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=update_status';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output);
    return false;
}
else if ($calc == 'family_detailsinselig') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=insert_familyelig';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output);
    return false;
}
else if ($calc == 'family_detailsins') {
    if($_POST['office_setup'] == "1" or $_POST['office_setup'] == "3")
    {
         
        $_POST['work_pincode'] = $_POST['res_pincode'];
        $_POST['ofc_area'] = $_POST['per_area'];
    }
    if($_POST['loan_category'] == "3")
    {
         $from = new DateTime($_POST['member_dob']);	
    $to   = new DateTime('today');	
    $age =  $from->diff($to)->y;	
    $_POST["age"] = $age;
    } 
    
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=insert_family';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output);
    return false;
}
else if ($calc == 'Fetch_Loanchecklist') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=Fetch_Loanchecklist';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'delete_document') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=delete_document';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'get_legaldoclist') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=get_legaldoclist';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'leads_display') {
    $json_encoded_array = json_encode($_POST, true);
    // echo $json_encoded_array;
    // return false;
    $url = API_URL . 'individual-partner/gsk_integration.php?call=leads_display';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    // echo $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}

else if ($calc == 'leads_displayGsk') {
    
    $json_encoded_array = json_encode($_POST, true);
    // echo $json_encoded_array;
    // return false;
    $url = API_URL . 'individual-partner/gsk_integration.php?call=leads_displayGsk';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    // echo $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'leads_displayExport') {
    
    $json_encoded_array = json_encode($_POST, true);
    // echo $json_encoded_array;
    // return false;
    $url = API_URL . 'individual-partner/gsk_integration.php?call=leads_displayExport';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    // echo $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'partner_leads_display') {
    
    $json_encoded_array = json_encode($_POST, true);
    // echo $json_encoded_array;
    // return false;
    $url = API_URL . 'individual-partner/gsk_integration.php?call=partner_leads_display';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    // echo $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'payment_intialized') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/gsk_integration.php?call=payment_initialize';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    // echo $response->body;
    $output = json_decode($output,true); 
    echo json_encode($output,true);
    return false;
}
else if($calc=='eligibilitysave'){
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=eligibilitysave';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='viabilitysave'){
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=viabilitysave';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
	else if ($calc == 'vh_brand') {	
    $input_array = array();	
    $input_array['term'] = $_REQUEST['term'];	
    $json_encoded_array = json_encode($input_array, true);	
    $url = API_URL . 'individual-partner/gsk_integration.php?call=vh_brand';	
    $response = \Httpful\Request::post($url)	
    ->sendsJson()	
    ->body($json_encoded_array)	
    ->send();	
    $businessList = json_decode($response->body, true);	
    $cList = array();	
    foreach ($businessList as $key => $company) {	
        $a = ['id' => $company['id'], 'label' => $company['maker_name'], 'value' => $company['maker_name']];	
        array_push($cList, $a);	
    }	
    $json_encoded_array = json_encode($cList, true);	
    print_r($json_encoded_array);	
    return false;	
   	
}	
else if ($calc == 'vh_modal') {	
    $input_array = array();	
    $input_array['term'] = $_REQUEST['term'];	
    $input_array['vh_make_id'] = $_REQUEST['vh_make_id'];	
    $json_encoded_array = json_encode($input_array, true);	
    $url = API_URL . 'individual-partner/gsk_integration.php?call=vh_modal';	
    $response = \Httpful\Request::post($url)	
    ->sendsJson()	
    ->body($json_encoded_array)	
    ->send();	
    $businessList = json_decode($response->body, true);	
    $json_encoded_array = json_encode($businessList, true);	
    print_r($json_encoded_array);	
    return false;	
   	
}
else if($calc=='viability_check')
{
    // print_r($_POST);
    // return false;
    $input_array = array();
    if($_POST['loan_category']==2){
        $stat_arr = [$_POST['employment_type']];
        $applicant_value = 1;
    }
    else if($_POST['loan_category']==1)
    {
        $property_fields['prop_identified'] = 1;

        if($_POST['is_coapp'] == '1')
        {
            $stat_arr = [$_POST['employment_type'],$_POST['employment_type2']];
        }
        else
        {
           $stat_arr = [$_POST['employment_type']]; 
        }
        
        $applicant_value = 1;
            if($_POST['loan_type'] == '1')
            {
               $property_fields['prop_identified'] = $_POST['property_identify']; 
            }
        $property_fields['prop_title'] = $_POST['property_title'];
        $property_fields['prop_cattype'] = $_POST['property_category'];
        $property_fields['prop_type'] = $_POST['property_type'];
        $property_fields['land_approval'] = $_POST['land_approval'];
        $property_fields['building_approval'] = $_POST['building_approval'];
        $property_fields['da_approved'] = $_POST['da_approved'];
        $property_fields['pincode'] = $_POST['prop_pincode'];
        $input_array['property_fields'] = $property_fields;
    }
    
    
    $input_array['employment_type']=$_POST['employment_type'];
    $language_obj = str_replace('"',"'",json_encode($stat_arr,true));
    
    $InputArray = GetFamilyDet($input_array,$language_obj); //Build Array
    
    
     $json_encoded_array = json_encode($InputArray, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=viabilitystep';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $jsonarray = json_encode($bclist, true);
        echo $jsonarray;
        return false;
    
}

else if($calc=='eligibility_check')
{
    $input_array = array();
    if($_POST['loan_category']==2){
        $stat_arr = [$_POST['employment_type']];
        $applicant_value = 1;
    } 
    else if($_POST['loan_category']==1)
    {
        if($_POST['is_coapp'] == '1')
        {
            $stat_arr = [$_POST['employment_type'],$_POST['employment_type2']];
        }
        else
        {
           $stat_arr = [$_POST['employment_type']]; 
        }
        
        $applicant_value = 1;
        $property_fields['prop_size'] = $_POST['property_size'];
        $property_fields['purpose_of'] = $_POST['property_purpose'];
        $property_fields['transaction_type'] = $_POST['transaction_type'];
        $property_fields['property_status'] = $_POST['property_status'];
        $property_fields['construction_status'] = $_POST['construction_status'];
        $property_fields['propety_ownership'] = $_POST['property_ownership'];
        $property_fields['completion_date'] = $_POST['proposed_completion'];
        $property_fields['plot_area'] = $_POST['plot_area'];
        $property_fields['built_up_area'] = $_POST['builtup_area'];
        $property_fields['carpet_area'] = $_POST['carpet_area'];
        $property_fields['property_value'] = $_POST['property_price'];
        $property_fields['age_of_property'] = $_POST['property_age'];
        $property_fields['cost_of_land'] = $_POST['plot_value'];
        $property_fields['completion_date'] = $_POST['completion_date'];
        $property_fields['cost_of_construction'] = $_POST['cost_of_construction'];
        $property_fields['exit_bank_name'] = $_POST['existing_bank'];
        $property_fields['exist_loan_varient'] = $_POST['exist_loan_varient'];
        $property_fields['original_loan_amount'] = $_POST['original_loan_amount'];
        $property_fields['original_tenure'] = $_POST['original_tenure'];
        $property_fields['remaining_tenure'] = $_POST['remaining_tenure'];
        $property_fields['interest_rate'] = $_POST['interest_rate'];
        
        $input_array['property_fields'] = $property_fields;
    }
    
    
    foreach($_POST["other_from"] as $other_incomekey => $otherincomeval){
        $other_incomearr = [];
        foreach($otherincomeval as $otherincomesinkey => $otherincomesinval){
            $ntemp = array();
            $ntemp['income_type'] = $_POST['other_from'][$other_incomekey][$otherincomesinkey];
            $ntemp['reflected_itr'] = $_POST['other_reflected'][$other_incomekey][$otherincomesinkey];
            $ntemp['income_amount'] = str_replace(',', '', $_POST['other_amount'][$other_incomekey][$otherincomesinkey]);
            array_push($other_incomearr,$ntemp);
        }
        $input_array["other_incomearr"][$other_incomekey]=$other_incomearr;
    }
    // foreach($_POST["outgoing_EMI"] as $other_emikey => $otheremival){
    //     $other_emiarr = [];
    //     foreach($otheremival as $otheremisinkey => $otheremisinval){
    //         $ntemp = array();
    //         $ntemp['loan_type'] = $_POST['other_from'][$other_emikey][$otheremisinkey];
    //         $ntemp['emi_amount'] = $_POST['other_reflected'][$other_emikey][$otheremisinkey];
    //         $ntemp['remaining_tenor'] = str_replace(',', '', $_POST['other_amount'][$other_emikey][$otheremisinkey]);
    //         array_push($other_incomearr,$ntemp);
    //     }
    //     $input_array["other_incomearr"][$other_emikey]=$other_incomearr;
    // }
    // $jsonarray = json_encode($input_array, true);
    //     echo $jsonarray;
    //     return false;
    $language_obj = str_replace('"',"'",json_encode($stat_arr,true));
    
   
    
    $input_array['form_data'] = $_POST;
    
     $InputArray = GetFamilyDetEligible($input_array,$language_obj); //Build Array
    
    $json_encoded_array = json_encode($InputArray, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=eligibilitystep';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $jsonarray = json_encode($bclist, true);
        echo $jsonarray;
        return false;
}
else if ($calc == 'comname') { //#1708 company name 
    $input_array = array();
    $input_array['bank_id'] = 2;
    $input_array['term'] = $_REQUEST['term'];

    $json_encoded_array = json_encode($input_array, true);

    $url = API_URL . 'individual-partner/process_functions.php?call=getCompanyList';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $companyList = json_decode($response->body, true);

    $cList = array();
    foreach ($companyList as $key => $company) {
        $a = ['id' => $company['id'], 'label' => $company['company_code'], 'value' => $company['company_code']];
        array_push($cList, $a);
    }

    $json_encoded_array = json_encode($cList, true);

    print_r($json_encoded_array);
    return false;
} 

else if ($calc == 'busname') { //#NM Finance Business name 
    $input_array = array();
    $input_array['term'] = $_REQUEST['term'];

    $json_encoded_array = json_encode($input_array, true);

    $url = API_URL . 'individual-partner/process_functions.php?call=getBusinessList';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $businessList = json_decode($response->body, true);

    $cList = array();
    foreach ($businessList as $key => $company) {
        $a = ['id' => $company['id'], 'label' => $company['business_name'], 'value' => $company['business_name']];
        array_push($cList, $a);
    }

    $json_encoded_array = json_encode($cList, true);

    print_r($json_encoded_array);
    return false;
} 

else if ($calc == 'generate_doccklist') {
    
     
      if($_POST['employment_type'] == '1')
      {
          $income_proof = $_POST['income_proof'][0];
      }
      else
      {
         $income_proof = $_POST['bus_income_proof'][0]; 
      }
      $income_proof = str_replace('"',"'",json_encode($income_proof,true));
      $income_proof = str_replace('[','(',$income_proof);
      $income_proof = str_replace(']',')',$income_proof);
    
     if($_POST['bus_employment_type'][0] == '1')
     {
         $vocation_type = '('.$_POST['ind_vocation'][0].')';
     }
     else if($_POST['bus_employment_type'][0] == '2')
     {
         $vocation_type = str_replace('"',"'",json_encode($_POST['work_vocation'][0],true));
         $vocation_type = str_replace('[','(',$vocation_type);
         $vocation_type = str_replace(']',')',$vocation_type);
     }
     else if($_POST['bus_employment_type'][0] == '3')
     {
         $vocation_type = '('.$_POST['bus_vocation'][0].')';
     }
    
       $input_array['employement_type'] = $_POST['employment_type'];
       $input_array['applicant_type'] = 1;
       $input_array['panno'] = $_POST['has_pan'];
       $input_array['residence_type'] = $_POST['res_type'][0];
       $input_array['salary_creditmethod'] = $_POST['salary_mode'][0];
       $input_array['epfdeducted'] = $_POST['is_epf_deduct'][0];
       $input_array['curentcomapantexp'] = $_POST['work_experiance'][0];
       $input_array['oustandingloan'] = $_POST['oustanding_loan'][0];
       $input_array['incomeproof'] = $income_proof;
       $input_array['vocationtype'] = $vocation_type;
       $input_array['businesstype'] = $_POST['bus_employment_type'][0];
       $input_array['office_ownership'] = $_POST['office_res'][0];
       $input_array['from_step3'] = $_POST['from_step3'];
       $input_array['transaction_id'] = $_POST['transaction_id'];
       $input_array['salary'] = $_POST['net_salary'][0];
       
    
        $json_encoded_array = json_encode($input_array, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=generate_doccklist';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);
    //   echo $responsessss;
        print_r($json_array);
    return false;
}

else if ($calc == 'eligible_banklist') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=eligible_banklist';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
    $bclist = json_decode($response->body, true);
    $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
} 
else if ($calc == 'checklist_click') {
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=update_enable';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
} 
else if ($calc == 'document_list') {
    // print_r($_POST);
    // return false;
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=get_documentcklist';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      if($_POST['status_flag'] == '1')
      {
            $input_arrays['subtask_id'] = $_POST['sub_id'];
            $input_arrays['user_id'] = $_POST['user_id'];
            $input_arrays['b2b_userid'] = $_POST['b2b_userid'];
            $input_arrays['transaction_id'] = $_POST['transaction_id'];
            $input_arrays['compstatus'] = 2;
            $input_arrays['from_gsk'] = "1";
            $json_encoded_arrays = json_encode($input_arrays,true);
              
            $urls = API_URL.'workflow/workflow.php?call=subtaskcomplete';
             $responsessss = \Httpful\Request::post($urls)
                ->sendsJson()
                ->body($json_encoded_arrays)
                ->send();
      }
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
} 
else if ($calc == 'credit_report') {
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=cibil_report';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
} 
else if($calc == 'credit_request') {
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=credit_request';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
}
else if($calc == 'Crif_reportCompletion') {
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=upd_cibilstatus';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
}
else if($calc == 'viableError') {
    $_POST['is_viable'] = 1;
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=viable_errormessage';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
}

else if($calc == 'DeleteReport') {
    
    unlink('../'.$_POST['filepath']);
    print_r($_POST);
    return false;
}
else if($calc == 'DownloadViable') {
    if($_POST['flag'] == '1')
    {
        $input['name'] = "viable_cnt";
    }
    else
    {
        $input['name'] = "crif_cnt";
    }
    if($_POST['count'] == '')
    {
        $_POST['count'] = 0;
    }
    $input['count'] = $_POST['count']+1;
    $input['transaction_id'] = $_POST['transaction_id'];
    $input['userName'] = $_POST['userName'];
    $input['mobile'] = $_POST['mobile'];
    $json_array = json_encode($input, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=report_count';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_array)
    ->send();
    
    // $json_encoded_array = json_encode($_POST, true);
    //  $url = BASE_URL . '/pdf-generation.php';
    // $response = \Httpful\Request::post($url)
    // ->sendsJson()
    // ->body($json_encoded_array)
    // ->send();
  
    // // $bclist = json_decode($response, true);
    // // $bclist = json_encode($bclist, true);
    echo $response;
    return false;
}

else if($calc == 'payment_schedule') {
    $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=payment_schedule';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = $response->body;
        print_r($bclist);
        return false;
}
else if($calc == 'delete_applicant') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=delete_applicant';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $bclist = $response->body;
    echo $bclist;
    return false;
}
else if($calc == 'get_familydetails') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=get_familydetails';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $bclist = $response->body;
    echo $bclist;
    return false;
}
else if($calc == 'get_familydetails1') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=get_familydetails1';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $bclist = $response->body;
    echo $bclist;
    return false;
}
else if($calc == 'get_familydetails2') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=get_familydetails2';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $bclist = $response->body;
    echo $bclist;
    return false;
}
else if($calc == 'update_appcount') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=update_appcount';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $bclist = $response->body;
    echo $bclist;
    return false;
}
else if($calc == 'getpayment_list') {
    $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=get_payschedule';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = $response->body;
        print_r($bclist);
        return false;
}
else if($calc == 'doc_uploadsubmit') {
    $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=doc_uploadsubmit';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        $bclist = $response->body;
        
        print_r($bclist);
        return false;
}
else if($calc == 'doc_paycomplete') {
    // print_r($_POST);
    // return false;
         $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=doc_paycomplete';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = $response->body;

        $json_encoded_array = json_encode($bclist,true);
        print_r($json_encoded_array);
        return false;
          
        
}
else if($calc == 'generate_docuverifyrule') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=generate_docuverifyrule';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $bclist = $response->body;
    $json_encoded_array = json_decode($bclist,true);
    $json_encoded_array = json_encode($json_encoded_array,true);
    print_r($json_encoded_array);
    return false;
}
else if ($calc == 'get_partbankup') {
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=get_partbankup';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    $output = json_decode($output,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'doc_step_complete') {
    // print_r($_POST);
    // return false;
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'individual-partner/process_functions.php?call=validate_upldoc';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $bclist = $response->body;
    // echo($bclist);
    //     return false;
    if($bclist != "0")
    {
        $bclist = json_decode($bclist,true);
        $result['statusflag'] = 0;
        $result['data'] = $bclist["message"];
        $result['status_arr'] = $bclist["status_arr"];
        // $result['date_arr'] = $bclist["date_arr"];
        //  $result = json_encode($result,true);
        $json_array = json_encode($result, true);
        echo($json_array);
        return false;
    }
    
    
         $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=doc_step_complete';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = $response->body;
        $bclistdata['data'][0] = "";
        $bclistdata['data'][1] = "";
        $bclistdata['data'][2] = "";
        $input_array = array();
        $input_array['subtask_id'] = $_POST['subtask_id'];
        $input_array['user_id'] = $_POST['user_id'];
        $input_array['b2b_userid'] = $_POST['b2b_userid'];
        $input_array['transaction_id'] = $_POST['transaction_id'];
        $input_array['compstatus'] = $_POST['compstatus'];
        $input_array['from_gsk'] = "1";
        $json_encoded_array = json_encode($input_array,true);
        // print_r($json_encoded_array);
    // return false;
          
        $url = API_URL.'workflow/workflow.php?call=subtaskcomplete';
         
        $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($json_encoded_array)
            ->send();
    
        echo json_encode($bclistdata,true);
        return false;
}
else if($calc == 'getloantypefilter') {
        $json_encoded_array = json_encode($_POST, true);
         $url = API_URL . 'individual-partner/process_functions.php?call=getloantypefilter';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
      
        $bclist = json_decode($response->body, true);
        $json_array = json_encode($bclist, true);

    print_r($json_array);
    return false;
}
// end
else if ($calc == 'getoccupation') { //#1708 company name
    $input_array = array();
    $input_array['term'] = $_REQUEST['term'];
    $json_encoded_array = json_encode($input_array, true);
    // print_r($json_encoded_array);
    // return false;
    $url = API_URL . 'workflow/callcenternew.php?call=getoccupation';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
  
    $bclist = json_decode($response->body, true);
    $cList = array();
    foreach ($bclist as $key => $bc) {
        $a = ['id' => $bc['id'],'label' => $bc['occupation_type'],'value' => $bc['occupation_type']];
        array_push($cList, $a);
    }

    $json_encoded_array = json_encode($cList, true);

    print_r($json_encoded_array);
    return false;
}
else if ($calc == 'checkstate') { //#1708 company name
    $input_array = array();
    $input_array['pincode'] = $_POST['pincode'];
    $json_encoded_array = json_encode($input_array, true);
    $url = API_URL . 'workflow/callcenternew.php?call=checkstate';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
   
    print_r($response->body);
    return false;
}
else if ($calc == 'checkpincode') { //#1708 company name
    $input_array = array();
    $input_array['pincode'] = $_POST['pincode'];
    $json_encoded_array = json_encode($input_array, true);
    $url = API_URL . 'workflow/callcenternew.php?call=checkpincode';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
   
    print_r($response->body);
    return false;
}
else if ($calc == 'getPincode') { //#1708 company name
    $input_array = array();
    $input_array['term'] = $_REQUEST['term'];
    $json_encoded_array = json_encode($input_array, true);
    // echo $json_encoded_array;
    // return false;
    $url = API_URL . 'workflow/callcenternew.php?call=getPincode';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $bclist = json_decode($response->body, true);
    //   echo $response->body;
    // return false;
    $cList = array();
    foreach ($bclist as $key => $bc) {
        $a = ['id' => $bc['id'],'label' => $bc['pincode'],'value' => $bc['pincode']];
        array_push($cList, $a);
    }
    $json_encoded_array = json_encode($cList, true);
    print_r($json_encoded_array);
    return false;
}
else if($calc=='CreateApplication') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2buserid'];
    $input_array['trans_actype'] = $_POST['trans_actype'];
    $input_array['user_name'] = $_POST['info_name'];
    $input_array['mobileno'] = $_POST['info_mobile'];
    $input_array['email_id'] = $_POST['info_email'];
    $input_array['location'] = $_POST['info_location'];
    $json_encoded_array = json_encode($input_array,true);

    // print_r($json_encoded_array);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=createapplication';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'sendOtpsave') {
    
    $mobile_number = $_POST['info_mobile'];   
    $b2b_userid = $_POST['b2b_id'];   
    $email_id = $_POST['info_mail'];   
    $otp = mt_rand(10000, 99999);
    $_SESSION['last_otp'] = $otp;
    $_SESSION['last_mobile_number'] = $_POST['mobile_number'];
    $input_array = [
            'mobile_number' => $mobile_number,
            'email_id' => $email_id,
            'b2b_userid' => $b2b_userid
        ];
        $json_encoded_array = json_encode($input_array);
        
        $url = API_URL.'workflow/workflow.php?call=alreadychecklead';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        $output = json_decode($response->body,true);
        
       if($output==1){
            $message = $otp . " is your OTP for Home Loan Tool at www.loanwiser.in.";
            $otpStatus = SendMsg($mobile_number, $message,$otp);
            $json_verify = json_decode($otpStatus,true); 
            if($json_verify['type'] == 'success'){
                $allresult = 1;
                
            }else{
              $allresult = 2;
          }
       } else {
           $allresult = 3;
       }
  echo $allresult;
}
else if ($calc == 'sendOtpsaveBrow') {
    
    $mobile_number = $_POST['mobile_number'];  
    $email_id = $_POST['email_id'];  
    $input_array = [
            'mobile_number' => $mobile_number,
            'email_id' => $email_id
        ];
    $json_encoded_array = json_encode($input_array,true);
    // print_r($input_array);
    // return false;  
    $url = API_URL.'workflow/browsing.php?call=checkalreadyuser';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
   
     
    $output = json_decode($response->body,true);
    if($output==0){
        $otp = mt_rand(10000, 99999);
        $_SESSION['last_otp'] = $otp;
        $_SESSION['last_mobile_number'] = $_POST['mobile_number'];
        
        $message = $otp . " is your OTP for Registration at www.loanwiser.in.";
       

            $otpStatus = SendMsg($mobile_number, $message,$otp);
             $json_verify = json_decode($otpStatus,true); 
              if($json_verify['type'] == 'success'){
                        $allresult = 1;
                       
              }else{
                  $allresult = 2;
              }
           // echo $otp;
    } else {
        $allresult = 2;
         // echo $allresult;
    } 
       // echo $otp;

      echo $allresult; 
}
else if ($calc == 'resendOtp') {
    $mobile_number = $_POST['mobile_number'];
    

    $_SESSION['last_mobile_number'] = $_POST['mobile_number'];


    $json_verify = resendOtp($mobile_number);
    $json_verify1 = json_decode($json_verify,true); 
    
    if($json_verify1['type'] == 'success'){
        $allresult = 1;
    }else{
         $allresult = 0;
    }
    
     echo $allresult;
    //echo $mobile_number;
} 
else if ($calc == 'confirmOtp') {
   
    $mobileno = $_POST['mobileno'];
    if($_POST['test_lead'] == "1")
    {
      $user_name = "Test";  
    }
    else
    {
        $user_name = $_POST['user_name'];
    }
    $email_id = $_POST['email_id'];
    $otp_entered = $_POST['otp_entered'];
    $location = $_POST['location'];
    $loan_cat = $_POST['loan_cat'];
    $loan_type = $_POST['loan_type'];
    $loan_amount = str_replace(",","",$_POST['loan_amount']);
    $whatsapp = $_POST['whatsapp'];
    $trans_actype = $_POST['trans_actype'];
    $b2b_userid = $_POST['b2buserid'];
    $trans_actype = $_POST['trans_actype'];
    $redirect = $_POST['redirect'];
    $employment_type = $_POST['employment_type'];
    $has_coapp = $_POST['has_coapp'];
    $is_exist = $_POST['is_exist'];
    //  print_r($employment_type);
    // return false;
    $json_verify = verifyOtp($mobileno, $otp_entered); //need to uncomment
     $json_verify1 = json_decode($json_verify,true); //need to uncomment
   
        //   print_r($json_verify1);
        //   return false;
    //   $json_verify1['type'] = 'success'; //need to comment
    if($json_verify1['type'] == 'success'){
   
     if ($otp_entered == $_SESSION['last_otp']) {
    //  if ($otp_entered == $otp_entered) {
        // validated
        $mobile_no = $_SESSION['last_mobile_number'];
        $input_array = [
            'b2b_userid' => $b2b_userid,
            'trans_actype' => $trans_actype,
            'user_name' => $user_name,
            'mobileno' => $mobileno,
            'email_id' => $email_id,
            'loan_cat' => $loan_cat,
            'loan_type' => $loan_type,
            'location' => $location,
            'test_lead' => $_POST['test_lead'],
            'loan_amount' => $loan_amount,
            'whatsapp' => $whatsapp,
            'employment_type' => $employment_type,
            'has_coapp' => $has_coapp,
            'from_gsk' => 1,
            'is_exist' => $is_exist
            
        ];
        $json_encoded_array = json_encode($input_array);
        // print_r($json_encoded_array);
        // return false;
        $url = API_URL.'workflow/workflow.php?call=createapplicationnew'; 
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = $response->body; 
        //  print_r($response->body);
        //  return false;

        $output = json_decode($response->body,true);
        $userid =$output['user_id'];
        $userid_hash =  my_simple_crypt( $userid, 'e' );
        $output['userid_hash'] = $userid_hash;
        echo json_encode($output,true);
        return false;
        
    }else{
        echo 2;
    } 
  }else{
      echo 2;
  }
}
else if ($calc == 'confirmOtpBrow') {
    $mobileno = $_POST['mobileno'];
    $brow_name = $_POST['brow_name'];
    $brow_email = $_POST['brow_email'];

    $brow_password = md5($_POST['brow_password']);
    $brow_center_name = $_POST['brow_center_name'];
    $otp_entered = $_POST['otp_entered'];
     $direct_content = $_POST['direct_content'];
    
    $json_verify = verifyOtp($mobileno, $otp_entered);
      $json_verify1 = json_decode($json_verify,true); 

   
    //       print_r($json_verify1);
    // return false;
     // $json_verify1['type'] = 'success';
    if($json_verify1['type'] == 'success'){
   
     if ($otp_entered == $_SESSION['last_otp']) {

        // validated
        $mobile_no = $_SESSION['last_mobile_number'];
        $input_array = [
            'brow_name' => $brow_name,
            'mobileno' => $mobileno,
            'brow_email' => $brow_email,
            'brow_password' => $brow_password,
            'brow_center_name' => $brow_center_name,
            'direct_content' => $direct_content,
            'status' => '1',
            'login_provider' => 'PROPWISER'
            
        ];
        $json_encoded_array = json_encode($input_array);
        
        $url = API_URL.'workflow/browsing.php?call=browsingusers';
        $response = \Httpful\Request::post($url)
                ->sendsJson()
                ->body($json_encoded_array)
                ->send();
        $result = $response->body;
        // echo $result;
        $output = json_decode($response->body,true);
        // print_r($result);
        // return;
        $_SESSION['b2b_userid'] = $output;
        echo $output;
        return false;
        
    }else{
        echo 2;
    } 
  }else{
      echo 2;
  }
}
else if($calc == 'agree_upload'){
    $data_array = array();
    
   
    $id = $_POST['user_id'];
    $input_array['doc_file'] = $_FILES["file"]["name"];
    
    $image = $_FILES["file"]["name"];
    $target_dir = "../../emitra_doc/";
    $target_dir1 = "../../emitra_doc";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $input_array['current_date'] = $data;
    $hashvalue = md5($data);
    $input_array['hashvalue'] = $hashvalue;
    $input_array['b2b_userid'] = $id;
    //$filename = $randnum;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
    // print_r($imageFileType);
    if($imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "jpg" || $imageFileType == "bmp" || $imageFileType == "pdf"  ) {

       if($moved = move_uploaded_file($_FILES["file"]["tmp_name"], $dbfilename1)){

       $json_encoded_array = json_encode($input_array,true);
        // print_r($input_array);
        // return false;
         $url = API_URL.'workflow/loginregister.php?call=uploadagreement';
        $response = \Httpful\Request::post($url) 
            ->sendsJson()
            ->body($json_encoded_array)
            ->send(); 
              
        $res = $response->body;
        $result1 = json_decode($res,true);
        
      $result = $res;      
       echo $hashvalue;
          return false;
      } else {
        $result=0;
         echo $result;
        return false;
      }
    }
    else{
        $result=0;
         echo $result;
        return false;
    }

}
else if($calc=='updatebasicinfo') {
    
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['b2b_userid'] = $_SESSION['b2b_userid'];
    $input_array['subtask_id'] = $_POST['subtask_id'];
    $input_array['username'] = $_POST['username'];
    $input_array['mobileno'] = $_POST['mobileno'];
    $input_array['location'] = $_POST['location'];
    $input_array['email_id'] = $_POST['email_id'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $json_encoded_array = json_encode($input_array,true);
    // print_r($input_array);
    // return false;  
    $url = API_URL.'workflow/workflow.php?call=updatebasicinfo';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'loanoffers') {
    $input_array = array();
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['compute_type'] = $_POST['compute_type'];
    $input_array['recompute_flag'] = $_POST['recompute_flag'];
    $input_array['interest_period'] = $_POST['interest_period'];
    $input_array['simple_share'] = $_POST['simple_share'];
    $input_array['shortswt_share'] = $_POST['shortswt_share'];
    $input_array['cash_hand'] = str_replace(',', '', $_POST['cash_in_hand']);
    $input_array['avg_monthlybal'] = str_replace(',', '', $_POST['avg_monthlybal']);
    $input_array['annual_deposit'] = str_replace(',', '', $_POST['annual_deposit']);
    $input_array['recurring_deposit'] = str_replace(',', '', $_POST['recurring_deposit']);
    $input_array['simulate_loan'] = $_POST['simulate_loan'];
    $input_array['simulate_tenor'] = $_POST['simulate_tenor'];

    # PMAY Details for Emitra
    $input_array['firstimebuyer'] = $_POST['firstimebuyer'];
    $input_array['familyincome'] = $_POST['familyincome'];
    $input_array['ownhouse'] = $_POST['ownhouse'];
    $input_array['availdpmay'] = $_POST['availdpmay'];

    # Property details
    $input_array['loan_type'] = $loan_type = $_POST['loan_type'];
    switch ($loan_type) {
        case 1:
            # Home Loan
            $input_array['property_identified'] = $_POST['property_identified'];
            $input_array['property_details'] = $_POST['property_details'];
            $input_array['cost_of_land'] = str_replace(',', '', $_POST['cost_of_land']);
            $input_array['cost_of_construction'] = str_replace(',', '', $_POST['cost_of_construction']);
            $input_array['cost_of_property'] = str_replace(',', '', $_POST['cost_of_property']);
            $input_array['builder_name'] = $_POST['builder_name'];
            break;
        case 2:
            # Loan Against Property
            $input_array['property_category'] = $_POST['property_category'];
            $input_array['property_value'] = str_replace(',', '', $_POST['property_value']);
            $input_array['built_up_area'] = str_replace(',', '', $_POST['built_up_area']);
            break;
        case 3:
            # Balance Transfer
            $input_array['exist_loan_varient'] = $_POST['exist_loan_varient'];
            $input_array['property_details'] = $_POST['property_details'];
            $input_array['property_category'] = $_POST['property_category'];
            $input_array['builder_name'] = $_POST['builder_name'];
            $input_array['cost_of_property'] = str_replace(',', '', $_POST['cost_of_property']);           
            
            $input_array['exist_loan_availd'] = str_replace(',', '', $_POST['exist_loan_availd']);
            $input_array['exist_loan_start'] = $_POST['exist_loan_start'];
            $input_array['original_loan_amount'] = str_replace(',', '', $_POST['original_loan_amount']);
            $input_array['outstanding_loan'] = str_replace(',', '', $_POST['outstanding_loan']);

            break;
        case 4:
            # Topup Home loan
            $input_array['exist_loan_varient'] = $_POST['exist_loan_varient'];
            $input_array['property_details'] = $_POST['property_details'];
            $input_array['property_category'] = $_POST['property_category'];
            $input_array['builder_name'] = $_POST['builder_name'];
            $input_array['cost_of_property'] = str_replace(',', '', $_POST['cost_of_property']); 
            $input_array['outstanding_principal'] = str_replace(',', '', $_POST['outstanding_principal']);
            $input_array['exist_loan_start'] = $_POST['exist_loan_start'];
            $input_array['loan_ac_no'] = $_POST['loan_ac_no'];
            $input_array['original_sanction_loan'] = str_replace(',', '', $_POST['original_sanction_loan']);
            $input_array['original_emi'] = str_replace(',', '', $_POST['original_emi']);
            break;
        case 5:
            # Balance transfer along with topup
            $input_array['exist_loan_varient'] = $_POST['exist_loan_varient'];
            $input_array['property_details'] = $_POST['property_details'];
            $input_array['property_category'] = $_POST['property_category'];
            $input_array['builder_name'] = $_POST['builder_name'];
            $input_array['cost_of_property'] = str_replace(',', '', $_POST['cost_of_property']); 
            $input_array['exist_loan_availd'] = str_replace(',', '', $_POST['exist_loan_availd']);
            $input_array['exist_loan_start'] = $_POST['exist_loan_start'];
            $input_array['original_sanction_loan'] = str_replace(',', '', $_POST['original_sanction_loan']);
            $input_array['outstanding_loan'] = str_replace(',', '', $_POST['outstanding_loan']);
            break;
        case 6:
            # Loan for puchasing non residential property
            $input_array['property_value'] = str_replace(',', '', $_POST['property_value']);
            $input_array['built_up_area'] = str_replace(',', '', $_POST['built_up_area']);
            break;;
    }
    
    # Applicants data
    $user_data = array();
    $i = 0;
    foreach ($_POST['aname'] as $key => $value) {
        $temp = array();
        $temp['name'] = $_POST['aname'][$key];
        $temp['age'] = $_POST['aage'][$key];
        $temp['retirement_age'] = $_POST['arage'][$key];
        $temp['member_dob'] = $_POST['adob'][$key];
        $temp['relationship_id'] = ($key+1);
        $temp['resident_status'] = $_POST['restatus'][$key];
        $temp['resident_country'] = (isset($_POST['rescount'][$key])) ? $_POST['rescount'][$key] : 0;
        # New Fields
        $temp['gender'] = $_POST['agender'][$key];
        $temp['pan_no'] = $_POST['apanno'][$key];
        $temp['adhar_no'] = $_POST['aadharno'][$key];
        $temp['bhamasa_id'] = $_POST['abhamasaid'][$key]; 
        $temp['living_city'] = $_POST['alivingcity'][$key];
        $temp['designation'] = $_POST['adesignation'][$key];
        $temp['office_email'] = $_POST['aofficeemail'][$key];
        $temp['avg_incentive'] = $_POST['aavgincentive'][$key];
        $temp['salary_mode'] = $_POST['asalarymode'][$key];
        $temp['income_proof'] = $_POST['aincomeproof'][$key];
        # Current Address
        $temp['since_living'] = $_POST['asinceliving'][$key];
        $temp['flat_no'] = $_POST['aflatno'][$key];
        $temp['building_name'] = $_POST['abuildingname'][$key];
        $temp['street'] = $_POST['astreet'][$key];
        $temp['city_name'] = $_POST['acityname'][$key];
        $temp['state_name'] = $_POST['astatename'][$key];
        $temp['pin_code'] = $_POST['apincode'][$key];
        $temp['is_sameas_curadr'] = $_POST['asameascurrentadr'][$key]; #y/n
        # Permanent Address
        $temp['per_flatno'] = $_POST['perflatno'][$key];
        $temp['per_buildingname'] = $_POST['perbuildingname'][$key];
        $temp['per_street'] = $_POST['perstreet'][$key];
        $temp['per_cityname'] = $_POST['percityname'][$key];
        $temp['per_statename'] = $_POST['perstatename'][$key];
        $temp['per_pincode'] = $_POST['perpincode'][$key];

        $temp['employee_type'] = $_POST['nemploy'][$key];

        $temp['gross_income'] = (isset($_POST['agrossincome'][$key])) ? str_replace(',', '', $_POST['agrossincome'][$key]) : 0;
        $temp['net_income'] = (isset($_POST['anetincome'][$key])) ? str_replace(',', '', $_POST['anetincome'][$key]) : 0;
        $temp['annual_bonus'] = str_replace(',', '', $_POST['abonus'][$key]);
        
        # Self Employeed
        $temp['annual_grossprofit'] = (isset($_POST['agrossprofit'][$key])) ? str_replace(',', '', $_POST['agrossprofit'][$key]) : 0;
        $temp['annual_netprofit'] = (isset($_POST['anetprofit'][$key])) ?str_replace(',', '', $_POST['anetprofit'][$key]) : 0;
        $temp['annual_profit_prev'] = str_replace(',', '', $_POST['aprofit_prev'][$key]);
        $temp['director_remun'] = str_replace(',', '', $_POST['adirectorremun']);
        $temp['currentyr_tax'] = str_replace(',', '', $_POST['acyr_tax'][$key]);
        $temp['depreci_curyr'] = str_replace(',', '', $_POST['depreci_curyr'][$key]);
        $temp['depreci_prevyr'] = str_replace(',', '', $_POST['depreci_prevyr'][$key]);
        $temp['company_type'] = (isset($_POST['company_type'][$key])) ? $_POST['company_type'][$key] : 0;
        $temp['company_name'] = $_POST['company_name'][$key];
        $temp['working_since'] = $_POST['working_since'][$key];
        $temp['employee_status'] = (isset($_POST['employee_status'][$key])) ? $_POST['employee_status'][$key] : 1;
        $temp['employee_count'] = (isset($_POST['employee_count'][$key])) ? $_POST['employee_count'][$key] : 0;
        $temp['profession'] = (isset($_POST['profession'][$key])) ? $_POST['profession'][$key] : 0;
        $temp['firm_type'] = (isset($_POST['firm_type'][$key])) ? $_POST['firm_type'][$key] : 0;
        $temp['qualification'] = (isset($_POST['qualification'][$key])) ? $_POST['qualification'][$key] : 0;
        $temp['working_experience'] = (isset($_POST['working_experience'][$key])) ? $_POST['working_experience'][$key] : 0;

        $income_array = array();
        foreach ($_POST['income_type'][$key] as $index => $emi) {
            $ntemp = array();
            $ntemp['income_type'] = $_POST['income_type'][$key][$index];
            $ntemp['income_amount'] = str_replace(',', '', $_POST['income_amount'][$key][$index]);
            array_push($income_array,$ntemp);
        }
        $temp['otherincome_arr'] = $income_array;

        $emi_array = array();
        foreach ($_POST['emi_loan_type'][$key] as $index => $emi) {
            $ntemp = array();
            $ntemp['loan_type'] = $_POST['emi_loan_type'][$key][$index];
            $ntemp['emi_amount'] = str_replace(',', '', $_POST['emi_amount'][$key][$index]);
            $ntemp['remaining_tenor'] = $_POST['remaining_months'][$key][$index];
            array_push($emi_array,$ntemp);
        }
        $temp['outgoing_emi'] = $emi_array;
        array_push($user_data, $temp);
        $i++;
    }

    $input_array['user_data'] = $user_data;
    $json_encoded_array = json_encode($input_array,true);
    
    // print_r($input_array);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=generateoffers';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;
    
    $output = json_decode($response->body,true);

    $user_id = $output['user_id'];
    $user_type = $output['user_type'];
    // $_SESSION['user_id'] = $user_id;
    // $_SESSION['user_type'] = $user_type;

    $result = [
        "userid" =>  $user_id,
        'result' => $output
    ];
    echo json_encode($result,true);
    return false;
} 
// else if ($calc == 'saveloanoffer') {
//     $data_arr = [
//         'transaction_id' => $_POST['trans_id'],
//         'b2b_userid' => $_POST['b2b_userid'],
//         'user_id' => $_POST['user_id'],
//         'scheme_id' => $_POST['scheme_id'],
//         'max_loan' => $_POST['max_loan'],
//         'interest_rate' => $_POST['int_rate'],
//         'emi_amount' => $_POST['emi_amount'],
//         'oc_equired' => $_POST['oc_equired'],
//         'affordable_price' => $_POST['affordable_price']
//     ];
//     $json_encoded_array = json_encode($data_arr, true);
//     // print_r($json_encoded_array);
//     // return;
//     $url = API_URL.'workflow/workflow.php?call=saveloanoffer';
//     $response = \Httpful\Request::post($url)
//         ->sendsJson()
//         ->body($json_encoded_array)
//         ->send();
//     $output = $response->body;
//     echo $output;
//     return false;
// }
else if ($calc == 'saveloanoffer') {
    $data_arr = [
        'transaction_id' => $_POST['trans_id'],
        'b2b_userid' => $_POST['b2b_userid'],
        'user_id' => $_POST['user_id'],
        'scheme_id' => $_POST['scheme_id'],
        'offer_id' => $_POST['offer_id']
    ];
    $json_encoded_array = json_encode($data_arr, true);

    $url = API_URL . 'workflow/homeloan.php?call=saveloanoffer';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    echo $output;
    return false;
}
else if ($calc == 'deletesingledoc') {
    $usertype = $_POST['usertype'];
    $classid = $_POST['classid'];
    $transid = $_POST['transid'];
    $hash = $_POST['hash'];
    $tabid = $_POST['tabid'];
    
    
        $input_array = [
            'usertype' => $usertype,
            'classid' => $classid,
            'transid' => $transid,
            'hash' => $hash,
            'tabid' => $tabid
        ];
        $json_encoded_array = json_encode($input_array);
        
        $url = API_URL.'workflow/workflow.php?call=deletesingledoc';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        $output = json_decode($response->body,true);
        
        $path = '../../emitra_doc/'.$output;
        unlink($path);
        echo $output;
        return false;
}
else if ($calc == 'deletesingleadditionaldoc') {
    $usertype = $_POST['usertype'];
    $userid = $_POST['userid'];
   $hash = $_POST['hash'];
    
    
    
        $input_array = [
            'usertype' => $usertype,
            'userid' => $userid,
            'hash' => $hash,
        ];
        $json_encoded_array = json_encode($input_array);
        
        $url = API_URL.'workflow/workflow.php?call=deletesingleadditionaldoc';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        $output = json_decode($response->body,true);
    // echo $response->body;
        $path = '../../emitra_doc/'.$output;
        unlink($path);
        echo $output;
        return false;
}
else if($calc == 'trackstatus'){
    $data_arr = [
        'transaction_id' => $_POST['trans_id'],
        'b2b_userid' => $_POST['b2b_userid'],
        'user_id' => $_POST['user_id'],
        'scheme_id' => $_POST['scheme_id'],
        'offer_id' => $_POST['offer_id']
    ];
    $json_encoded_array = json_encode($data_arr, true);

    $url = API_URL . 'workflow/homeloan.php?call=stages';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    echo $output;
    return false;
}
else if($calc == 'post_view_close'){
    
    $json_encoded_array = json_encode($_POST, true);
    // echo $json_encoded_array;
    // return false;
    $url = API_URL . 'individual-partner/gsk_integration.php?call=post_view_close';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    echo $output;
    return false;
}
else if($calc == 'boosterplan') {
    $data_arr = [
        'trans_id' => $_POST['trans_id'],
        'emi_eligible' => $_POST['emi_eligible'],
        'int_rate' => $_POST['int_rate'],
        'final_loan' => $_POST['final_loan'],
        'max_tenure' => $_POST['max_tenure'],
        'interest_period' => $_POST['interest_period'],
        'booster_income' => $_POST['income']
    ];
    $json_encoded_array = json_encode($data_arr,true);
    
    $url = API_URL.'loan/idfchomeloan.php?call=boosterplan';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = $response->body;
    echo $output;
    return false;
}
else if($calc == 'shortandsweet') {
    $data_arr = [
        'trans_id' => $_POST['trans_id'],
        'emi_eligible' => $_POST['emi_eligible'],
        'int_rate' => $_POST['int_rate'],
        'final_loan' => $_POST['final_loan'],
        'max_tenure' => $_POST['max_tenure'],
        'recur_deposit' => $_POST['recur_deposit'],
        'avg_balance' => $_POST['avg_balance'],
        'annual_deposit' => $_POST['annual_deposit']
    ];
    $json_encoded_array = json_encode($data_arr,true);

    $url = API_URL.'loan/idfchomeloan.php?call=shortsweet';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = $response->body;
    echo $output;
    return false;
}
else if($calc == 'maxsaver') {
    $data_arr = [
        'trans_id' => $_POST['trans_id'],
        'simple_share' => $_POST['simple_share'],
        'shortswt_share' => $_POST['shortswt_share'],
        'emi_eligible' => $_POST['emi_eligible'],
        'int_rate' => $_POST['int_rate'],
        'ss_int_rate' => $_POST['ss_int_rate'],
        'final_loan' => $_POST['final_loan'],
        'max_tenure' => $_POST['max_tenure'],
        'recur_deposit' => $_POST['recur_deposit'],
        'avg_balance' => $_POST['avg_balance'],
        'annual_deposit' => $_POST['annual_deposit']
    ];
    $json_encoded_array = json_encode($data_arr,true);

    $url = API_URL.'loan/idfchomeloan.php?call=maxsaver';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = $response->body;
    echo $output;
    return false;
}
else if($calc == 'downloadcountupdate') {
    
    
    // $app_arr = ["occuption:".$_POST['occupation']['0'].
    // ",mothincome:".str_replace(",","",$_POST['mothincome']['0']).
    // ",residence:".$_POST['residence']['0'].
    // ",incomeproof:".$incomeproof.
    // ",businesseg:".$_POST['businesseg']['0'].
    // ",businessproo:".$_POST['businessproo']['0']];
    
    
    $data_arr = [];
    if($_POST['applicant_value']==1){
        $stat_arr = [$_POST['coapplicant0_frmgen']];
    } else if($_POST['applicant_value']==2){
        $stat_arr = [$_POST['coapplicant0_frmgen'],$_POST['coapplicant1_frmgen']];
        
    }else if($_POST['applicant_value']==3){
        $stat_arr = [$_POST['coapplicant0_frmgen'],$_POST['coapplicant1_frmgen'],$_POST['coapplicant2_nustatus']];

    }else if($_POST['applicant_value']==4){
        $stat_arr = [$_POST['coapplicant0_frmgen'],$_POST['coapplicant1_frmgen'],$_POST['coapplicant2_nustatus'],$_POST['coapplicant3_nustatus']];

    }else if($_POST['applicant_value']==5){
        $stat_arr = [$_POST['coapplicant0_frmgen'],$_POST['coapplicant1_frmgen'],$_POST['coapplicant2_nustatus'],$_POST['coapplicant3_nustatus'],$_POST['coapplicant4_nustatus']];

    }
    
    $language_obj = str_replace('"',"'",json_encode($stat_arr,true));
    // print_r($_POST);
    // return false;
    
    if($_POST['loanap_category']==2){
        $property_identified = 2;    
    }
    else{
        $property_identified = $_POST['propidenti_frmgen'];
    }
    if($_POST['coapplicant0_frmgen']==1){
        $incomeproofapp = $_POST['incomeproofsal']['0'];
    } else {
         $incomeproofapp = $_POST['incomeproofself']['0'];
    }
    if($_POST['coapplicant1_frmgen']==1){
        $incomeproofcoapp = $_POST['incomeproofsal']['1'];
    } else {
         $incomeproofcoapp = $_POST['incomeproofself']['1'];
    }
    $incomeproofapp = str_replace('"',"'",json_encode($incomeproofapp,true));
    $incomeproofcoapp = str_replace('"',"'",json_encode($incomeproofcoapp,true));
    // print_r($language_obj);
    // return false;
    if($_POST['applicant_value']==1){
        
           $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['mothincome'][0]);
            $app_arr['app']['residence'] = $_POST['residence']['0'];
            
            $app_arr['app']['businesseg'] = $_POST['businesseg']['0'];
            $app_arr['app']['businessproo'] = $_POST['businessproo']['0'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        
    } else {
        $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['mothincome'][0]);
            $app_arr['app']['residence'] = $_POST['residence']['0'];
            $app_arr['app']['businesseg'] = $_POST['businesseg']['0'];
            $app_arr['app']['businessproo'] = $_POST['businessproo']['0'];
            $app_arr['coapp']['occuption'] = $_POST['occupation']['1'];
            $app_arr['coapp']['mothincome'] = str_replace(",","",$_POST['mothincome'][1]);
            $app_arr['coapp']['residence'] = $_POST['residence']['1'];
            $app_arr['coapp']['businesseg'] = $_POST['businesseg']['1'];
            $app_arr['coapp']['businessproo'] = $_POST['businessproo']['1'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true)); 
    }
    
   
    $data_arr['status_arr']=$language_obj;
    $data_arr['info_name']=$_POST['username'];
    $data_arr['info_mobile']=$_POST['info_mobile'];
    $data_arr['user_id']=$_POST['user_id'];
    $data_arr['transaction_id']=$_POST['transaction_id'];
    $data_arr['applicant_value']=$_POST['applicant_value'];
    $data_arr['formloan_cat']=$_POST['loanap_category'];
    $data_arr['loantype_frmgen']=$_POST['loan'];
    $data_arr['download_count']=$_POST['download_count'];
    $data_arr['loan_amount']=str_replace(",","",$_POST['loan_amount']);
    $data_arr['prop_location_pincode']=$_POST['prop_location_pincode'];
    $data_arr['work_location_pincode']=$_POST['work_location_pincode'];
    $data_arr['propidenti_frmgen']=$property_identified;
    $data_arr['prop_stateid']=$_POST['prop_stateid'];
    $data_arr['prop_districtid']=$_POST['prop_districtid'];
    $data_arr['loaction_stateid']=$_POST['loaction_stateid'];
    $data_arr['loaction_districtid']=$_POST['loaction_districtid'];
    $data_arr['subtask_id']=$_POST['subtask_id'];
    $data_arr['select_area']=$_POST['select_area'];
    $data_arr['select_areaprop']=$_POST['select_areaprop'];
    $data_arr['appdetails']=$appde_arr;
    $data_arr['incomeprofapp']=$incomeproofapp;
    $data_arr['incomeprofcoapp']=$incomeproofcoapp;
     $print_arr = [
        'ssoid' => $_POST['ssoid'],
        'applicant_id' => $_POST['applicant_id'],
        'applicant_value' => $_POST['applicant_value'],
        'info_name' => $_POST['username'],
        'info_mobile' => $_POST['info_mobile'],
        'loanap_category' => $_POST['loanap_category'],
        'loantype_frmgen' => $_POST['loan'],
        'propidenti_frmgen' => $property_identified,
        'loan_amount' => str_replace(",","",$_POST['loan_amount']),
        'company_name' => $_POST['company_name'],
        'loan_amount' => str_replace(",","",$_POST['loan_amount']),
        'applicant_nustatus' => $_POST['coapplicant0_frmgen'],
        'coapplicant1_nustatus' => $_POST['coapplicant1_frmgen'],
        'coapplicant2_nustatus' => $_POST['coapplicant2_nustatus'],
        'coapplicant3_nustatus' => $_POST['coapplicant3_nustatus'],
        'coapplicant4_nustatus' => $_POST['coapplicant4_nustatus'],
        
    ];
    
    $json_encoded_array = json_encode($data_arr,true);
    // print($json_encoded_array);
    // return false;
    $json_encoded_printarray = json_encode($print_arr,true);
    // print_r($json_encoded_printarray);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=downloadcountupdate';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = $response->body;
    $output = json_decode($response->body,true);

    // echo $output;
    // return false;
    $url = BASE_URL.'downloadapplication.php';
    $responses = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_printarray)
        ->send();
    
    $result = $responses->body;
        
        $output['pdf'] = $result;
        echo json_encode($output,true);
    return false;
}
else if($calc=='getdocumentlist') {
    $input_array = array();
    $input_array['checklist_code'] = $_POST['checklist_code'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['applicant_empstatus'] = $_POST['applicant_empstatus'];
    $input_array['usertype'] = $_POST['usertype'];
  

    $json_encoded_array = json_encode($input_array,true);
    
    $url = API_URL.'workflow/workflow.php?call=getdocumentlist';
     
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'uploaddocumentlist') {
    $input_array = array();
    $input_array['doc_file'] = $_POST['doc_file'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['subtask_id'] = $_POST['subtask_id'];
    $input_array['classid'] = $_POST['classid'];
    $input_array['doc_type_id'] = $_POST['doc_type_id'];
    $input_array['docname'] = $_POST['docname'];
    $input_array['usertype'] = $_POST['usertype'];
    $input_array['docid'] = $_POST['docid'];
    $input_array['doc_file'] = $_FILES["doc_file"]["name"];
    $image = $_FILES["doc_file"]["name"];
    $id = $_POST['id'];
    $target_dir = "../../emitra_doc/";
    $target_dir1 = "../../emitra_doc";
    $target_file = $target_dir . basename($_FILES["doc_file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $input_array['current_date'] = $data;
    $hashvalue = md5($data);
    $input_array['hashvalue'] = $hashvalue;
    //$filename = $randnum;
    
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['doc_file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
    
  
    

       if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename1)){
       $json_encoded_array = json_encode($input_array,true);
        // print_r($json_encoded_array);
        // return false;
        $url = API_URL.'workflow/workflow.php?call=documentchecklistupload';
        $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($json_encoded_array)
            ->send();
        $result = $response->body;
       $input_arrays['subtask_id'] = $_POST['subtask_id'];
    $input_arrays['user_id'] = $_POST['user_id'];
    $input_arrays['b2b_userid'] = $_SESSION['b2b_userid'];
    $input_arrays['transaction_id'] = $_POST['transaction_id'];
    $input_arrays['compstatus'] = 3;
    $input_arrays['from_gsk'] = "1";
    $json_encoded_arrays = json_encode($input_arrays,true);
      
    $urls = API_URL.'workflow/workflow.php?call=subtaskcomplete';
     
    $responsessss = \Httpful\Request::post($urls)
        ->sendsJson()
        ->body($json_encoded_arrays)
        ->send();
    
         echo $response;
        return false;
     } else {
        $result=0;
        echo $result;
        return false;
     }
    
     
}
else if ($calc == 'profile_otp') {
    
        $mobile_number = $_POST['mobile_number'];  
        $otp = mt_rand(10000, 99999); 
        $_SESSION['last_otp'] = $otp;
        $_SESSION['last_mobile_number'] = $_POST['mobile_number'];
        
        $message = $otp . " is your OTP for Mobile Verification at www.emitra.propwiser.com.";
       

            $otpStatus = SendMsg($mobile_number, $message,$otp);
             $json_verify = json_decode($otpStatus,true); 
            $json_verify['type'] = 'success';
              if($json_verify['type'] == 'success'){
                        $allresult = 1;
                       
              }else{
                  $allresult = 2;
              }
           
            echo $allresult; 
}
else if($calc=='profile_save') {
    
    $mobile_number = $_POST['profile_mobile'];
    $otp_entered = $_POST['otp_entered'];
    $json_verify = verifyOtp($mobile_number, $otp_entered);
    $json_verify1 = json_decode($json_verify,true);
    // $json_verify1['type'] = "success"
    if($json_verify1['type'] == 'success'){
   
     if ($otp_entered == $_SESSION['last_otp']) {
         
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['kiosk_name'] = $_POST['profile_name'];
    $input_array['email_id'] = $_POST['profile_mail'];
    $input_array['mobile_no'] = $_POST['profile_mobile'];
    $input_array['state_id'] = $_POST['profile_state'];
    $input_array['district_id'] = $_POST['profile_district'];
    $input_array['district_name'] = $_POST['district_name'];
    $input_array['location'] = $_POST['location'];
    $input_array['locality_id'] = $_POST['profile_locality'];
    $input_array['address_type'] = $_POST['isRural'];
    $input_array['kiosk_code'] = $_POST['operator_id'];
    $input_array['pincode'] = $_POST['profile_pincode'];
    if($_POST['isRural'] == "rural")
    {
        $input_array['gram_panchayat'] = $_POST['profile_grampanch'];
        $input_array['panchayat'] = $_POST['profile_panch'];
    }
    if($_POST['isRural'] == "urban")
    {
        $input_array['ward_no'] = $_POST['profile_wardno'];
        $input_array['municipality'] = $_POST['profile_municpality'];
    }
    $input_array['profile_address'] = $_POST['profile_address'];
    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'meeseva/meeseva.php?call=profile_saveemitra';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
     }
     else
     {
         echo 2;
     }
     
    }
    else
    {
        echo 3;
    }
    
}
else if($calc=='callback_save') {
    
    $mobile_number = $_POST['call_mobile'];
    $otp_entered = $_POST['otp_entered'];
    $json_verify = verifyOtp($mobile_number, $otp_entered);
    $json_verify1 = json_decode($json_verify,true); 
    if($json_verify1['type'] == 'success'){
   
     if ($otp_entered == $_SESSION['last_otp']) {
         
    $input_array['kiosk_name'] = $_POST['call_name'];
    $input_array['email_id'] = $_POST['call_mail'];
    $input_array['callback_remarks'] = $_POST['callback_remarks'];
    $input_array['mobile_no'] = $_POST['call_mobile'];
    $input_array['kiosk_code'] = $_POST['operator_id'];
    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'meeseva/meeseva.php?call=callback_save';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
     }
     else
     {
         echo 2;
     }
     
    }
    else
    {
        echo 3;
    }
    
}
else if($calc=='callbackdir_save') {
    

         
    $input_array['kiosk_name'] = $_POST['call_name'];
    $input_array['callback_remarks'] = $_POST['callback_remarks'];
    $input_array['kiosk_code'] = $_POST['operator_id'];
    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'meeseva/meeseva.php?call=callback_save';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
    
    
} 
else if ($calc == 'uploaddocs') {
    
    $input_array = array();
    $input_array['doc_name'] = $_POST['doc_name'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['user_type'] = $_POST['user_type'];
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['is_applicant'] = "0";
    $input_array['hiddendocumentid'] = $_POST['hiddendocumentid'];
    $input_array['doc_file'] = $_FILES["doc_file"]["name"];

    $image = $_FILES["doc_file"]["name"];
    $id = $_POST['id'];
    $target_dir = "../../emitra_doc/";
    $target_dir1 = "../../emitra_doc";
    $target_file = $target_dir . basename($_FILES["doc_file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $input_array['current_date'] = $data;
    $hashvalue = md5($data);
    $input_array['hashvalue'] = $hashvalue;
    //$filename = $randnum;
   
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['doc_file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
    // print_r($imageFileType);
   

       if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename1)){
       $json_encoded_array = json_encode($input_array,true);
        // print_r($json_encoded_array);
        // return false;
        $url = API_URL.'workflow/workflow.php?call=uploaddocuments';
        $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($json_encoded_array)
            ->send();
        $result = $response->body;
         echo $hashvalue;
        return false;
     } else {
        $result=0;
        echo $result;
        return false;
     }
    

    
}
else if($calc=='subtaskcomplete') {
    $input_array = array();
    $input_array['subtask_id'] = $_POST['subtask_id'];
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['b2b_userid'] = $_SESSION['b2b_userid'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['compstatus'] = $_POST['compstatus'];
    $input_array['from_gsk'] = "1";
    
    $json_encoded_array = json_encode($input_array,true);
      
    $url = API_URL.'workflow/workflow.php?call=subtaskcomplete';
     
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    print_r($response->body);
    return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='addnotes') {
    $input_array = array();
    $input_array['note_desc'] = $_POST['note_desc'];
    $input_array['note_title'] = $_POST['note_title'];
    $input_array['noteid'] = $_POST['noteid'];
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['internalnotes'] = 2;

    $json_encoded_array = json_encode($input_array,true);
    
    $url = API_URL.'workflow/workflow.php?call=addnotes';
     
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='getsinglenote') {
    $noteid= $_POST['noteid'];
    
    $url = API_URL.'workflow/workflow.php?call=getsinglenote&noteid='.$noteid;
     
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body()
        ->send();
       
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'uploadapplicationdocs') {
    
    $input_array = array();
    $input_array['doc_name'] = "Applicant Form";
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['hiddendocumentid'] = "0";
    $input_array['user_type'] = "0";
    $input_array['is_applicant'] = "1";
    $input_array['doc_file'] = $_FILES["doc_file"]["name"];

    $image = $_FILES["doc_file"]["name"];
     $id = $_POST['id'];
     $target_dir = "../../emitra_doc/";
     $target_dir1 = "../../emitra_doc";
    $target_file = $target_dir . basename($_FILES["doc_file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $input_array['current_date'] = $data;
    $input_array['hashvalue'] = md5($data);
    //$filename = $randnum;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['doc_file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
    // print_r($imageFileType);
    if($imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "jpg" || $imageFileType == "bmp" || $imageFileType == "pdf"  ) {

       if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename1)){
       $json_encoded_array = json_encode($input_array,true);
        // print_r($json_encoded_array);
        // return false;
        $url = API_URL.'workflow/workflow.php?call=uploaddocuments';
        $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($json_encoded_array)
            ->send();
        $result = $response->body;
         echo $result;
        return false;
     } else {
        $result=0;
        echo $result;
        return false;
     }
    }
    else{
        $result=0;
        echo $result;
        return false;
    }

    
}
else if($calc=='getnotifications') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['transaction_id'] = $_POST['transaction_id'];

    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=getnotifications';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='getactivities') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['transaction_id'] = $_POST['transaction_id'];

    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=getactivities';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='check_submit') {
   
    $json_encoded_array = json_encode($_POST,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'individual-partner/gsk_integration.php?call=check_submit';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='get_AllLeads') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $json_encoded_array = json_encode($input_array,true);
    $url = API_URL.'individual-partner/gsk_integration.php?call=get_AllLeads';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='get_AllLeadsGsk') {
    $input_array = array();
    // $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'individual-partner/gsk_integration.php?call=get_AllLeadsGsk';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='partner_displayGsk') {
    $input_array = array();
    // $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'individual-partner/gsk_integration.php?call=partner_displayGsk';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'getmodel') {
     $data = [
        
        'makeby'=> $_POST['make']
        
         
    ];
    $json_encoded_array = json_encode($data, true);
    $url = API_URL . 'workflow/callcenternew.php?call=getmodel';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = $response->body;
    
    echo $output;
    return false;
}
else if($calc=='gskLogin') {
    $input_array['mail_id'] = $_POST['email'];
    $input_array['password'] = $_POST['password'];
    $json_encoded_array = json_encode($input_array,true);
    $url = API_URL.'workflow/workflow.php?call=login';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $output = json_decode($response->body,true);
    $_SESSION['partner_id'] = $output['id'];
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'leads_state') {

   $data = [
        'state_value' => $_POST['state_value'],
         
    ];
    $json_encoded_array = json_encode($data, true);

    $url =API_URL.'workflow/callcenternew.php?call=districts';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($json_encoded_array)
            ->send();

    $output = $response->body;
   echo $output;
    return false;
    
   
   
}
else if($calc=='get_SancLeads') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    
    $json_encoded_array = json_encode($input_array,true);
   
    $url = API_URL.'individual-partner/gsk_integration.php?call=get_Sancleads';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo $response;
    return false;
}
else if($calc=='get_SancLeadsGsk') {
    
    $json_encoded_array = json_encode($_POST,true);
   
    $url = API_URL.'individual-partner/gsk_integration.php?call=get_SancleadsGsk';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo $response;
    return false;
}
else if($calc == 'browsingagreement') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['transaction_id'] = $_POST['transaction_id'];

    $json_encoded_array = json_encode($input_array,true);
    $url = API_URL.'workflow/workflow.php?call=browsingagreement';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $doc =  stripcslashes(trim($response->body));
    
    // $myFile = "../images/agreement.html"; // or .php   
    // $fh = fopen($myFile, 'w'); // or die("error");   
    // fwrite($fh, $doc);
    // fclose($fh);

    echo $doc;
    return false;
}
else if($calc=='complete_reg') {
    
    $b2b_userid= $_POST['b2b_userid'];
    $_SESSION['b2b_userid'] = $b2b_userid;
    $json_encoded_array = json_encode($input_array,true);
    // print_r($b2b_userid);
    // return false;  
    $url = API_URL.'workflow/workflow.php?call=completereg&b2b_userid='.$b2b_userid;
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='complete_setting') {
    
    $b2b_userid= $_POST['b2b_userid'];
    $_SESSION['b2b_userid'] = $b2b_userid;
    $json_encoded_array = json_encode($input_array,true);
    // print_r($b2b_userid);
    // return false;  
    $url = API_URL.'workflow/loginregister.php?call=complete_setting&b2b_userid='.$b2b_userid;
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='regenerateagree') {
    
    $b2b_userid= $_POST['b2b_userid'];
    $_SESSION['b2b_userid'] = $b2b_userid;
    $json_encoded_array = json_encode($input_array,true);
    // print_r($b2b_userid);
    // return false;  
    $url = API_URL.'workflow/loginregister.php?call=regenerateagree&b2b_userid='.$b2b_userid;
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='promoemitra') {
    
    $data_array = array();
    $id = $_POST['b2b_userid'];
    $input_array['upload_opt']=0;
    $input_array['doc_file'] = $_FILES["file"]["name"];
    $input_array['b2b_userid'] = $id;
    $image = $_FILES["file"]["name"];
    $target_dir = "../../emitra_promodoc/";
    $target_dir1 = "../../emitra_promodoc";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $todaydate = date("Y-m-d");
    $data= strtotime($current_date);
    $input_array['current_date'] = $todaydate;
    $hashvalue = md5($data);
    $input_array['hashvalue'] = $hashvalue;
    //$filename = $randnum;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
    // print_r($imageFileType);
    $json_encoded_array = json_encode($input_array,true);
    // print_r($json_encoded_array);
    // return false;
   
        //  echo  $dbfilename1;
        // return false;
       if($moved = move_uploaded_file($_FILES["file"]["tmp_name"], $dbfilename1)){

       

         $url = API_URL.'emitra/emitra.php?call=updateimagepath';
        $response = \Httpful\Request::post($url) 
            ->sendsJson()
            ->body($json_encoded_array)
            ->send(); 
              
        $res = $response->body;
        $result1 = json_decode($res,true);
        $result = $hashvalue;     
        echo $result;
          return false;
      } else {
         $result=0;
        echo $result;
        return false;
      }
   
}
else if($calc=='promoemitra1') {
    
    $data_array = array();
    $id = $_POST['b2b_userid'];
    $input_array['upload_opt']=1;
    $input_array['doc_file'] = $_FILES["file"]["name"];
    $input_array['b2b_userid'] = $id;
    $image = $_FILES["file"]["name"];
    $target_dir = "../../emitra_promodoc/";
    $target_dir1 = "../../emitra_promodoc";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $todaydate = date("Y-m-d");
    $data= strtotime($current_date);
    $input_array['current_date'] = $todaydate;
    $hashvalue = md5($data);
    $input_array['hashvalue'] = $hashvalue;
    //$filename = $randnum;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
    // print_r($imageFileType);
    $json_encoded_array = json_encode($input_array,true);
    // print_r($json_encoded_array);
    // return false;
  

       if($moved = move_uploaded_file($_FILES["file"]["tmp_name"], $dbfilename1)){

       

         $url = API_URL.'emitra/emitra.php?call=updateimagepath';
        $response = \Httpful\Request::post($url) 
            ->sendsJson()
            ->body($json_encoded_array)
            ->send(); 
              
        $res = $response->body;
        $result1 = json_decode($res,true);
        $result = $hashvalue;     
        echo $result;
          return false;
      } else {
         $result=0;
        echo $result;
        return false;
      }
   
}
else if($calc=='logout_complet') {
    
    $b2b_userid= $_POST['b2b_userid'];
    $_SESSION['b2b_userid'] = $b2b_userid;
   session_destroy();
     
   
    return false;
}
else if($calc=='getworkflowsummery') {
    $input_array = array();
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['transaction_id'] = $_POST['transaction_id'];

    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=getworkflowsummery';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    // print_r($response->body);
    // return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='Question_check') {

    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'integration/crif_integration.php?call=user_authentication';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'supmit_crifscore')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=supmit_crifscore';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc == 'check_bankstateupload')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=check_bankstateupload';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='generate_crif') {

    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'integration/crif_integration.php?call=initiate_inquiry';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'activity_notes') {
   $input_array = [
        'tranid' =>  $_POST['tranid'],
        'from_gsk' =>  1
    ];
    $json_encoded_array = json_encode($input_array);
    $url = API_URL.'workflow/money_spot.php?call=activity_notes';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $result = json_decode($response->body,true);
    $result_data = json_encode($result);
    echo $result_data;
    return false;
}
else if($calc=='get_applicantname') {

    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'individual-partner/gsk_integration.php?call=get_applicantname';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if($calc=='decrypt_values') {
    $redirection_urlenc = $_POST["returnUrl"];
    $notifyyrlenc       = $_POST["notifyUrl"];
    $app_idenc          = $_POST["appId"];
    
    $encry_key = "L0@nw1ser";
    $cipher="AES-128-CBC";
    $redirection_urlenc = base64_decode($redirection_urlenc);
    $ciphertext_raw = openssl_decrypt($redirection_urlenc, $cipher, $encry_key, $options=OPENSSL_RAW_DATA, $encry_key);
    $redirection_url = utf8_decode($ciphertext_raw);
    
    $notifyyrlenc = base64_decode($notifyyrlenc);
    $ciphertext_raw = openssl_decrypt($notifyyrlenc, $cipher, $encry_key, $options=OPENSSL_RAW_DATA, $encry_key);
    $notifyyrl = utf8_decode($ciphertext_raw);
    
    $app_idenc = base64_decode($app_idenc);
    $ciphertext_raw = openssl_decrypt($app_idenc, $cipher, $encry_key, $options=OPENSSL_RAW_DATA, $encry_key);
    $app_id = utf8_decode($ciphertext_raw);
    
    $input_arr["returnUrl"]   = $redirection_url;
    $input_arr["notifyUrl"]   = $notifyyrl;
    $input_arr["appId"]   = $app_id;
    echo json_encode($input_arr,true);
    return false;
}
else if($calc=='getsupportdocumentlist') {
    $input_array = array();
    $input_array['user_type'] = $_POST['usertype'];
    $input_array['transaction_id'] = $_POST['transaction_id'];

    $json_encoded_array = json_encode($input_array,true);
    //  print_r($json_encoded_array);
    // return false;
    $url = API_URL.'workflow/workflow.php?call=getsupportdocumentlist';
       
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    print_r($response->body);
    return false;    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'uploadadddoc') {
    $input_array = array();
    $input_array['transaction_id'] = $_POST['transaction_id'];
    $input_array['user_id'] = $_POST['user_id'];
    $input_array['b2b_userid'] = $_POST['b2b_userid'];
    $input_array['nameid'] = $_POST['nameid'];
    $input_array['title'] = $_POST['title'];
    $input_array['doc_file'] = $_FILES["doc_file"]["name"];
    $image = $_FILES["doc_file"]["name"];
   
    $target_dir = "../../emitra_doc/";
    $target_dir1 = "../../emitra_doc";
    $target_file = $target_dir . basename($_FILES["doc_file"]["name"]);
    $randnum = rand(10,100000);
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $input_array['current_date'] = date("Y-m-d");
    $hashvalue = md5($data);
    $input_array['hashvalue'] = $hashvalue;
    //$filename = $randnum;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES['doc_file']['name'], PATHINFO_FILENAME);
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $dbfilename = $target_dir1.$finalfilename; 
    $dbfilename1 = $target_dir.$finalfilename; 
        // Check if image file is$filename a actual image or fake image
    //$check = getimagesize($_FILES["image_url"]["tmp_name"]);
     $json_encoded_array = json_encode($input_array,true);
     // print_r($json_encoded_array);
     // return false;
    
    if($imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "jpg" || $imageFileType == "bmp" || $imageFileType == "pdf"  ) {
        
     if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename1)){
         
         $url = API_URL.'workflow/workflow.php?call=uploadadditionaldoc';
         $response = \Httpful\Request::post($url)
         ->sendsJson()
         ->body($json_encoded_array)
         ->send();
         $result = $response->body;
         
         echo $response;
         return false;
     } else {
        $result=0;
        echo $result;
        return false;
    }
}
else{
    $result=0;
    echo $result;
    return false;
}

}
else if ($calc == 'bank_statementlist') { //#1708 company name
   
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=bank_statementlist';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if ($calc == 'bank_statementupload') { //#1708 company name
   
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=sift_upload';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    print_r($response->body);
    return false;
}
else if ($calc == 'sift_statuscheck') { 
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=sift_statuscheck';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}else if ($calc == 'get_bankstatedetailsnew') { 
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=get_bankstatement_detnew';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if ($calc == 'Get_crifresult') { 
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/crif_integration.php?call=Get_result';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if ($calc == 'Get_bankresult') { 
    $_POST["from_gsk"]=1;
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=Get_bankresult';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if($calc == 'bank_statementanalysis')
{
    $json_encoded_array = json_encode($_POST,true);
    $url = API_URL.'moratorium/process.php?call=bank_statementanalysis';
    $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
    
    $output = json_decode($response->body,true);
    echo json_encode($output,true);
    return false;
}
else if ($calc == 'get_bankstatedetails') { 
    $json_encoded_array = json_encode($_POST, true);
    $url = API_URL . 'integration/bank_statement.php?call=get_bankstatement_detnew';
    $response = \Httpful\Request::post($url)
    ->sendsJson()
    ->body($json_encoded_array)
    ->send();
    $response_arr = json_decode($response->body,true);
    echo $response->body;
    return false;
}
else if ($calc == 'get_bankstatement') { //#1708 company name
    // print_r($_FILES["myFile"]);
    // return false;
    if(isset($_FILES["myFile"])){
        foreach($_FILES["myFile"]["name"] as $fileey => $fileval){
            $input_array['myFile'][$fileey] = $fileval;
            $image = $fileval;
            $target_dir = "../../auditor.loanwiser.in/bank_statement/";
            $target_file = $target_dir . basename($fileval);
            $current_date = date("Y-m-d h:i:sa");
            $data= strtotime($current_date);
            $hashvalue = md5($data);
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $filename = pathinfo($fileval, PATHINFO_FILENAME);
            $filename = explode(".",$filename);
            $filename = $filename[0];
            $finalfilename = $filename.$data.'.'.$imageFileType;
            $input_array['finalfilename'][$fileey] = $finalfilename;
            $input_array['transaction_id'] = $_POST["transaction_id"];
            $input_array['pdf_password'] = $_POST["pdf_password"];
            $input_array['bank_list'] = $_POST["bank_list"];
            $input_array['relationship_type'] = $_POST["relationship_type"];
            $input_array['entity_id'] = $_POST["entity_id"];
            $input_array['bank_pass'] = $_POST["bank_pass"];
            $dbfilename = $target_dir.$finalfilename; 
            $input_array['upload_status'][$fileey]=0;
            if($moved = move_uploaded_file($_FILES["myFile"]["tmp_name"][$fileey], $dbfilename)){
                $input_array['upload_status'][$fileey]=1;
            }
        }
    }
    
    
        $json_encoded_array = json_encode($input_array, true);
        // echo $json_encoded_array;
        // return;
        $url = API_URL . 'integration/bank_statement.php?call=bank_statement';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        echo $response->body;
        return false;
    
    // echo $json_encoded_array;
    // return;
    
}
else if ($calc == 'upload_bankstate') {
    
    
    $target_dir = "../../auditor.loanwiser.in/bank_statement/";
    $target_file = $target_dir . basename($_FILES["doc_file"]["name"]);
    $current_date = date("Y-m-d h:i:sa");
    $data= strtotime($current_date);
    $hashvalue = md5($data);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $filename = pathinfo($_FILES["doc_file"]["name"], PATHINFO_FILENAME);
    $filename = explode(".",$filename);
    $filename = $filename[0];
    $finalfilename = $filename.$data.'.'.$imageFileType;
    $input_array['finalfilename'] = $finalfilename;
    $input_array['transaction_id'] = $_POST["transaction_id"];
    $input_array['relationship_type'] = $_POST["typecnt"]+1;
    $dbfilename = $target_dir.$finalfilename; 
    $input_array['upload_status']=0;
    $output["status"]="error";
    if($moved = move_uploaded_file($_FILES["doc_file"]["tmp_name"], $dbfilename)){
        $json_encoded_array = json_encode($input_array,true);
        $url = API_URL . 'integration/bank_statement.php?call=update_linkdata';
        $response = \Httpful\Request::post($url)
        ->sendsJson()
        ->body($json_encoded_array)
        ->send();
        $output = $response->body;
        $output = json_decode($output,true);
        $output["status"]="success";
    }
    
    echo json_encode($output,true);
    return false;
}

function SendMsg($mobileNumber, $message,$otp) {
   //Your authentication key
    $authKey = "153770AqYFQv9XI5926b9cc";
    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "LONWSR";
    $tempID = "1307161743116877224";
    // $mobileNumber = "8220402007";
    //API URL
     // return $opt;
    $url = "https://control.msg91.com/api/sendotp.php?authkey=".$authKey."&sender=".$senderId."&mobile=91".$mobileNumber."&message=".urlencode($message)."&otp=".$otp."&otp_length=5&DLT_TE_ID=".$tempID;
   
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
function SendMsgCons($mobileNumber, $message,$otp) {
   //Your authentication key
    $authKey = "153770AqYFQv9XI5926b9cc";
    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "LONWSR";
    $tempID = "1307161796166656914";
    // $mobileNumber = "8220402007";
    //API URL
     // return $opt;
    $url = "https://control.msg91.com/api/sendotp.php?authkey=".$authKey."&sender=".$senderId."&mobile=91".$mobileNumber."&message=".urlencode($message)."&otp=".$otp."&otp_length=5&DLT_TE_ID=".$tempID;
   
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
function SendMsgNew($mobileNumber, $message,$otp,$tempID) {
   //Your authentication key
    // $authKey = "153770AqYFQv9XI5926b9cc";
    $authKey = "153770AqYFQv9XI5926b9cc";
    $tempID = "1307161743116877224";
    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "LONWSR";
    // $mobileNumber = "918220402007";
    //API URL
     // return $opt;
    $url = "https://control.msg91.com/api/sendotp.php?authkey=".$authKey."&sender=".$senderId."&mobiles=91".$mobileNumber."&message=".urlencode($message)."&otp=".$otp."&otp_length=5&DLT_TE_ID=".$tempID;
    // urlencode($message);
    // $message = $otp." is your OTP for Loanwiser Individual partner Verification Process.";
    // $url = "https://api.msg91.com/api/v5/otp?template_id".$tempID."=&mobile=".$mobileNumber."&authkey=".$authKey."&otp=".$otp."&otp_length=5&extra_param=INDIVIDUAL";
//   authkey=value&mobiles=value&message=value&sender=value&otp=value&DLT_TE_ID=value
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, $url);
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    // $result = curl_exec($curl);
    // curl_close($curl);
    // return $result;
    
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_ENCODING, "");
    curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
    curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_POSTFIELDS, "{\"Value1\":\"INDIVIDUAL\"}");
    
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
      return "cURL Error #:" . $err;
    } else {
      return $response;
    }
    
    
}
function resendOtp($mobileNumber){
    //Your authentication key
    $authKey = "153770AqYFQv9XI5926b9cc";
    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "LONWSR";
    
    // //API URL
    // $url = "https://control.msg91.com/api/retryotp.php?authkey=153770AqYFQv9XI5926b9cc&mobile=917598231119&retrytype=voice";
    
    $url = "https://control.msg91.com/api/retryotp.php?authkey=".$authKey."&mobile=91".$mobileNumber."&retrytype=voice";
    // echo $url;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
function verifyOtp($mobileNumber,$otp_entered){
    //Your authentication key
    $authKey = "153770AqYFQv9XI5926b9cc";
    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "LONWSR";
    
    //API URL
    $url = "https://control.msg91.com/api/verifyRequestOTP.php?authkey=".$authKey."&mobile=91".$mobileNumber."&otp=".$otp_entered;
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
function GetSalariedViable($input_array,$language_obj)
{
        $input_array['user_id']=$_POST['user_id'];
        $input_array['transaction_id']=$_POST['transaction_id'];
        $input_array['subtask_id']=$_POST['subtask_id'];
        
        $input_array['loan_category']=$_POST['loan_category'];
        $input_array['loan_type']=$_POST['loan_type'];
        $input_array['loan_amount']=$_POST['loan_amount'];
        $input_array['applicant_value']=$applicant_value;
        $input_array['b2b_id']=$_POST['b2b_id'];
        $input_array['status_arr']=$language_obj;
        
        
        
        
        $input_array['per_pincode'] = $_POST['res_pincode'];
        
        
        
        $input_array_sal['member_name'] = $_POST['info_name'];
        $input_array_sal['current_home_duration'] = $_POST['live_in_res'];
        $input_array_sal['is_other_eranings'] = $_POST['is_other_eranings'];
        $input_array_sal['family_member_name'] = $_POST['family_member_name'];
        $input_array_sal['rel_income'] = $_POST['rel_income'];
        $input_array_sal['affordable_pay'] = $_POST['affordable_pay'];
        $input_array_sal['member_age'] = $_POST['age'];  
        $input_array_sal['has_pan'] = $_POST['has_pancard'];
        // $input_array_sal['pan_no'] = $_POST['pan_number']; //if is this Uncomment please add field in CustHist Table
        $input_array_sal['resident_status'] = $_POST['res_type'];
        $input_array_sal['has_emp_id'] = $_POST['has_emp_id'];
        $input_array_sal['monthly_income'] = $_POST['net_salary'];
        $input_array_sal['occupation'] = $_POST['occupation'];
        $input_array_sal['salary_mode'] = $_POST['salary_mode'];
        $input_array_sal['has_sb_account'] = $_POST['has_sb_account'];
        $input_array_sal['income_proof_type'] = $_POST['income_proof'];
        $input_array_sal['working_experience'] = $_POST['tot_work_experiance'];
        $input_array_sal['noofyearcompany'] = $_POST['work_experiance'];
        $input_array_sal['ofc_pincode'] = $_POST['work_pincode'];
        $input_array_sal['per_pincode'] = $_POST['res_pincode'];
         
        $family_income = $_POST['net_salary'][0]+$_POST['rel_income'][0];
        
        if($applicant_value == '1')
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['net_salary'][0]);
            $app_arr['app']['residence'] = $_POST['res_type']['0'];
            
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        
        }
        else
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['net_salary'][0]);
            $app_arr['app']['residence'] = $_POST['residence']['0'];
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $app_arr['coapp']['occuption'] = $_POST['occupation']['1'];
            $app_arr['coapp']['mothincome'] = str_replace(",","",$_POST['net_salary'][1]);
            $app_arr['coapp']['residence'] = $_POST['residence']['1'];
            $app_arr['coapp']['businesseg'] = 0;
            $app_arr['coapp']['businessproo'] = $_POST['bus_proof']['1'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true)); 
        }
        $input_array['appdetails']=$appde_arr;
        $input_array['family_det']=$input_array_sal;
        $input_array['family_income']=$family_income;
        
        $input_array['history_maint'] = $input_array_sal;
        $input_array['history_maint']['user_name'] = $input_array_sal['member_name'];
        $input_array['incomeprofapp'] = $_POST['income_proof'][0];
        $input_array['incomeprofcoapp'] = $_POST['income_proof'][1];
        unset($input_array['history_maint']['member_name']);
        return $input_array;
    
}


function GetSelfEmpViable($input_array,$language_obj)
{
        
        
         $input_array['user_id']=$_POST['user_id'];
        $input_array['transaction_id']=$_POST['transaction_id'];
        $input_array['subtask_id']=$_POST['subtask_id'];
        
        $input_array['loan_category']=$_POST['loan_category'];
        $input_array['loan_amount']=str_replace(",","",$_POST['loan_amount']);
        $input_array['loan_type']=$_POST['loan_type'];
        $input_array['applicant_value']=$applicant_value;
        $input_array['b2b_id']=$_POST['b2b_id'];
        $input_array['status_arr']=$language_obj;
        
        $input_array['per_pincode'] = $_POST['res_pincode'];
       
        $input_array['info'] = $_POST['info_name'];
        
        
        $input_array_self['member_name'] = $_POST['info_name'];  
        $input_array_self['member_age'] = $_POST['age'];  
        $input_array_self['has_pan'] = $_POST['has_pancard']; 
        // $input_array_self['pan_no'] = $_POST['pan_number'];
        $input_array_self['resident_status'] = $_POST['res_type'];
        $input_array_self['employee_count'] = $_POST['bus_employee_count'];
        $input_array_self['office_setup'] = $_POST['office_setup'];
        $input_array_self['bus_employment_type'] = $_POST['bus_employment_type'];
        $input_array_self['bus_vocation'] = $_POST['business_vocation'];
        
        $input_array_self['vintagedoc'] = $_POST['bus_proof'];
        $input_array_self['income_proof_type'] = $_POST['bus_income_proof']; // income_proof to income_proof_type
        $input_array_self['vocation'] = $_POST['ind_vocation']; // vocation
        
        $input_array_self['vehicle_type'] = $_POST['vehicle_type'];//
        $input_array_self['no_of_vehicles'] = $_POST['no_of_vehicles'];//
        $input_array_self['noofyearcompany'] = $_POST['no_of_years_work'];//
        $input_array_self['avg_mon_income'] = $_POST['avg_mon_income'];// 
        $input_array_self['work_vocation'] = $_POST['work_vocation'];
        $input_array_self['acres'] = $_POST['acres'];
        $input_array_self['crop_types'] = $_POST['crop_types'];
        $input_array_self['annual_income'] = $_POST['annual_income'];
        $input_array_self['daily_income'] = $_POST['daily_income'];
        $input_array_self['no_of_animals'] = $_POST['no_of_animals'];
        $input_array_self['no_of_litres'] = $_POST['no_of_litres'];
        $input_array_self['sell_milk_to'] = $_POST['sell_milk_to'];
        $input_array_self['no_of_birds'] = $_POST['no_of_birds'];
        $input_array_self['company_supplied'] = $_POST['company_supplied'];
        $input_array_self['selling_price'] = $_POST['selling_price'];
        $input_array_self['profit'] = $_POST['profit'];
        $input_array_self['monthly_profit'] = $_POST['monthly_profit'];
        $input_array_self['is_franchise'] = $_POST['is_franchise'];
        $input_array_self['monthly_income'] = $_POST['monthly_income'];
        $input_array_self['setup_investment'] = $_POST['bus_setup_investment'];
        $input_array_self['value_of_stock'] = $_POST['value_of_stock'];
        $input_array_self['monthly_sales'] = $_POST['monthly_sales'];
        $input_array_self['value_of_machineries'] = $_POST['value_of_machineries'];
        $input_array_self['assets'] = $_POST['assets'];
        
        $input_array_self['current_home_duration'] = $_POST['live_in_res'];
        $input_array_self['is_other_eranings'] = $_POST['is_other_eranings'];
        $input_array_self['family_member_name'] = $_POST['family_member_name'];
        $input_array_self['rel_income'] = $_POST['rel_income'];
        
         $input_array_self['per_pincode'] = $_POST['res_pincode'];
        $input_array_self['office_res'] = $_POST['office_res'];
        
        $input_array_self['about_company'] = $_POST['about_company'];
        
        foreach($_POST['office_setup'] as $Okey => $Oval)
        {
            if($Oval == '1')
            {
                $_POST['ofc_pincode'][$Okey] = $_POST['res_pincode'][$Okey];
            }
            else
            {
                $_POST['ofc_pincode'][$Okey] = $_POST['office_pincode'][$Okey];
            }
        }
        $input_array_self['ofc_pincode'] = $_POST['office_pincode'];
        
        
        if($applicant_value == '1')
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['net_salary'][0]);
            $app_arr['app']['residence'] = $_POST['res_type']['0'];
            
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        
        }
        else
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['net_salary'][0]);
            $app_arr['app']['residence'] = $_POST['residence']['0'];
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $app_arr['coapp']['occuption'] = $_POST['occupation']['1'];
            $app_arr['coapp']['mothincome'] = str_replace(",","",$_POST['net_salary'][1]);
            $app_arr['coapp']['residence'] = $_POST['residence']['1'];
            $app_arr['coapp']['businesseg'] = 0;
            $app_arr['coapp']['businessproo'] = $_POST['bus_proof']['1'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true)); 
        }
        
        $input_array['appdetails']=$appde_arr;
        $input_array['family_det']=$input_array_self;
        
        $input_array['history_maint'] = $input_array_self;
        $input_array['history_maint']['user_name'] = $input_array_self['member_name'];
        $input_array['incomeprofapp'] = $_POST['income_proof'][0];
        $input_array['incomeprofcoapp'] = $_POST['income_proof'][1];
        unset($input_array['history_maint']['member_name']);
        return $input_array;
    
}


function GetFamilyDet($input_array,$language_obj)
{
        $input_array['user_id']=$_POST['user_id'];
        $input_array['transaction_id']=$_POST['transaction_id'];
        $input_array['subtask_id']=$_POST['subtask_id'];
        
        $input_array['loan_category']=$_POST['loan_category'];
        $input_array['loan_type']=$_POST['loan_type'];
        $input_array['loan_amount']=$_POST['loan_amount'];
        $input_array['applicant_value']=$applicant_value;
        $input_array['b2b_id']=$_POST['b2b_id'];
        $input_array['status_arr']=$language_obj;
        
        $input_array['per_pincode'] = $_POST['res_pincode'];
       
        $input_array['info'] = $_POST['info_name'];
        
        
        $FamilyArr['member_name'] = $_POST['info_name'];
        $FamilyArr['current_home_duration'] = $_POST['live_in_res'];
        $FamilyArr['is_other_eranings'] = $_POST['is_other_eranings'];
        $FamilyArr['family_member_name'] = $_POST['family_member_name'];
        $FamilyArr['rel_income'] = $_POST['rel_income'];
        $FamilyArr['affordable_pay'] = $_POST['affordable_pay'];
        $FamilyArr['member_age'] = $_POST['age'];  
        $FamilyArr['has_pan'] = $_POST['has_pancard'];
        // $input_array_sal['pan_no'] = $_POST['pan_number']; //if is this Uncomment please add field in CustHist Table
        $FamilyArr['resident_status'] = $_POST['res_type'];
        $FamilyArr['has_emp_id'] = $_POST['has_emp_id'];
        $FamilyArr['monthly_income'] = $_POST['net_salary'];
        $FamilyArr['occupation'] = $_POST['occupation'];
        $FamilyArr['salary_mode'] = $_POST['salary_mode'];
        $FamilyArr['has_sb_account'] = $_POST['has_sb_account'];
        $FamilyArr['income_proof_type'] = $_POST['income_proof'];
        $FamilyArr['working_experience'] = $_POST['tot_work_experiance'];
        $FamilyArr['noofyearcompany'] = $_POST['work_experiance'];
        $FamilyArr['ofc_pincode'] = $_POST['work_pincode'];
        $FamilyArr['per_pincode'] = $_POST['res_pincode'];
         
         
        $FamilyArr['employee_count'] = $_POST['bus_employee_count'];
        $FamilyArr['office_setup'] = $_POST['office_setup'];
        $FamilyArr['bus_employment_type'] = $_POST['bus_employment_type'];
        $FamilyArr['bus_vocation'] = $_POST['business_vocation'];
        
        $FamilyArr['vintagedoc'] = $_POST['bus_proof'];
        $FamilyArr['income_proof_type'] = $_POST['income_proof']; // income_proof to income_proof_type
        $FamilyArr['vocation'] = $_POST['ind_vocation']; // vocation
        
        $FamilyArr['vehicle_type'] = $_POST['vehicle_type'];//
        $FamilyArr['no_of_vehicles'] = $_POST['no_of_vehicles'];//
        
         $FamilyArr['noofyearcompany'] = $_POST['work_experiance'];//
        
        $FamilyArr['avg_mon_income'] = $_POST['avg_mon_income'];// 
        $FamilyArr['work_vocation'] = $_POST['work_vocation'];
        $FamilyArr['acres'] = $_POST['acres'];
        $FamilyArr['crop_types'] = $_POST['crop_types'];
        $FamilyArr['annual_income'] = $_POST['annual_income'];
        $FamilyArr['daily_income'] = $_POST['daily_income'];
        $FamilyArr['no_of_animals'] = $_POST['no_of_animals'];
        $FamilyArr['no_of_litres'] = $_POST['no_of_litres'];
        $FamilyArr['sell_milk_to'] = $_POST['sell_milk_to'];
        $FamilyArr['no_of_birds'] = $_POST['no_of_birds'];
        $FamilyArr['company_supplied'] = $_POST['company_supplied'];
        $FamilyArr['selling_price'] = $_POST['selling_price'];
        $FamilyArr['profit'] = $_POST['profit'];
        $FamilyArr['monthly_profit'] = $_POST['monthly_profit'];
        $FamilyArr['is_franchise'] = $_POST['is_franchise'];
        $FamilyArr['monthly_income'] = $_POST['net_salary'];
        $FamilyArr['setup_investment'] = $_POST['bus_setup_investment'];
        $FamilyArr['value_of_stock'] = $_POST['value_of_stock'];
        $FamilyArr['monthly_sales'] = $_POST['monthly_sales'];
        $FamilyArr['value_of_machineries'] = $_POST['value_of_machineries'];
        $FamilyArr['assets'] = $_POST['assets'];
        
        $FamilyArr['current_home_duration'] = $_POST['live_in_res'];
        $FamilyArr['is_other_eranings'] = $_POST['is_other_eranings'];
        $FamilyArr['family_member_name'] = $_POST['family_member_name'];
        $FamilyArr['rel_income'] = $_POST['rel_income'];
        
         $FamilyArr['per_pincode'] = $_POST['res_pincode'];
        $FamilyArr['office_res'] = $_POST['office_res'];
        
        $FamilyArr['about_company'] = $_POST['about_company'];
         
         
        $family_income = $_POST['net_salary'][0]+$_POST['rel_income'][0];
        
        
            foreach($_POST['office_setup'] as $Okey => $Oval)
            {
                if($Oval == '1')
                {
                    $_POST['ofc_pincode'][$Okey] = $_POST['res_pincode'][$Okey];
                }
                else
                {
                    $_POST['ofc_pincode'][$Okey] = $_POST['office_pincode'][$Okey];
                }
            }
            $FamilyArr['ofc_pincode'] = $_POST['office_pincode'];
            
        
        
        
        if($applicant_value == '1')
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$FamilyArr['monthly_income'][0]);
            $app_arr['app']['residence'] = $_POST['res_type']['0'];
            
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        
        }
        else
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$FamilyArr['monthly_income'][0]);
            $app_arr['app']['residence'] = $_POST['residence']['0'];
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $app_arr['coapp']['occuption'] = $_POST['occupation']['1'];
            $app_arr['coapp']['mothincome'] = str_replace(",","",$FamilyArr['monthly_income'][1]);
            $app_arr['coapp']['residence'] = $_POST['residence']['1'];
            $app_arr['coapp']['businesseg'] = 0;
            $app_arr['coapp']['businessproo'] = $_POST['bus_proof']['1'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true)); 
        }
       
        $input_array['appdetails']=$appde_arr;
        $input_array['family_det']=$FamilyArr;
        $input_array['family_income']=$family_income;
        
        $input_array['history_maint'] = $FamilyArr;
        $input_array['history_maint']['user_name'] = $FamilyArr['member_name'];
        $input_array['incomeprofapp'] = $_POST['income_proof'][0];
        $input_array['incomeprofcoapp'] = $_POST['income_proof'][1];
        unset($input_array['history_maint']['member_name']);
        return $input_array;
        

}


function GetFamilyDetEligible($input_array,$language_obj)
{
   
        
        $input_array['user_id']=$_POST['user_id'];
        $input_array['transaction_id']=$_POST['transaction_id'];
        $input_array['subtask_id']=$_POST['subtask_id'];
        
        $input_array['applicant_value']=$applicant_value;
        $input_array['b2b_id']=$_POST['b2b_id'];
        $input_array['status_arr']=$language_obj;
        
        if($applicant_value == '1')
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['net_salary'][0]);
            $app_arr['app']['residence'] = $_POST['res_type']['0'];
            
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        
        }
        else
        {
            $app_arr['app']['occuption'] = $_POST['occupation']['0'];
            $app_arr['app']['mothincome'] = str_replace(",","",$_POST['net_salary'][0]);
            $app_arr['app']['residence'] = $_POST['residence']['0'];
            $app_arr['app']['businesseg'] = 0;
            $app_arr['app']['businessproo'] = $_POST['bus_proof']['0'];
            $app_arr['coapp']['occuption'] = $_POST['occupation']['1'];
            $app_arr['coapp']['mothincome'] = str_replace(",","",$_POST['net_salary'][1]);
            $app_arr['coapp']['residence'] = $_POST['residence']['1'];
            $app_arr['coapp']['businesseg'] = 0;
            $app_arr['coapp']['businessproo'] = $_POST['bus_proof']['1'];
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true)); 
        }
        
        
        
        $FamilyArr['company_name'] = $_POST['company_name'];  
        $FamilyArr['company_type'] = $_POST['company_type'];  
        $FamilyArr['designation'] = $_POST['designation'];
        $FamilyArr['employee_count'] = $_POST['employees_count'];
        $FamilyArr['employee_type'] = $_POST['employee_type'];
        $FamilyArr['perm_res_pincode'] = $_POST['perm_res_pincode'];
        $FamilyArr['rel_address'] = $_POST['rel_address'];
        $FamilyArr['perm_residence'] = $_POST['perm_residence'];
        $FamilyArr['own_house_relative'] = $_POST['own_house_relative'];
        $FamilyArr['is_epf_deduct'] = $_POST['is_epf_deduct'];
        
        foreach($_POST['res_type'] as $Pkey => $Pval)
        {
            if($Pval == '2')
            {
                $_POST['address_proof'][$Pkey] = $_POST['addr_proof_rent'][$Pkey];
            }
            else
            {
                $_POST['address_proof'][$Pkey] = $_POST['addr_proof_own'][$Pkey];
            }
        }
        $FamilyArr['address_proof'] = $_POST['address_proof'];
        if($_POST['loan_category']==2)
        {
            $app_arr['app'] = $FamilyArr;
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        }
        $input_array['appdetails']=$appde_arr;
        $input_array['family_det']=$FamilyArr;
        
         $input_array['history_maint'] = $FamilyArr;
        
        
        
    
        $input_array['user_id']=$_POST['user_id'];
        $input_array['transaction_id']=$_POST['transaction_id'];
        $input_array['subtask_id']=$_POST['subtask_id'];
        
        $input_array['applicant_value']=$applicant_value;
        $input_array['b2b_id']=$_POST['b2b_id'];
        $input_array['status_arr']=$language_obj;
        
       
        
        
        
        $FamilyArr['purpercent_bank'] = $_POST['purpercent_bankacc'];  //
        // $input_array_self['purpercent_cash'] = 100 - $_POST['purpercent_bankacc'];  //
        
        $FamilyArr['purpercent_gst'] = $_POST['purpercent_gstbill'];  //
        // $input_array_self['purpercent_katcha'] = 100-$_POST['purpercent_gstbill'];  //
        
        $FamilyArr['salepercent_gst'] = $_POST['salepercent_gstbill'];//
        // $input_array_self['salepercent_katcha'] = 100-$_POST['salepercent_gstbill'];//
        
        $FamilyArr['incomepercent_bank'] = $_POST['incomepercent_bank'];//
        // $input_array_self['incomepercent_cash'] = 100-$_POST['incomepercent_bank'];//
        
        foreach($_POST['res_type'] as $Pkey => $Pval)
        {
            if($Pval == '2')
            {
                $_POST['address_proof'][$Pkey] = $_POST['addr_proof_rent'][$Pkey];
            }
            else
            {
                $_POST['address_proof'][$Pkey] = $_POST['addr_proof_own'][$Pkey];
            }
        }
        
        $FamilyArr['avg_monthlybal'] = $_POST['avg_bankbalance'];//
        // $input_array_self['address'] = $_POST['address'];//
        $FamilyArr['is_guarantor_provide'] = $_POST['is_guarantor_provide'];//
        $FamilyArr['reference_name'] = $_POST['reference_name'];//
        $FamilyArr['reference_num'] = $_POST['reference_mobile'];//
        $FamilyArr['perm_res_pincode'] = $_POST['perm_res_pincode'];//
        $FamilyArr['perm_residence'] = $_POST['perm_residence'];//
        $FamilyArr['address_proof'] = $_POST['address_proof'];//
        $FamilyArr['bussiness_registeration'] = $_POST['bussiness_registeration'];//
        
        
        if($_POST['loan_category']==2)
        {
            $app_arr['app'] = $FamilyArr;
            $appde_arr = str_replace('"',"'",json_encode($app_arr,true));
        }
        $input_array['appdetails']=$appde_arr;
        $input_array['family_det']=$FamilyArr;
        
        $input_array['history_maint'] = $FamilyArr;
        
    
        return $input_array;

}
?>