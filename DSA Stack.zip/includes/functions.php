<?php
function get_vh_model($inputs)
{
    $url = API_URL.'individual-partner/gsk_integration.php?call=vh_modal';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function Get_UserDetails($input) {
    $url = API_URL.'moratorium/process.php?call=get_userdetails';
     $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getUserInfo($input) {
    // return $input;
    $url = API_URL.'gsk-integration/gsk_integration.php?call=getUserInfo';
     $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function partner_mail_verify($input) {

    $url = API_URL.'workflow/partner.php?call=partner_mail_verify';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function get_vh_brand($inputs)
{
    $url = API_URL.'individual-partner/gsk_integration.php?call=vh_brand';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
#New functions 22-11-2019
function status_display($inputs)
{
    $url = API_URL.'individual-partner/gsk_integration.php?call=status_display';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function getAsklist($inputs)
{
    $url = API_URL.'individual-partner/gsk_integration.php?call=getAsklist';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function familydetails($inputs)
{
    $url = API_URL.'individual-partner/process_functions.php?call=familydetails';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function get_promos($inputs)
{
    $url = API_URL.'individual-partner/process_functions.php?call=get_promos';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function get_stageresult($inputs)
{
    $url = API_URL.'individual-partner/process_functions.php?call=gsk_status_view';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function getappinfo($inputs)
{
    $url = API_URL.'individual-partner/process_functions.php?call=getappinfo';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function Update_Paymentdet($inputs)
{
    $url = API_URL.'individual-partner/gsk_integration.php?call=payment_status';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $response_data = json_decode($response->body,true);
    return $response_data;
}
function getPayStatus($inputs)
{
    $url = API_URL.'individual-partner/process_functions.php?call=getPayStatus';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $response_data = json_decode($response->body,true);
    return $response_data;
}
function GetPaymentList($inputs)
{
    $url = API_URL.'individual-partner/process_functions.php?call=get_payschedule';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $response_data = json_decode($response->body,true);
    return $response_data;
}
function KIOSKuser($inputs) {
    $url = API_URL.'individual-partner/process_functions.php?call=gskusers';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function ProductOffered($inputs) {
    $url = API_URL.'individual-partner/process_functions.php?call=eligible_products';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function getloantypefilter($inputs) {
    $url = API_URL.'individual-partner/process_functions.php?call=getloantypefilter';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function Get_Propertytitle($input) {

    $url = API_URL.'individual-partner/process_functions.php?call=get_propertytitle';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function Bank_List($input) {

    $url = API_URL.'workflow/offers.php?call=bank_list';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
# Velu - EMITRA Create Transaction
function KIOSKEligible($inputs) {
    $url = API_URL.'emitra/emitra.php?call=KIOSKEligible';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function insertEmitraTransaction($inputs) {
    $url = API_URL.'emitra/emitra.php?call=insertemitratrans';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function Get_Area($inputs) {
    $url = API_URL.'loanwiser/loanwiser.php?call=getarea';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($inputs)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}

function Get_Businessproof($inputs) {
    $url = API_URL.'emitra/emitra.php?call=get_businessproof';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($inputs)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getloancategory($input) {

    $url = API_URL.'meeseva/meeseva.php?call=getloancategory';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getloancategorynew($input) {

    $url = API_URL.'meeseva/meeseva.php?call=getloancategorynew';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function updateEmitraTransaction($inputs) {
    $url = API_URL.'emitra/emitra.php?call=updateemitratrans';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function getEmitraTransaction($inputs) {
    $url = API_URL.'emitra/emitra.php?call=getemitratrans';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
# END Emitra


function applicationusers($input) {

	$url = API_URL.'workflow/workflow.php?call=applicationusers';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function applicationdetails($input) {

    $url = API_URL.'workflow/homeloan.php?call=applicationdetails';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function applicationdetailsnew($input) {

    $url = API_URL.'workflow/homeloan.php?call=applicationdetailsnew';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}

function Get_PartnerDet($inputs) {
    $url = API_URL.'individual-partner/gsk_integration.php?call=Get_PartnerDet';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($inputs)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function Check_Partner($inputs) {
    $url = API_URL.'individual-partner/gsk_integration.php?call=check_partner';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($inputs)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function DownloadCountUpdate($data) {

    $url = API_URL.'workflow/workflow.php?call=DownloadCountUpdateGovePaidSave';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($data)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getSupportDoc($input) {

    $url = API_URL.'workflow/workflow.php?call=getSupportDoc';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function notificount($data) {

    $url = API_URL.'workflow/workflow.php?call=notificount';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($data)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getlistofdocviewer($data) {

    $url = API_URL.'workflow/workflow.php?call=getlistofdocviewer';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($data)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function checkuservalidation($data) {

    $url = API_URL.'workflow/workflow.php?call=checkuservalidation';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($data)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getdocumentviewer($data) {

    $url = API_URL.'workflow/workflow.php?call=getdocumentviewer';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($data)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getdocumentchecklist($data) {

    $url = API_URL.'workflow/workflow.php?call=getdocumentlist';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($data)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function BrowsingCenterLogin($input){
    $url = API_URL.'workflow/loginregister.php?call=browsinguserlogin';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
    $result = $response->body;
   
    if ($result != 'null') {
            $b2bUser = json_decode($result);
            $_SESSION['browinfo'] = $b2bUser;
             $_SESSION['b2b_userid'] =  $b2bUser->id;
            $_SESSION['brow_name'] = $b2bUser->contact_person;
            $_SESSION['brow_emailid'] = $b2bUser->email_id;
            return 1;
        } else {
            return 0;
        }
    
}
function checkalreadyuser($input){
     $url = API_URL.'workflow/browsing.php?call=checkalreadyuser';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getBrowsingCenterUser($input) {

    $url = API_URL.'workflow/loginregister.php?call=getbrowsingcenteruser';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getDocumentList($input){
     $url = API_URL.'workflow/loginregister.php?call=getdocumentlist';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
    
}
function getAgreementList($input){
     $url = API_URL.'workflow/loginregister.php?call=getAgreementList';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
    
}
function getProgressStatus($input){
     $url = API_URL.'workflow/loginregister.php?call=getProgressStatus';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
    
}

function getState($input) {

    $url = API_URL.'workflow/workflow.php?call=getState';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getcity($input) {
    $url = API_URL.'workflow/workflow.php?call=getcity&state_value=allcity';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->send();   
    
      
        
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getpromoemitra($input){
     $url = API_URL.'emitra/emitra.php?call=getpromoemitra';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
    
}function changestatus($input){
     $url = API_URL.'emitra/emitra.php?call=changestatus';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send(); 
          
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
    
}
function getadditionaldocument($input) {
    $url = API_URL.'workflow/workflow.php?call=getadditionaldocument';
     $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getdistrict($input) {

    $url = API_URL.'meeseva/meeseva.php?call=getdistrict';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getadditionaldoclist($input) {
    $url = API_URL.'workflow/workflow.php?call=getadditionaldoclist';
     $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getloantypename($input) {

    $url = API_URL.'meeseva/meeseva.php?call=getloantypename';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function subtaskcomplete($input) {

    $url = API_URL.'workflow/workflow.php?call=subtaskcompletepay';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $response->body;
}
function commissionearned($inputs) {
    $url = API_URL.'workflow/workflow.php?call=commissionearned';
    $response = \Httpful\Request::post($url)
            ->sendsJson()
            ->body($inputs)
            ->send();  
    $userList = json_decode($response->body,true);
    return $userList;
}
function gskprofile($input) {
 // return $input;
    $url = API_URL.'individual-partner/process_functions.php?call=view_profile';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getmakeby_vh($input)
{
    // return $inputs;
    $url = API_URL.'workflow/callcenternew.php?call=getvh_makeby';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($input)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function getmodel_vh($inputs)
{
    // return $inputs;
    $url = API_URL.'workflow/callcenternew.php?call=getmodel';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($inputs)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
}
function viable_report($inputs)
{
     $url = API_URL . 'individual-partner/process_functions.php?call=viable_errormessage';
    $response = \Httpful\Request::post($url) 
        ->sendsJson()
        ->body($inputs)
        ->send();   
    $result = $response->body;
    $arr = json_decode($result,true);
    return $arr;
    
}
?>