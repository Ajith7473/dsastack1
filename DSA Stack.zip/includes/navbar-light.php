
        <header class="">
        	<nav class="navbar navbar-expand-lg">
        		<div class="container">
        			<a class="navbar-brand" href="https://dsastack.in/">
        				<img src="images/dsastack-logo.png" width="180px" alt="DSA Stack Loan Facilitation MarketPlace">
        			</a>
        			<button class="navbar-toggler navbar-light bg-light" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">	<span class="navbar-toggler-icon"></span>
        			</button>
        			<div class="collapse navbar-collapse" id="navbarNav">
        				<ul class="navbar-nav ml-auto">
        					<li style="position: relative" class="nav-item <?php echo ($page == 'Loanwiser')?" active ":" " ?>">	
        					    <a class="nav-link" href="index.php">Home</a>
        						<div class="bottomline"></div>
        					</li>
        					<li class="nav-item dropdown <?php echo ($page == 'Corporates' or $page == 'IndividualsWeb' or $page == 'IndividualsMobile' or $page == 'Startups')?" active ":" " ?>">	
        					    <a class="nav-link" href="#sectionThree">Benefits</a>
        					    <div class="bottomline"></div>
        					</li>
        					<li style="position: relative" class="nav-item <?php echo ($page == 'Financial')?" active ":" " ?>">	
        					    <a class="nav-link" href="#sectionFour">How it Works</a>
        						<div class="bottomline"></div>
        					</li>
        					<li style="position: relative" class="nav-item <?php echo ($page == 'AboutUs')?" active ":" " ?>">	
        					    <a class="nav-link" href="#sectionSix">Pricing</a>
        						<div class="bottomline"></div>
        					</li>
        					<li style="position: relative" class="nav-item <?php echo ($page == 'ContactUs')?" active ":" " ?>">	
        					    <a class="nav-link" href="#Contact-Form">Demo</a>
        						<div class="bottomline"></div>
        					</li>
        					<!--<li style="position: relative" class="nav-item">	-->
        					<!--    <a class="nav-link" href="Individual-Partner-WebApp.php?req=login" target="_blank">Individual Partner Login</a>-->
        					<!--	<div class="bottomline"></div>-->
        					<!--</li>-->
        				</ul>
        			</div>
        		</div>
        	</nav>
        </header>