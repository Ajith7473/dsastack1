<?php
require_once('class.phpmailer.php');

function propwiserMail($from,$to,$subject,$message)
{
	$mail = new PHPMailer(); 

	$body = $message;
	$mail->SetFrom($from,"Propwiser");
	$mail->AddReplyTo($from,"Propwiser");
	$mail->AddAddress($to);
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	if(!$mail->Send()) 
	{
		return $mail->ErrorInfo;
	} 
	else 
	{
		return "0";
	}
}

function propwiserMailadmin($from,$to,$subject,$message,$username)
{
	$mail = new PHPMailer(); 

	$body = $message;
	$mail->SetFrom($from,$username);
	$mail->AddReplyTo($from,$username);
	$mail->AddAddress($to);
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	if(!$mail->Send()) 
	{
		return $mail->ErrorInfo;
	} 
	else 
	{
		return "0";
	}
}

function propwiserMailSpecial($from,$to,$subject,$message,$replyto,$username,$attachment)
{
	$mail = new PHPMailer();
	$mail->IsSMTP(); // Using SMTP.
	$mail->CharSet = 'utf-8';
	$mail->SMTPAuth = false; // Enables SMTP authentication.
	$mail->Host = "localhost"; // SMTP server host.

	$body = $message;
	$mail->addReplyTo($replyto,$username);
	$mail->SetFrom($from,"Propwiser");	
	$mail->AddAddress($to,"");
	$mail->AddCC($replyto,$username);
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	if ($attachment != '') 
	{
		$mail->AddAttachment($attachment);
	}	

	if(!$mail->Send()) 
	{
		return $mail->ErrorInfo;
	} 
	else 
	{
		if ($attachment != '') 
		{
			unlink($attachment);
		}
		return "0";
	}
}
?>