<?php
/*
	$host = "192.168.0.109";
	$db = "trackprop8783";
    $uname = "propwiser";
	$pwd = "inforvio_trakprop";
*/
	$host = 'localhost';
	$db = 'inforvio_propcalcv1';
	$uname = 'inforvio_calcusr';
	$pwd = 'z~lGtDJ@eTm;';
	
$con = mysqli_connect($host,$uname,$pwd,$db);
?>