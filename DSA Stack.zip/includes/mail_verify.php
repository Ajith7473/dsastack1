<?php 

$admin_mail = 'info@loanwiser.in';
$today = date('Y-m-d H:i:s');
require_once('class.phpmailer.php');

include_once('config.php');
include_once("mail_functions.php");

$inputs = json_decode(file_get_contents('php://input'),true);

    
    $contact_id = $inputs['b2b_id'];
	$contact_email = $inputs['email'];
	$contact_name = $inputs['name'];
	$contact_mobile = $inputs['mobile'];
	$partner_code = $inputs['partner_code'];
	$company_name = $inputs['company_name'];
	$address = $inputs['profile_address'].", ".$inputs['district_name'].", ".$inputs['state_name'].", ".$inputs['pincode'];
	$from = 'noreply@loanwiser.in';
	$date = date("M d, Y");
	$to = $contact_email;
// 	$to = "ranjeeth@loanwiser.in";
	$lnk_gen = 'https://loanwiser.in/Email-Verification.php?b2b_id='.$contact_id.'&mail_verify=1';
	$subject = "Email Verfication for Loanwiser Partner Web Portal";
	$click_here = "Click here to Verify Email";
	$heading = "Thank you for Registering with Loanwiser Partner ";
	if($inputs['send_mail'] == "reset")
	{
	   $subject = "Reset Password Link for Loanwiser Partner Web Portal"; 
	   $lnk_gen = 'https://loanwiser.in/Reset-Password.php?b2b_id='.$contact_id.'&mail_verify=1';
	   $click_here = "Click here to Reset the Password";
	   $heading = "We’ve received a request to reset the password for your Loanwiser Partner web portal account";
	}
	$message = file_get_contents('reg_verify.php');
	$message = str_replace("**b2b_id**",$lnk_gen,$message);
	$message = str_replace("**name**",$contact_name,$message);
	$message = str_replace("**email**",$contact_email,$message);
	$message = str_replace("**mobile**",$contact_mobile,$message);
	$message = str_replace("**partner_code**",$partner_code,$message);
	$message = str_replace("**date**",$date,$message);
	$message = str_replace("**click_here**",$click_here,$message);
	$message = str_replace("**heading**",$heading,$message);
	$message = str_replace("**partner_type**",$inputs["source_name"],$message);
	$message = str_replace("**address**",$address,$message);
	$message = str_replace("**company_name**",$company_name,$message);
	$loanwiser_mail = loanwiserMailadmin($from,$to,$subject,$message,$contact_name);

	if($loanwiser_mail == '0')
	{
		echo '0';
		return false;
	} 
	else
	{
		echo '1';
		return false;
	}


function loanwiserMailadmin($from,$to,$subject,$message,$username)
{
    
    $username = 'Loanwiser';
	$mail = new PHPMailer(); 

	$body = $message;
	$mail->SetFrom($from,$username);
	$mail->AddReplyTo($from,$username);
	$mail->AddAddress($to);
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	if(!$mail->Send()) 
	{
		return $mail->ErrorInfo;
	} 
	else 
	{
		return "0";
	}
}
?>