<script id="documentcklist_template" type="x-handlebars-template">
<center><p class="p1" style="font-size: 18px!important;color: #2699FB!important"><b>Note:</b> Your progress is saved. You can login again using the same mobile number to complete the document upload process, anytime.</p>
<p class="p1" style="font-size: 18px!important;color: #2699FB!important">Complete the document upload step at the earliest for faster loan processing.</p></center>
<div class="container-fluid pt-5">
    <div class="bankstate_pdf {{#ifCond this.loan_categoryid "1"}}d-none{{else}}{{/ifCond}} ">
    	<div class="col-lg-4 col-md-6 m-auto pt-4 pb-4 pr-0 pl-0 box1 text-center bankstate_manual ">
    		<p class="heading">Please download a bank statement for the period 01.01.2020 to <?php echo date("d.m.Y"); ?>  from your bank's internet login portal or mobile app and upload here.</p>
    		<p class="heading" style="font-weight: 400!important">(PDF Format)</p>
    		<div class="bank_statementdiv">
    		{{#ifCond this.banlstate_status 1}}
        		{{#each this.banlstate_arr}}
            		<div class="fileDiv mt-2" style="background-color: #F1F9FF" >
            			<a target="_blank" href="{{url}}"><p class="fileName">{{file_name}}</p></a>
            		</div>
        		{{/each}}
    		{{/ifCond}}
    		</div>
    		<form class="upload pt-4" id="bank_statementdetails" enctype="multipart/form-data">
    		    <div class="form-group pr-4 pl-4 pb-4">	
                	<label for="" style="float: left!important;font-size: 16px!important;font-weight: 500;!important;color: #464646!important;">PDF Password (if any)</label>
                	<div class="input-group">
                    	<input type="text" name="pdf_password" id="password" style="border: 2px solid #E4E4E4!important;background-color: #F9FBFD!important;font-size: 17px!important;font-weight: 500;!important;color: #464646!important;" class="form-control password " >
                    	
                	</div>
            	</div>
    			<div align="center">
    				<label  class="label_content" for="file">Add Document <span style="font-size: 20px;line-height:0;font-weight: 700">+</span></label>
    				<input type="file" name="myFile[]" class="form-control-file file_uploaddet" multiple id="file">
    			</div>
    		</form>	
    	</div>
    	<div class="col-lg-4 col-md-6 m-auto pt-4 pb-4 pr-0 pl-0 text-center bankstate_manual">
            <p  style="font-weight: 600!important">or</p>
            <a class="netbaning_upload" style="color:#D34D53!important;font-weight:800!important; text-decoration: underline;cursor: context-menu;">Upload Using Net Banking</a>
            <p style="color:#002B5D!important">(Securely login and upload using Net Banking integration)</p>
        </div>
        <div class="col-lg-4 col-md-6 m-auto pt-4 pb-4 pr-0 pl-0  text-center bankstate_iframe d-none">
            <iframe src="" class="iframe_banstate" onload="iframe_banstate();" ></iframe>
        </div>
        <div class="col-lg-4 col-md-6 m-auto pt-4 pb-4 pr-0 pl-0 text-center bankstate_iframe d-none">
            <p  style="font-weight: 600!important">or</p>
            <a class="manual_upload" style="color:#D34D53!important;font-weight:800!important; text-decoration: underline;cursor: context-menu;">Manual Upload</a>
            
        </div>
        <div class="col-lg-4 col-md-6 m-auto pt-4 pb-4 pr-0 box1 pl-0 text-center banksuccess_manual d-none">
            <img src="https://consumer.loanwiser.in/images/Group 1046.png" style="padding: 25px;">
            <p style="color:#002B5D!important">Bank Statement Successfully Uploaded</p>
        </div>
        <div class="col-12 text-center"> 
            <a href="#"><button id="generate_bankdoc" class="generate_bankdoc button_cls" style="margin-top: 0px!important ">Submit & Next</button></a>
        </div>
    </div>
    <div class="legal_doculist  {{#ifCond this.loan_categoryid "1"}}{{else}}d-none{{/ifCond}} ">
    	{{#each this.documentlist_arr}}
        	{{#each this}}
        	<div class="col-lg-4 col-md-6  pt-4 pb-4 pr-0 pl-0 box1 text-center mt-5">
        		<p class="heading">{{@../key}}<span class="heading  {{#ifCond class_id "3"}} {{else}}d-none {{/ifCond}} " style="font-weight: 400!important;font-size:12px!important;color: grey!important;">   (Optional)</span></p>
        	
        		{{#ifCond doc_type "1"}}<p class="heading" style="font-weight: 400!important">(Upload Front & Back Photo)</p>{{else}}<p class="heading" style="font-weight: 400!important">(Upload as Single PDF)</p>{{/ifCond}}
        		<div class="form-group pr-4 pl-4 pb-4">	
                	<label for="" style="float: left!important;font-size: 16px!important;font-weight: 500;!important;color: #464646!important;">Please Select One Document</label>
                	<div class="input-group">
                    	<select class="form-control legal_docid{{this.nameforhtml}}" required="" name="legal_docid" style="border: 2px solid #E4E4E4!important;background-color: #F9FBFD!important;font-size: 17px!important;font-weight: 500;!important;color: #464646!important;">
                    		<option value="0">-select-</option>
                    		{{#each this.doc_type_names}}
                            	<option value="{{this.legal_docid}}">{{this.doc_typename}}</option>
                            {{/each}}
                    	</select>
                	</div>
            	</div>
            	<div class="img_classdata{{class_id}}{{@key}}">
            	{{#each this.doc_type_names}}
            	    
                	{{#ifCond this.upload_status "1"}}
                	    
                    	{{#each this.file}}
                    	    {{#ifCond ../../doc_type "1"}}
                    		<div class="fileImg text-center mt-2 col-9" id="deletehas{{this.hash}}" style="solid #88CCFF;border-radius: 4px" >
                    			<button class="delete two delete_document button_cls d-none"  id="button_cls{{this.legal_docid}}{{@key}}" data-hash="{{this.hash}}" data-legal_id="{{this.legal_docid}}"><i class="fa fa-trash fa-1x" aria-hidden="true"></i></button>
                    			<img src="{{this.url}}" class="img_class d-none img-fluid"  id="imgloading_class{{this.legal_docid}}{{@key}}" onload="changeImage({{this.legal_docid}}{{@key}});"  data-legal_id="{{this.legal_docid}}{{@key}}"  width="300" height="200">
                    				<center>	<p class="loaderimg" id="loading_class{{this.legal_docid}}{{@key}}"></p></center>
                    		
                    		</div>
                    		{{else}}
                    		<div class="fileDiv mt-2 col-12"  id="deletehas{{this.hash}}" style="background-color: #F1F9FF" >
                    		    <button class="delete two delete_document button_cls col-2"  id="button_cls{{this.legal_docid}}{{@key}}" data-hash="{{this.hash}}" data-legal_id="{{this.legal_docid}}"><i class="fa fa-trash fa-1x" aria-hidden="true"></i></button>
                    			<a target="_blank" class="col-10" href="{{this.url}}"><p class="fileName">{{this.file_name}}</p></a>
                    		</div>
                    		{{/ifCond}}
                		{{/each}}
            		{{/ifCond}}
            		
        		{{/each}}
        		</div>
        		<form class="upload pt-4">
        			<div align="center">
        				<label  class="label_content1" for="{{this.nameforhtml}}">{{#ifCond doc_type "1"}}Add Photo {{else}}Add Document {{/ifCond}}<span style="font-size: 20px;line-height:0;font-weight: 700">+</span></label>
        				<input type="file" name="doc_file" data-key="{{@key}}"  data-doc_type="{{doc_type}}" data-class_id="{{this.class_id}}" class=" legal_documentupload"  data-typecnt="{{this.nameforhtml}}" id="{{this.nameforhtml}}"  >
        			</div>
        		</form>
        	</div>
        	{{/each}}
    	{{/each}}
    	<div class="col-12 text-center">
            <a href="#"><button id="{{#ifCond this.property_enable "1"}}generate_banstateanalnew{{else}}generate_banstateanal{{/ifCond}}" class="{{#ifCond this.property_enable "1"}}generate_banstateanalnew{{else}}generate_banstateanal{{/ifCond}} button_cls" style="margin-top: 0px!important ">{{#ifCond this.property_enable "1"}}Submit & Next{{else}}Submit{{/ifCond}}</button></a>
        </div>
    </div>
    <div class="property_doculist d-none">
        <div class="property_doculistcnt">
        
        </div>
        <div class="col-12 text-center">
            <a href="#"><button id="generate_banstateanal" class="generate_banstateanal button_cls" style="margin-top: 0px!important ">Submit</button></a>
        </div>
    </div>
</div>
</script>
<script id="property_docscript" type="x-handlebars-template">
        {{#each this.documentlist_arr}}
        	{{#each this}}
        	<div class="col-lg-4 col-md-6  pt-4 pb-4 pr-0 pl-0 box1 text-center mt-5">
        		<p class="heading">{{@../key}}</p>
        	    
        	    <p class="heading" style="font-weight: 400!important">(Upload as Single PDF)</p>
        		<div class="form-group pr-4 pl-4 pb-4">	
                	<label for="" style="float: left!important;font-size: 16px!important;font-weight: 500;!important;color: #464646!important;">Please Select One Document</label>
                	<div class="input-group">
                    	<select class="form-control legal_docid{{this.nameforhtml}}" required="" name="legal_docid" style="border: 2px solid #E4E4E4!important;background-color: #F9FBFD!important;font-size: 17px!important;font-weight: 500;!important;color: #464646!important;">
                    		<option value="0">-select-</option>
                    		{{#each this.doc_type_names}}
                            	<option value="{{this.legal_docid}}">{{this.doc_typename}}</option>
                            {{/each}}
                    	</select>
                	</div>
            	</div>
            	<div class="img_classdata{{class_id}}{{@key}}">
            	{{#each this.doc_type_names}}
            	    
                	{{#ifCond this.upload_status "1"}}
                	    
                    	{{#each this.file}}
                    		<div class="fileDiv mt-2 col-12"  id="deletehas{{this.hash}}" style="background-color: #F1F9FF" >
                    		    <button class="delete two delete_document button_cls col-2"  id="button_cls{{this.legal_docid}}{{this.count_data}}" data-hash="{{this.hash}}" data-legal_id="{{this.legal_docid}}"><i class="fa fa-trash fa-1x" aria-hidden="true"></i></button>
                    			<a target="_blank" class="col-10" href="{{this.url}}"><p class="fileName">{{this.file_name}}</p></a>
                    		</div>
                		{{/each}}
            		{{/ifCond}}
            		
        		{{/each}}
        		</div>
        		<form class="upload pt-4">
        			<div align="center">
        				<label  class="label_content1" for="{{this.nameforhtml}}">Add Document <span style="font-size: 20px;line-height:0;font-weight: 700">+</span></label>
        				<input type="file" name="doc_file" data-key="{{@key}}" data-doc_type="{{doc_type}}"  data-class_id="{{this.class_id}}" class=" legal_documentupload"  data-typecnt="{{this.nameforhtml}}" id="{{this.nameforhtml}}"  >
        			</div>
        		</form>
        	</div>
        	{{/each}}
    	{{/each}}
</script>
<script id="plpersonal_details" type="x-handlebars-template">
    <div class="col-lg-6 col-md-8 col-sm-12 m-auto" style="padding: 0px!important">
	
	<h6 style="color: #002B5D!important;font-weight: 500!important;margin-top:30px!important">Please enter the details below</h6> </br>
</div>
<div class="col-lg-6 col-md-8 col-sm-12 m-auto contentBox">
	<form class="row" style="margin-bottom: 30px" id="personaldetailsform">
		    
		
			<div class="col-md-6 col-12" >
				<div class="form-group" >
					<label for="name">Salary Credit Method</label>
					<div class="input-group"> 
						<select type="text" name="salary_mode" id="salary_mode" class="form-control salary_mode"  required="" >
							<option disabled selected></option>
                            <option value="1">Cash Salaried</option>
                            <option value="2">Bank Credited</option>
						</select>
					</div>
				</div>	
			</div>
			
		
		
		    <div class="col-md-6 col-12" >
				<div class="form-group" >
					<label for="name">Monthly Net Salary</label>
					<div class="input-group"> 
						<input type="text" name="monthly_income"  autocomplete="off" id="monthly_income" data-d-group="2" class="form-control monthly_income formattedNumberField1"  required="" >
					</div>
				</div>	
			</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Job Sector</label>
					<div class="input-group"> 
						<select type="text" name="job_sector" id="job_sector" class="form-control job_sector"  required="" >
							<option disabled selected></option>
                            <option value="1">Agriculture & Allied Industries</option>
                            <option value="2">Automobile</option>
                            <option value="3">Aviation/Tourism</option>
                            <option value="4">Construction/Infrastructure</option>
                            <option value="5">Ecommerce</option>
                            <option value="6">Education/R&D</option>
                            <option value="7">Energy</option>
                            <option value="8">Facility Management/Security</option>
                            <option value="9">Financial Services</option>
                            <option value="10">Govt/PSU/Defence</option>
                            <option value="11">Manufacturing</option>
                            <option value="12">Media/Entertainment</option>
                            <option value="13">Pharmaceutical/Healthcare</option>
                            <option value="14">Retail or FMCG</option>
                            <option value="15">Software/IT/ITES/BPO</option>
                            <option value="16">Others</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Company Type</label>
					<div class="input-group"> 
						<select type="text" name="company_type" id="company_type" class="form-control company_type"  required="" >
							<option disabled selected></option>
                            <option value="1">State Govt</option>
                            <option value="2">Central Govt</option>
                            <option value="3">Public Ltd</option>
                            <option value="4">Private Ltd</option>
                            <option value="5">Partnership</option>
                            <option value="6">proprietorship</option>
                            <option value="7">NGO / Charity / Trust</option>
                            <option value="8">Others</option>
						</select>
					</div>
				</div>	
			</div>	
		</div>
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-12" >
				<div class="form-group" >
					<label for="name">Organisation Name</label>
					<div class="input-group"> 
						<input type="text" name="company_name"  autocomplete="off" id="company_name" class="form-control company_name "  required="" >
					</div>
				</div>	
			</div>
		</div>
		
		
		
		<div class="d-flex flex-row" style="width: 100%">
        	<div class="col-md-12 col-sm-12 " >
			    <label for="name">Work Experience </label>
			</div>
			
		</div>
		<div class="d-flex flex-row" style="width: 100%">
        	
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Years</label>
					<div class="input-group"> 
						<select  name="working_experience_y" id="working_experience_y" class="form-control working_experience_y"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
						</select>
					</div>
				</div>	
			</div>	
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Months</label>
					<div class="input-group"> 
						<select  name="working_experience_m" id="working_experience_m" class="form-control working_experience_m"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
						</select>
					</div>
				</div>	
			</div>
			
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Salary Proof</label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker " name="income_proof_type[]" multiple required  id="income_proof_type">
							<option value="1">Bank Statement</option>
                            <option value="2">Salary certificate</option>
                            <option value="3">Payslip</option>
                            <option value="4">Form 16</option>
                            <option value="5">ITR</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
	    <div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Company Proof</label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker " name="company_proof[]" multiple required  id="company_proof">
							<option value="1">Company Mail Id</option>
                            <option value="2">Pay Slip</option>
                            <option value="3">Id Card</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
		
	    
	    
	    
		
		
	</form>
	<div class="col-12 text-center">
		<a href="#"><button id="save_personaldetails" class="button_cls"  style="margin-top: 0px!important ">Save & Next</button></a>
	</div>
</div>
</script>
<script id="secplpersonal_details" type="x-handlebars-template">
    <div class="col-lg-6 col-md-8 col-sm-12 m-auto" style="padding: 0px!important">

	<h6 style="color: #002B5D!important;font-weight: 500!important;margin-top:30px!important">Please enter the details below</h6> </br>
</div>
<div class="col-lg-6 col-md-8 col-sm-12 m-auto contentBox">
	<form class="row" style="margin-bottom: 30px" id="personaldetailsform">
		    <div class="d-flex flex-row text-center" style="width: 100%">
                <div class="col-md-12 col-sm-6 " >
                    <p style="color:#B0B0B0!important;font-size: 13px!important;">Property Details</p>
                </div>
            </div>
            <div class="d-flex flex-row" style="width: 100%">
    		    <div class="col-md-6 col-sm-6 {{#ifCond this.loan_type "1"}} {{else}} d-none {{/ifCond}}" >
    				<div class="form-group" >
    					<label for="name">Property Identified</label>
    					<div class="input-group"> 
    						<select class="selectpicker property_identify" id="property_identify"  name="property_identify" required>
                                <option disabled=""></option>
                                <option value="1">Yes</option>
                                <option value="2">No</option>
                            </select>
    					</div>
    				</div>	
    			</div>
    		</div>
    		
    		<div class="d-flex flex-row" style="width: 100%">
    		    <div class="col-md-6 col-sm-6 property_title_div" >
    				<div class="form-group" >
    					<label for="name">Property Title</label>
    					<div class="input-group"> 
    						<select class="selectpicker property_title" id="property_title"  name="property_title" required>
                                <option disabled="" selected=""></option>
                                <?php 
                                foreach($proptitle_arr as $prop_key => $prop_val){ ?>
                                    <optgroup label="<?php echo $prop_key ?>">
                                    <?php   foreach($prop_val as $speckey => $specval)
                                    { ?>
                                        <option value="<?php echo $specval["id"]?>" <?php echo ($property_arr['prop_title'] ==  $specval["id"]) ? 'selected' : '';?> ><?php echo $specval["property_title"] ?></option>
                                    <?php  } ?>
                                    </optgroup>
                                    <?php
                                }
                                ?>
                            </select>
    					</div>
    				</div>	
    			</div>
    		</div>
    		<div class="d-flex flex-row" style="width: 100%">
    		    <div class="col-md-6 col-sm-6 prop_pincode_div " >
            		<div class="form-group" >
            			<label for="name">Property Pincode</label>
            			<div class="input-group"> 
            				<input type="text" name="prop_pincode" class="form-control prop_pincode formattedpinField"  autocomplete="off" id="prop_pincode"  value="<?php echo $user_arr['family_arr']["per_pincode"]; ?>"  required="" >
            			</div>
            		</div>	
            	</div>
            </div>
            <div class="d-flex flex-row" style="width: 100%">
    		    <div class="col-md-6 col-sm-6 property_type_div " >
    				<div class="form-group" >
    					<label for="name">Property Type </label>
    					<div class="input-group"> 
    						<select class="selectpicker property_type" id="property_type"  name="property_type" required>
                                <option disabled="" selected=""></option>
                                <option value="2">Villa</option>
                                <option value="3">Independent House</option>
                                <option value="4">Row House</option>
                                <option value="5">Multi unit Residential Building</option>
                                <option value="6">Residential Plot</option>
                                <option value="7">Office Unit</option>
                                <option value="8">Shop Unit</option>
                                <option value="9">Multi unit Commercial Building</option>
                                <option value="10">Commercial Plot</option>
                                <option value="11">Agri land</option>
                            </select>
    					</div>
    				</div>	
    			</div>
    		</div>
    		<div class="d-flex flex-row" style="width: 100%">
    			<div class="col-md-6 col-sm-6  property_price_div {{#inCond this.prop_value this.loan_type}}d-none{{/inCond}}" >
    				<div class="form-group" >
    					<label for="name">Property Value</label>
    					<div class="input-group"> 
    						<input type="text" name="property_price"  autocomplete="off" id="property_price"  data-d-group="2"  class="form-control property_price formattedNumberField1"  required="" >
    					</div>
    				</div>	
    			</div>
    		</div>
    		<div class="d-flex flex-row" style="width: 100%">
    			<div class="col-md-6 col-sm-6 {{#inCond this.plot_value this.loan_type}}d-none{{/inCond}}" >
    				<div class="form-group" >
    					<label for="name">Plot Value</label>
    					<div class="input-group"> 
    						<input type="text" name="plot_value"  autocomplete="off" id="plot_value"  data-d-group="2"  class="form-control plot_value formattedNumberField1"  required="" >
    					</div>
    				</div>	
    			</div>
    		</div>
    		<div class="d-flex flex-row" style="width: 100%">
    			<div class="col-md-6 col-sm-6 {{#inCond this.cost_estimated this.loan_type}}d-none{{/inCond}}" >
    				<div class="form-group" >
    					<label for="name">Cost Estimate</label>
    					<div class="input-group"> 
    						<input type="text" name="cost_of_construction"  autocomplete="off" id="cost_of_construction"  data-d-group="2"  class="form-control cost_of_construction formattedNumberField1"  required="" >
    					</div>
    				</div>	
    			</div>
    		</div>
    		
    		
    		<div class="d-flex flex-row text-center" style="width: 100%">
                <div class="col-md-12 col-sm-6 " >
                    <p style="color:#B0B0B0!important;font-size: 13px!important;">Personal / Business Details</p>
                </div>
            </div>
		    
		    
		    
			<div class="col-md-6 col-12" >
				<div class="form-group" >
					<label for="name">Salary Credit Method</label>
					<div class="input-group"> 
						<select type="text" name="salary_mode" id="salary_mode" class="form-control salary_mode"  required="" >
							<option disabled selected></option>
                            <option value="1">Cash Salaried</option>
                            <option value="2">Bank Credited</option>
						</select>
					</div>
				</div>	
			</div>
			
		
		
		    <div class="col-md-6 col-12" >
				<div class="form-group" >
					<label for="name">Monthly Net Salary</label>
					<div class="input-group"> 
						<input type="text" name="monthly_income"  autocomplete="off" id="monthly_income" data-d-group="2" class="form-control monthly_income formattedNumberField1"  required="" >
					</div>
				</div>	
			</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Job Sector</label>
					<div class="input-group"> 
						<select type="text" name="job_sector" id="job_sector" class="form-control job_sector"  required="" >
							<option disabled selected></option>
                            <option value="1">Agriculture & Allied Industries</option>
                            <option value="2">Automobile</option>
                            <option value="3">Aviation/Tourism</option>
                            <option value="4">Construction/Infrastructure</option>
                            <option value="5">Ecommerce</option>
                            <option value="6">Education/R&D</option>
                            <option value="7">Energy</option>
                            <option value="8">Facility Management/Security</option>
                            <option value="9">Financial Services</option>
                            <option value="10">Govt/PSU/Defence</option>
                            <option value="11">Manufacturing</option>
                            <option value="12">Media/Entertainment</option>
                            <option value="13">Pharmaceutical/Healthcare</option>
                            <option value="14">Retail or FMCG</option>
                            <option value="15">Software/IT/ITES/BPO</option>
                            <option value="16">Others</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Company Type</label>
					<div class="input-group"> 
						<select type="text" name="company_type" id="company_type" class="form-control company_type"  required="" >
							<option disabled selected></option>
                            <option value="1">State Govt</option>
                            <option value="2">Central Govt</option>
                            <option value="3">Public Ltd</option>
                            <option value="4">Private Ltd</option>
                            <option value="5">Partnership</option>
                            <option value="6">proprietorship</option>
                            <option value="7">NGO / Charity / Trust</option>
                            <option value="8">Others</option>
						</select>
					</div>
				</div>	
			</div>	
		</div>
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-12" >
				<div class="form-group" >
					<label for="name">Organisation Name</label>
					<div class="input-group"> 
						<input type="text" name="company_name"  autocomplete="off" id="company_name" class="form-control company_name "  required="" >
					</div>
				</div>	
			</div>
		</div>
		
		
		
		<div class="d-flex flex-row" style="width: 100%">
        	<div class="col-md-12 col-sm-12 " >
			    <label for="name">Work Experience </label>
			</div>
			
		</div>
		<div class="d-flex flex-row" style="width: 100%">
        	
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Years</label>
					<div class="input-group"> 
						<select  name="working_experience_y" id="working_experience_y" class="form-control working_experience_y"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
						</select>
					</div>
				</div>	
			</div>	
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Months</label>
					<div class="input-group"> 
						<select  name="working_experience_m" id="working_experience_m" class="form-control working_experience_m"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
						</select>
					</div>
				</div>	
			</div>
			
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Salary Proof</label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker " name="income_proof_type[]" multiple required  id="income_proof_type">
							<option value="1">Bank Statement</option>
                            <option value="2">Salary certificate</option>
                            <option value="3">Payslip</option>
                            <option value="4">Form 16</option>
                            <option value="5">ITR</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
	    <div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Company Proof</label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker " name="company_proof[]" multiple required  id="company_proof">
							<option value="1">Company Mail Id</option>
                            <option value="2">Pay Slip</option>
                            <option value="3">Id Card</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
		
	    
	    
	    
		
		
	</form>
	
	
	
	<div class="col-12 text-center">
		<a href="#"><button id="save_personaldetails" class="button_cls"  style="margin-top: 0px!important ">Save & Next</button></a>
	</div>
</div>
</script>
<script id="blpersonal_details" type="x-handlebars-template">
    <div class="col-lg-6 col-md-8 col-sm-12 m-auto" style="padding: 0px!important">
	
	<h6 style="color: #002B5D!important;font-weight: 500!important;margin-top:30px!important">Please enter the details below</h6>
</div>
<div class="col-lg-6 col-md-8 col-sm-12 m-auto contentBox">
	<form class="row" style="margin-bottom: 30px" id="personaldetailsform">
		
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Type of Employment </label>
					<div class="input-group"> 
						<select class="selectpicker bus_employment_type" id="bus_employment_type"  name="bus_employment_type" required>
                            <option disabled="" selected=""></option>
                            <option value="1">Independent worker </option>
                            <option value="2">Farming / Dairy / poultry</option>
                            <option value="3">Run own business / Shop</option>
                        </select>
					</div>
				</div>	
			</div>
		</div>
			<div class="d-flex flex-row" style="width: 100%">
        	<div class="col-md-12 col-sm-12 " >
			    <label for="name">Business Experience</label>
			</div>
		</div>
		
		<div class="d-flex flex-row" style="width: 100%">
        	
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Year</label>
					<div class="input-group"> 
						<select  name="work_experianceyr" id="work_experianceyr" class="form-control work_experianceyr"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
						</select>
					</div>
				</div>	
			</div>	
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Month</label>
					<div class="input-group"> 
						<select  name="work_experiancemon" id="work_experiancemon" class="form-control work_experiancemon"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Business vintage Proof</label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker bus_proof" id="bus_proof"  multiple name="bus_proof[]" required>
                   
                            <option value="1">GST Registration</option>
                            <option value="2">Shop License</option>
                            <option value="3">FSSAI</option>
                            <option value="4">SSI</option>
                            <option value="7">work / Labor License</option>
                            <option value="8">Weighing Scale Certificate</option>
                            <option value="9">TIN Registration Certificate</option>
                            <option value="10">TAN Registration Certificate</option>
                            <option value="11">VAT Registration Certificate </option>
                            <option value="12">Registrar of firms Certificate</option>
                            <option value="14">Import and Export License </option>
                            <option value="16">Udhyog Aadhar</option>
                             <option value="17">CST Registration Certificate </option>
                            <option value="15">No proof</option>
                        </select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Average monthly profit</label>
					<div class="input-group"> 
						<input type="text" name="net_salary"  autocomplete="off" id="net_salary" class="form-control net_salary formattedNumberField1"  data-d-group="2"   required="" >
					</div>
				</div>	
			</div>
		</div>
		
		
		
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Business Income Proof </label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker income_proof_type " multiple name="income_proof_type[]" id="income_proof_type" required>
                          
                            <option value="1">Income Tax Return (ITR)</option>
                            <option value="2">Balance sheet & P/L account</option>
                            <option value="4">Current Account statement for 1 year</option>
                            <option value="5">Savings Account statement for 1 year</option>
                            <option value="6">Sales Bill/Voucher</option>
                            <option value="7">GST returns for 1year</option>
                            <option value="8">TDS Certificate</option>
                            <option value="15">No Proof</option>
                        </select>
					</div>
				</div>	
			</div>
			
		</div>
	
	
		<div class="d-flex flex-row" style="width: 100%">
			
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Office/Shop Setup</label>
					<div class="input-group"> 
						<select type="text" name="office_setup" id="office_setup" class="form-control office_setup"  required="" >
							<option value="" selected=""></option>
                            <option value="1">At Home</option>
                            <option value="2">Seperate</option>
                            <option value="3">No Setup</option>
						</select>
					</div>
				</div>	
			</div>
			
		</div>
	    <div class="d-flex flex-row" style="width: 100%">
			
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Bussiness Registeration </label>
					<div class="input-group"> 
						<select type="text" name="bussiness_registeration" id="bussiness_registeration" class="form-control bussiness_registeration"  required="" >
							<option disabled="" selected=""></option>
                            <option value="4">Un Registered</option>
                            <option value="1">Proprietorship</option>
                            <option value="2">Partnership</option>
                            <option value="3">Private Limited</option>
						</select>
					</div>
				</div>	
			</div>
			
		</div>
	
		
	</form>
	<div class="col-12 text-center">
		<a href="#"><button id="save_personaldetails" class="button_cls"  style="margin-top: 0px!important ">Save & Next</button></button></a>
	</div>
</div>
</script>
<script id="secblpersonal_details" type="x-handlebars-template">
    <div class="col-lg-6 col-md-8 col-sm-12 m-auto" style="padding: 0px!important">
	
	<h6 style="color: #002B5D!important;font-weight: 500!important;margin-top:30px!important">Please enter the details below</h6>
</div>
<div class="col-lg-6 col-md-8 col-sm-12 m-auto contentBox">
	<form class="row" style="margin-bottom: 30px" id="personaldetailsform">
		<div class="d-flex flex-row text-center" style="width: 100%">
            <div class="col-md-12 col-sm-6 " >
                <p style="color:#B0B0B0!important;font-size: 13px!important;">Property Details</p>
            </div>
        </div>
        <div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6 {{#ifCond this.loan_type "1"}} {{else}} d-none {{/ifCond}}" >
				<div class="form-group" >
					<label for="name">Property Identified</label>
					<div class="input-group"> 
						<select class="selectpicker property_identify" id="property_identify"  name="property_identify" required>
                            <option disabled=""></option>
                            <option value="1">Yes</option>
                            <option value="2">No</option>
                        </select>
					</div>
				</div>	
			</div>
		</div>
		
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6  property_title_div" >
				<div class="form-group" >
					<label for="name">Property Title</label>
					<div class="input-group"> 
						<select class="selectpicker property_title" id="property_title"  name="property_title" required>
                            <option disabled="" selected=""></option>
                            <?php 
                            foreach($proptitle_arr as $prop_key => $prop_val){ ?>
                                <optgroup label="<?php echo $prop_key ?>">
                                <?php   foreach($prop_val as $speckey => $specval)
                                { ?>
                                    <option value="<?php echo $specval["id"]?>" <?php echo ($property_arr['prop_title'] ==  $specval["id"]) ? 'selected' : '';?> ><?php echo $specval["property_title"] ?></option>
                                <?php  } ?>
                                </optgroup>
                                <?php
                            }
                            ?>
                        </select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6  prop_pincode_div" >
        		<div class="form-group" >
        			<label for="name">Property Pincode</label>
        			<div class="input-group"> 
        				<input type="text" name="prop_pincode" class="form-control prop_pincode formattedpinField"  autocomplete="off" id="prop_pincode"  value="<?php echo $user_arr['family_arr']["per_pincode"]; ?>"  required="" >
        			</div>
        		</div>	
        	</div>
        </div>
        <div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6  property_type_div" >
				<div class="form-group" >
					<label for="name">Property Type </label>
					<div class="input-group"> 
						<select class="selectpicker property_type" id="property_type"  name="property_type" required>
                            <option disabled="" selected=""></option>
                            <option value="2">Villa</option>
                            <option value="3">Independent House</option>
                            <option value="4">Row House</option>
                            <option value="5">Multi unit Residential Building</option>
                            <option value="6">Residential Plot</option>
                            <option value="7">Office Unit</option>
                            <option value="8">Shop Unit</option>
                            <option value="9">Multi unit Commercial Building</option>
                            <option value="10">Commercial Plot</option>
                            <option value="11">Agri land</option>
                        </select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 {{#inCond this.prop_value this.loan_type}}d-none{{/inCond}}" >
				<div class="form-group property_price_div" >
					<label for="name">Property Value</label>
					<div class="input-group"> 
						<input type="text" name="property_price"  autocomplete="off" id="property_price" class="form-control property_price formattedNumberField1"   data-d-group="2"  required="" >
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 {{#inCond this.plot_value this.loan_type}}d-none{{/inCond}}" >
				<div class="form-group" >
					<label for="name">Plot Value</label>
					<div class="input-group"> 
						<input type="text" name="plot_value"  autocomplete="off" id="plot_value" class="form-control plot_value formattedNumberField1"  data-d-group="2"   required="" >
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 {{#inCond this.cost_estimated this.loan_type}}d-none{{/inCond}}" >
				<div class="form-group" >
					<label for="name">Cost Estimate</label>
					<div class="input-group"> 
						<input type="text" name="cost_of_construction"  autocomplete="off" id="cost_of_construction" class="form-control cost_of_construction formattedNumberField1"  data-d-group="2"   required="" >
					</div>
				</div>	
			</div>
		</div>
		
		
		<div class="d-flex flex-row text-center" style="width: 100%">
            <div class="col-md-12 col-sm-6 " >
                <p style="color:#B0B0B0!important;font-size: 13px!important;">Personal / Business Details</p>
            </div>
        </div>
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Type of Employment </label>
					<div class="input-group"> 
						<select class="selectpicker bus_employment_type" id="bus_employment_type"  name="bus_employment_type" required>
                            <option disabled="" selected=""></option>
                            <option value="1">Independent worker </option>
                            <option value="2">Farming / Dairy / poultry</option>
                            <option value="3">Run own business / Shop</option>
                        </select>
					</div>
				</div>	
			</div>
		</div>
		
        
		<div class="d-flex flex-row" style="width: 100%">
        	<div class="col-md-12 col-sm-12 " >
			    <label for="name">Business Experience</label>
			</div>
		</div>
		
		<div class="d-flex flex-row" style="width: 100%">
        	
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Year</label>
					<div class="input-group"> 
						<select  name="work_experianceyr" id="work_experianceyr" class="form-control work_experianceyr"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
						</select>
					</div>
				</div>	
			</div>	
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Month</label>
					<div class="input-group"> 
						<select  name="work_experiancemon" id="work_experiancemon" class="form-control work_experiancemon"  required="" >
							<option disabled selected></option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
						</select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
		    <div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Business vintage Proof</label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker bus_proof" id="bus_proof"  multiple name="bus_proof[]" required>
                   
                            <option value="1">GST Registration</option>
                            <option value="2">Shop License</option>
                            <option value="3">FSSAI</option>
                            <option value="4">SSI</option>
                            <option value="7">work / Labor License</option>
                            <option value="8">Weighing Scale Certificate</option>
                            <option value="9">TIN Registration Certificate</option>
                            <option value="10">TAN Registration Certificate</option>
                            <option value="11">VAT Registration Certificate </option>
                            <option value="12">Registrar of firms Certificate</option>
                            <option value="14">Import and Export License </option>
                            <option value="16">Udhyog Aadhar</option>
                             <option value="17">CST Registration Certificate </option>
                            <option value="15">No proof</option>
                        </select>
					</div>
				</div>	
			</div>
		</div>
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Average monthly profit</label>
					<div class="input-group"> 
						<input type="text" name="net_salary"  autocomplete="off" id="net_salary" class="form-control net_salary formattedNumberField1"  data-d-group="2"   required="" >
					</div>
				</div>	
			</div>
		</div>
		
		
		
		<div class="d-flex flex-row" style="width: 100%">
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Business Income Proof </label><label1> (Select one or more)</label1>
					<div class="input-group"> 
						<select class="selectpicker income_proof_type " multiple name="income_proof_type[]" id="income_proof_type" required>
                          
                            <option value="1">Income Tax Return (ITR)</option>
                            <option value="2">Balance sheet & P/L account</option>
                            <option value="4">Current Account statement for 1 year</option>
                            <option value="5">Savings Account statement for 1 year</option>
                            <option value="6">Sales Bill/Voucher</option>
                            <option value="7">GST returns for 1year</option>
                            <option value="8">TDS Certificate</option>
                            <option value="15">No Proof</option>
                        </select>
					</div>
				</div>	
			</div>
			
		</div>
	
	
		<div class="d-flex flex-row" style="width: 100%">
			
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Office/Shop Setup</label>
					<div class="input-group"> 
						<select type="text" name="office_setup" id="office_setup" class="form-control office_setup"  required="" >
							<option value="" selected=""></option>
                            <option value="1">At Home</option>
                            <option value="2">Seperate</option>
                            <option value="3">No Setup</option>
						</select>
					</div>
				</div>	
			</div>
			
		</div>
	    <div class="d-flex flex-row" style="width: 100%">
			
			<div class="col-md-6 col-sm-6 " >
				<div class="form-group" >
					<label for="name">Bussiness Registeration </label>
					<div class="input-group"> 
						<select type="text" name="bussiness_registeration" id="bussiness_registeration" class="form-control bussiness_registeration"  required="" >
							<option disabled="" selected=""></option>
                            <option value="4">Un Registered</option>
                            <option value="1">Proprietorship</option>
                            <option value="2">Partnership</option>
                            <option value="3">Private Limited</option>
						</select>
					</div>
				</div>	
			</div>
			
		</div>
	
		
	</form>
	<div class="col-12 text-center">
		<a href="#"><button id="save_personaldetails" class="button_cls"  style="margin-top: 0px!important ">Save & Next</button></button></a>
	</div>
</div>
</script>