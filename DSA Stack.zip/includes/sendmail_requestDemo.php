<?php 

$admin_mail = 'info@loanwiser.in';
$today = date('Y-m-d H:i:s');
require_once('class.phpmailer.php');

include_once('config.php');
include_once("mail_functions.php");

$inputs = json_decode(file_get_contents('php://input'),true);

if($_POST['email'] != "")
{
 
    $contact_name = $_POST['name'];
	$contact_email = $_POST['email'];
	$contact_phone = $_POST['mobilenum'];
	$contact_message = $_POST['message'];
	$contact_companysize = $_POST['companysize'];
	if($contact_companysize == "1")
	{
	    $contact_companysize = "Less than 10 Franchisee/End-Users";
	}
	else if($contact_companysize == "2")
	{
	    $contact_companysize = "10 to 50";
	}
	else if($contact_companysize == "3")
	{
	    $contact_companysize = "50 to 100";
	}
	else if($contact_companysize == "4")
	{
	    $contact_companysize = "Greater than 100";
	}
	$contact_date_time = $_POST['date_time'];
	$contact_business = $_POST['bussiness'];
	$from = 'hello@dsastack.in';
	$date = date("M d, Y");
	$to = "sreedhar@loanwiser.in";
// 	$to = "ranjeeth@loanwiser.in";
	
	$cc['mail'] = "support@loanwiser.in";
// 	$cc[0]['mail'] = "ranjeeth@ranjeeth.in";
	$cc['name'] = "Support";

// 	$lnk_gen = 'https://loanwiser.in/Email-Verification.php?b2b_id='.$contact_id.'&mail_verify=1';
$subject = "Request for Demo";
 if($_POST['source'] == "fi")
 {
     $heading = "You have received a request for Demo from Loanwiser Services - For Banks & FIs - ".$_POST['link'];
     
 }
 else if($_POST['source'] == "st")
 {
     $heading = "You have received a request for Demo from Loanwiser Services - For Startups - ".$_POST['link'];
 }
 else if($_POST['source'] == "co")
 {
     $heading = "You have received a request for Demo from Loanwiser Services - For Corporates - ".$_POST['link'];
 }
	
	

// 	$message = file_get_contents('reg_verify.php');
	$message = file_get_contents('request_demo_template.php');
	$message_enq = file_get_contents('request_demo_enquirer_template.php');
	
	$message = str_replace("**username**",$contact_name,$message);
	$message_enq = str_replace("**username**",$contact_name,$message_enq);
	
	$message = str_replace("**useremail**",$contact_email,$message);
	$message_enq = str_replace("**useremail**",$contact_email,$message_enq);
	
	$message = str_replace("**userphone**",$contact_phone,$message);
	$message_enq = str_replace("**userphone**",$contact_phone,$message_enq);
	
	$message = str_replace("**usermessage**",$contact_message,$message);
	$message_enq = str_replace("**usermessage**",$contact_message,$message_enq);
	
	$message = str_replace("**business**",$contact_business,$message);
	$message_enq = str_replace("**business**",$contact_business,$message_enq);
	
	$message = str_replace("**date**",$date,$message);
	$message_enq = str_replace("**date**",$date,$message_enq);
	
	$message = str_replace("**scheduled_date**",$contact_date_time,$message);
	$message_enq = str_replace("**scheduled_date**",$contact_date_time,$message_enq);
	
	$message = str_replace("**company_size**",$contact_companysize,$message);
	$message_enq = str_replace("**company_size**",$contact_companysize,$message_enq);
	
	$message = str_replace("**heading**",$heading,$message);
	$loanwiser_mail = loanwiserMailadmin($from,$to,$subject,$message,$contact_name,$cc);
	$loanwiser_mail_enq = loanwiserMailadmin($from,$contact_email,$subject,$message_enq,$contact_name,0);

	if($loanwiser_mail == '0')
	{
		echo '0';
		return false;
	} 
	else
	{
		echo '1';
		return false;
	}
}
else
{
    echo "Something went wrong..";
    return false;
}

function loanwiserMailadmin($from,$to,$subject,$message,$username,$cc)
{
    
    $username = 'DSA Stack';
	$mail = new PHPMailer(); 

	$body = $message;
	$mail->SetFrom($from,$username);
	$mail->AddReplyTo($from,$username);
	$mail->AddAddress($to);
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	if($cc)
	{
	    $mail->AddCC($cc["mail"], $cc["name"]);
	}
    
	
	if(!$mail->Send()) 
	{
		return $mail->ErrorInfo;
	} 
	else 
	{
		return "0";
	}
}
?>