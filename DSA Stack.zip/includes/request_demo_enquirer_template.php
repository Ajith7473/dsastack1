
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">

<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<meta content="width=device-width" name="viewport" />
	<meta content="IE=edge" http-equiv="X-UA-Compatible" />
	<title></title>
	<link href="https://fonts.googleapis.com/css?family=Droid+Serif" rel="stylesheet" type="text/css" />
	<style type="text/css">
	</style>
</head>

<body class="clean-body" style="margin: 0; padding: 0; -webkit-text-size-adjust: 100%; background-color: #FFFFFF;">
	
	<div id="" class="">
		<div style="margin:0;padding:0">
			<table style="border-collapse:collapse;table-layout:fixed;margin:0 auto;border-spacing:0;padding:0;height:100%!important;width:100%!important;font-weight:normal;color:#3e4152;font-family:'roboto',Arial,Helvetica,sans-serif;font-size:14px;line-height:1.4" height="100%" border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
					<tr>
						<td style="background:#ffffff;padding:16px 0">
							<table style="max-width:800px;margin:auto;border-spacing:0;background:#002b5de6;padding:4px;border-radius:16px;overflow:hidden" align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
								<tbody>
									<tr>
										<td style="border-collapse:collapse">
											<table style="margin:auto;border-spacing:0;background:white;border-radius:12px;overflow:hidden" align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
												<tbody>
													<tr>
														<td style="border-collapse:collapse">
															<table style="border-spacing:0;border-collapse:collapse" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%">
																<tbody>
																	<tr>
																		<td style="border-collapse:collapse;padding:16px 32px" align="left" valign="middle">
																			<table style="border-spacing:0;border-collapse:collapse" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td style="padding:0;text-align:left;border-collapse:collapse" width="40" align="left" valign="middle">
																							<a href="https://dsastack.in" style="text-decoration:none;color:#ffffff;outline:0;outline:none;border:0;border:none" target="_blank" >
																								<img src="https://loanwiser.in/dsa/images/dsastack-logo.png" title="DSA Stack" alt="DSA Stack" style="margin:auto;text-align:center;border:0;outline:none;text-decoration:none;" align="middle" border="0" width="160" class="CToWUd">
																							</a>
																						</td>
																						<td width="16" align="left" valign="middle" style="border-collapse:collapse">&nbsp;</td>
																						<td align="right" valign="middle">**date**</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>																												
													<tr>
														<td style="border-collapse:collapse;padding:32px;background:#ffffff;font-family:'roboto',Arial,Helvetica,sans-serif">
															<p style="padding:0;margin:0">Hi ,**username**
																<br>
																<br>Thanks for getting in touch - We're exited for our first interaction together. You will be hearing from us very soon.
																<br></p>
														</td>
													</tr>
													<tr>
														<td style="border-collapse:collapse;padding:0 16px">
															<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="background:#f7f9fa;padding:16px;border-radius:8px;overflow:hidden">
																<tbody>	
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse;text-transform:capitalize">Name</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**username**</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse;text-transform:capitalize">Email</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**useremail**</td>
																						
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse;text-transform:capitalize">Mobile Number</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**userphone**</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse">Business Name</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**business**</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse">Company Size</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**company_size**</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse">Preferred Date & Time for Demo</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**scheduled_date**</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;padding:8px 0;border-bottom:1px solid #eaeaed;font-size:12px">
																			<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																				<tbody>
																					<tr>
																						<td width="28%" align="left" valign="top" style="border-collapse:collapse;text-transform:capitalize">Message</td>
																						<td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">:</td>
																						<td align="left" valign="top" style="border-collapse:collapse;font-weight:normal">**usermessage**</td>
																						
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
													<tr>
														<td style="border-collapse:collapse;padding:32px;background:#ffffff;font-family:'roboto',Arial,Helvetica,sans-serif">
															<p style="padding:0;margin:0">Thanks!
																<br>Your DSA Stack Team</p>
														</td>
													</tr>
													<tr>
														<td style="border-collapse:collapse;padding:16px 32px;border-top:1px solid #eaeaed;font-family:'roboto',Arial,Helvetica,sans-serif;font-size:12px">
															<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
																<tbody>
																	<tr>
																		<td align="left" valign="middle" style="border-collapse:collapse;font-weight:normal"> 
																		<a href="https://loanwiser.in/About-Us.php" style="color:#002b5de6;font-size:12px;padding:4px;height:24px;display:inline-block;text-transform:capitalize;outline:0;outline:none;border:0;border:none" target="_blank" >About us</a>  
																		<a href="https://loanwiser.in/Privacy-Policy.php" style="color:#002b5de6;font-size:12px;padding:4px;height:24px;display:inline-block;text-transform:capitalize;outline:0;outline:none;border:0;border:none" target="_blank" >Privacy Policy</a>
																		 <a href="https://loanwiser.in/Refund-Policy.php" style="color:#002b5de6;font-size:12px;padding:4px;height:24px;display:inline-block;text-transform:capitalize;outline:0;outline:none;border:0;border:none" target="_blank" >Refund Policy</a> 
																		<a href="https://loanwiser.in/Terms-Conditions.php" style="color:#002b5de6;font-size:12px;padding:4px;height:24px;display:inline-block;text-transform:capitalize;outline:0;outline:none;border:0;border:none" target="_blank" >Terms & Conditions</a> 
																		</td>
																		<td width="16" align="left" valign="middle" style="border-collapse:collapse">&nbsp;</td>
																		<td align="right" valign="middle" style="border-collapse:collapse">
																			<table border="0" cellspacing="0" cellpadding="0">
																				<tbody>
																					<tr>
																						<td style="border-collapse:collapse">
																							<a href="https://www.facebook.com/loanwiser.inforvio" style="font-size:0;border:0;outline:0;border:none;outline:none;text-decoration:none;margin-right:4px" target="_blank">
																								<img width="26" style="border-radius: 4px;" src="https://consumer.loanwiser.in/images/ico_facebook.jpg" title="Facebook" alt="Facebook" class="CToWUd">
																							</a>
																							<a href="https://twitter.com/loanwiser" style="font-size:0;border:0;outline:0;border:none;outline:none;text-decoration:none;margin-right:4px" target="_blank">
																								<img width="26" style="border-radius: 4px;" src="https://consumer.loanwiser.in/images/ico_twitter.jpg" title="Twitter" alt="Twitter" class="CToWUd">
																							</a>
																							<a href="https://www.linkedin.com/company/loanwiser" style="font-size:0;border:0;outline:0;border:none;outline:none;text-decoration:none;margin-right:4px" target="_blank">
																								<img width="26" style="border-radius: 4px;" src="https://consumer.loanwiser.in/images/ico_linkedin.jpg" title="LinkedIn" alt="LinkedIn" class="CToWUd">
																							</a>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td style="border-collapse:collapse;font-weight:normal;padding-top:16px;font-style:italic;color:#7e818c" colspan="3">Important Note: DSA Stack or its merchant partners never ask for your DSA Stack password, bank details or MPIN over email/phone. Please do not share your DSA Stack password or MPIN with anyone. For any questions reach us at <a style="color:#002b5de6">hello@dsastack.in</a> 
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	
</body>

</html>