<?php 

$admin_mail = 'info@loanwiser.in';
$today = date('Y-m-d H:i:s');
require_once('class.phpmailer.php');

include_once('config.php');
include_once("mail_functions.php");

$inputs = json_decode(file_get_contents('php://input'),true);

if($_POST['email'] != "")
{    
 
    $contact_name = $_POST['name'];
	$contact_email = $_POST['email'];
	$contact_phone = $_POST['phone'];
	$contact_message = $_POST['message'];
	$contact_business = $_POST['business'];
	$from = 'loanwiser@gmail.com';
	$date = date("M d, Y");
	$to = "sreedhar@loanwiser.in";
	$cc[0]['mail'] = "support@loanwiser.in";
	$cc[0]['name'] = "Support";
	$cc[1]['mail'] = $contact_email;
	$cc[1]['name'] = $contact_name;
// 	$lnk_gen = 'https://loanwiser.in/Email-Verification.php?b2b_id='.$contact_id.'&mail_verify=1';
	$subject = "You have received message from Loanwiser contact form";
	

// 	$message = file_get_contents('reg_verify.php');
	$message = file_get_contents('contact_temp.php');
	$message = str_replace("**username**",$contact_name,$message);
	$message = str_replace("**useremail**",$contact_email,$message);
	$message = str_replace("**userphone**",$contact_phone,$message);
	$message = str_replace("**usermessage**",$contact_message,$message);
	$message = str_replace("**business**",$contact_business,$message);
	$message = str_replace("**date**",$date,$message);
	$loanwiser_mail = loanwiserMailadmin($from,$to,$subject,$message,$contact_name,$cc);

	if($loanwiser_mail == '0')
	{
		echo '0';
		return false;
	} 
	else
	{
		echo '1';
		return false;
	}

}
else
{
    echo "Something went wrong..";
    return false;
}
function loanwiserMailadmin($from,$to,$subject,$message,$username,$cc)
{
    
    $username = 'Loanwiser';
	$mail = new PHPMailer(); 

	$body = $message;
	$mail->SetFrom($from,$username);
	$mail->AddReplyTo($from,$username);
	$mail->AddAddress($to);
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	foreach($cc as $key => $val)
	{
	    $mail->AddCC($val["mail"], $val["name"]);
	}
	if(!$mail->Send()) 
	{
		return $mail->ErrorInfo;
	} 
	else 
	{
		return "0";
	}
}
?>