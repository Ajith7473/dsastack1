<!-- Add New Lead Modal -->
<div class="modal fade" id="addnewlead" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content card">
      <div class="">
        <div class="card-header card-header-icon" data-background-color="default">
          <i class="material-icons">person_add</i>
        </div>
        <div class="modal-header">
          <h5 class="modal-title">Add New Lead</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i class="material-icons">clear</i>
          </button>
        </div>
        <form id="" action="" method="">
          <div class="modal-body">

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Name<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Email<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Mobile Number<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Living City<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Refer By<small>*</small></label>
                <select class="form-control">
                  <option value=""></option>
                  <option value="Propwiser">Propwiser</option>
                  <option value="Browsing Center">Browsing Center</option>
                  <option value="Agent">Agent</option>
                  <option value="Document Writer">Document Writer</option>
                  <option value="Mortgage Connector">Mortgage Connector</option>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">BC Code<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Lead From<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Refer By<small>*</small></label>
                <select class="form-control">
                  <option value=""></option>
                  <option value="English">English</option>
                  <option value="Tamil">Tamil</option>
                  <option value="Hindi">Hindi</option>
                  <option value="Telungu">Telungu</option>
                  <option value="Kannada">Kannada</option>
                </select>
              </div>
            </div>
            <div class="clearfix"></div>

          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-rose btn-fill">Submit</button>
            <!--<button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>-->
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--  End Add New Lead Modal -->

<!-- Add New Business User Modal -->
<div class="modal fade" id="addnewbusiness" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content card">
      <div class="">
        <div class="card-header card-header-icon" data-background-color="default">
          <i class="material-icons">person_add</i>
        </div>
        <div class="modal-header">
          <h5 class="modal-title">Add New Business User</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i class="material-icons">clear</i>
          </button>
        </div>
        <form id="" action="" method="">
          <div class="modal-body">

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Name<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Email<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Mobile Number<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Source Name<small>*</small></label>
                <select class="form-control">
                  <option value=""></option>
                  <option value="Propwiser">Loanwiser</option>
                  <option value="Browsing Center">Browsing Center</option>
                  <option value="Agent">Agent</option>
                  <option value="Document Writer">Document Writer</option>
                  <option value="Mortgage Connector">Mortgage Connector</option>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">State<small>*</small></label>
                <select class="form-control">
                  <option value=""></option>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">City<small>*</small></label>
                <select class="form-control">
                  <option value=""></option>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group label-floating is-empty">
                <label class="control-label">Pin Code<small>*</small></label>
                <input class="form-control">
                <span class="material-input"></span>
              </div>
            </div>
            <div class="clearfix"></div>

          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-rose btn-fill">Submit</button>
            <!--<button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>-->
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--  End Add New Business User  Modal -->