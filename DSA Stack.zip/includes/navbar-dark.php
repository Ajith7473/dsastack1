        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-138047361-1"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'UA-138047361-1');
        </script>
        <!-- End Global site tag (gtag.js) - Google Analytics -->
        <header class="">
        	<nav class="navbar navbar-expand-lg">
        		<div class="container">
        			<a class="navbar-brand" href="https://loanwiser.in/">
        				<img src="images/loanwiser White.png" width="180px" alt="Loanwiser Loan Facilitation MarketPlace">
        			</a>
        			<button class="navbar-toggler navbar-light bg-light" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">	<span class="navbar-toggler-icon"></span>
        			</button>
        			<div class="collapse navbar-collapse" id="navbarNav">
        				<ul class="navbar-nav ml-auto">
        					<li style="position: relative" class="nav-item <?php echo ($page == 'Loanwiser')?" active ":" " ?>">	
        					    <a class="nav-link customnavLink" href="index.php">Home</a>
        						<div class="bottomline2"></div>
        					</li>
        					<li class="nav-item dropdown <?php echo ($page == 'Corporates' or $page == 'IndividualsWeb' or $page == 'IndividualsMobile' or $page == 'Startups')?" active ":" " ?>">	
        					    <a class="nav-link customnavLink dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Our Services</a>
        						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> 
        						    <a class="dropdown-item <?php echo ($page == 'Corporates')?" active ":" " ?>" href="Corporate-Partner.php">For Corporates</a>
        							<!--<a class="dropdown-item <?php echo ($page == 'IndividualsWeb')?" active ":" " ?>" href="Individual-Partner-WebApp.php" target="_blank">For Individuals Web</a>-->
        							<!--<a class="dropdown-item <?php echo ($page == 'IndividualsMobile')?" active ":" " ?>" href="Individual-Partner-MobileApp.php">For Individuals Mobile</a>-->
        							<a class="dropdown-item <?php echo ($page == 'Startups')?" active ":" " ?>" href="Startups.php">For Startups</a>
        						</div>
        						<div class="bottomline2"></div>
        					</li>
        					<li style="position: relative" class="nav-item <?php echo ($page == 'Financial')?" active ":" " ?>">	
        					    <a class="nav-link customnavLink" href="Financial-Institution.php">For Banks & FIs</a>
        						<div class="bottomline2"></div>
        					</li>
        					<li style="position: relative" class="nav-item <?php echo ($page == 'AboutUs')?" active ":" " ?>">	
        					    <a class="nav-link customnavLink" href="About-Us.php">About Us</a>
        						<div class="bottomline2"></div>
        					</li>
        					<li style="position: relative" class="nav-item <?php echo ($page == 'ContactUs')?" active ":" " ?>">	
        					    <a class="nav-link customnavLink" href="Contact-Us.php">Contact Us</a>
        						<div class="bottomline2"></div>
        					</li>
        					<!--<li style="position: relative" class="nav-item">	-->
        					<!--    <a class="nav-link customnavLink" href="Individual-Partner-WebApp.php?req=login" target="_blank">Individual Partner Login</a>-->
        					<!--	<div class="bottomline2"></div>-->
        					<!--</li>-->
        				</ul>
        			</div>
        		</div>
        	</nav>
        </header>