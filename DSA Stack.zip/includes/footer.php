<footer>
	<div style="background-color: #EEF4FF" class="position-relative">
		<div class="container">
			<div class="row" style="padding: 1px 0px">
				<div class="col-lg-3 col-md-12 py-2">
					<a href="https://dsastack.in/"><img src="images/dsastack-logo.png" height="50px" alt="DSA Stack Loan Facilitation MarketPlace"></a>
				</div>
				<!--<div class="col-lg-3 col-md-3 my-4">-->
				<!--    <a href="index.php" class="links">Home</a>-->
				<!--</div>-->
				<!--<div class="col-lg-3 col-md-3 my-4">-->
				<!--    <a href="About-Us.php" class="links">About Us</a>-->
				<!--</div>-->
				<!--<div class="col-lg-3 col-md-3 my-4">-->
				<!--    <a href="Contact-Us.php" class="links">Contact Us</a>-->
				<!--</div>-->
			</div>
		</div>
		<div class="topBtn">
			<a href="#" class="btn-top">
				<img src="images/topbutton.png" width="100%">
			</a>
		</div>
	</div>
	<div style="background-color: #20385D">
		<div class="container">
			<div class="row" style="padding: 1px 0px">
				<div class="col-lg-4 col-md-4 mt-3 text-center">
					<p class="text-white m-0">A Product of <a href="https://inforvio.com" class="text-white" target="_blank">Inforvio Technologies Pvt Ltd</a>
					</p>
				</div>
				<div class="col-lg-5 col-md-4 mt-3 text-center p-0" >
				    <p style="font-size: 14px!important;" class="m-0">
				        <a target="_blank" href="https://loanwiser.in/Terms-Conditions.php">Terms &amp; Condition</a> -	
				        <a target="_blank" href="https://loanwiser.in/Terms-Service.php">Terms of Service</a> -	
            			<a target="_blank" href="https://loanwiser.in/Privacy-Policy.php">Privacy Policy</a> -	
            			<a target="_blank" href="https://loanwiser.in/Refund-Policy.php">Refund Policy</a>
				    </p>
        				
        		</div>
				<div class="col-lg-3 col-md-4 mt-3 mb-3 text-center textRtoL">
					<a class="mr-5 text-white" href="https://in.linkedin.com/company/loanwiser" target="_blank">
						<i class="fab fa-linkedin-in fa-lg"></i>
					</a>
					<a class="text-white" href="https://twitter.com/loanwiser" target="_blank">
						<i class="fab fa-twitter fa-lg"></i>
					</a>
					<a class="ml-5 text-white" href="https://www.facebook.com/loanwiser.in" target="_blank">
						<i class="fab fa-facebook-f fa-lg"></i>
					</a>
					<a class="ml-5 text-white" href="https://www.instagram.com/loanwiser/" target="_blank">
						<i class="fab fa-instagram fa-lg"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
</footer>