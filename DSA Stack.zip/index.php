<?php
    $page="DSA";
?>
<!doctype html>
<html>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<title>DSA Stack</title>
	<meta name="keywords" itemprop="keywords" content="Loan sourcing, loan business, embedded finance, fintech, loan marketplace, startups, developer friendly, fintech APIs"/>
	<meta name="description" content="Why stop with single loan product when you can empower your customers with entire range of loan products from wide range of lenders."/>
	<meta property="og:title" content="Loanwiser - For Startups" />
	<meta property="og:description" content="Why stop with single loan product when you can empower your customers with entire range of loan products from wide range of lenders."/>
	<link rel="shortcut icon" href="images/favicon-1.png">
	<link href="css/index.css?ver=1" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" crossorigin="anonymous" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
	<!--font-awesome-->
	<!--font-awesome-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
	<style>
		.stepstoFollow:before {
		    height: 90%!important;	
			}
	</style>
</head>

<body class="">
	<section class="bgBlueright" id="top">
		<?php include "includes/navbar-light.php" ?>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 my-5 m-auto">
					<!--<p class="mt-2 mb-4 breadcrumbs">Our Services -> Startups</p>-->
					<h1>Next Gen Intelligent DSA Platform</h1>
					<p>While Experts predict that DSAs are getting disrupted by Fintechs, we digitize DSAs.</p>
					<a class="btn one" href="#Contact-Form" style="margin-top: 20px">Request Demo</a>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center align-items-center my-5">
					<img src="images/bannerimg7.png" width="90%" alt="Loanwiser For Startups">
				</div>
			</div>
		</div>
	</section>
	<section class="sectionThree py-5" style="width: 100%" id="sectionThree">
		<div class="col-12 text-center">
			<h1 class="mb-2 text-white">Platform Features & Benefits</h1>
			<!--<p class="mb-2 text-white">We love working with DSAs</p>-->
		</div>
		<div class="container">
			<div class="row mt-3">
				<div class="col-lg-4 col-md-4 col-sm-6 col-6 my-4">
					<div class="customcard text-center">
						<div class="icon">
							<img src="images/icon37.png" width="70px">
						</div>
						<h2>Onboard & Manage Channel Partners Digitally</h2>
						<p class="p1">We understand that Channel partners is key to loan distribution business. We have not let any stone unturned to help you nurture that relationship.</p>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-6 my-4">
					<div class="customcard text-center">
						<div class="icon">
							<img src="images/icon38.png" width="70px">
						</div>
						<h2>Digital Ways to Generate Leads @Zero Cost</h2>
						<p class="p1">Lead sourcing module empower your Sub DSAs and your Employees to promote business via assisted commerce, social commerce & O2O commerce models by leveraging whatsapp</p>
					    
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-6 my-4">
					<div class="customcard text-center">
						<div class="icon">
							<img src="images/icon39.png" width="70px">
						</div>
						<h2>Leads Categorized for Easy Management</h2>
						<p class="p1">Dashboard for Partners to manage and track their Leads. Leads with complete document set are sent to your processing team.</p>
					    
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-6 my-4">
					<div class="customcard text-center">
						<div class="icon">
							<img src="images/icon40.png" width="70px">
						</div>
						<h2>Cross Verify Files for Completeness</h2>
						<p class="p1">Processing team is enabled to cross verify profile  and documents.Login files Right First Time. </p>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-6 my-4" style="margin: 0px auto">
					<div class="customcard text-center">
						<div class="icon">
							<img src="images/icon49.png" width="70px">
						</div>
						<h2>No More Guess Work While Selecting Lenders</h2>
						<p class="p1">System recommends the Lenders that would accept the customer profile and documents. We help you manage Banks credit rules.</p>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-6 my-4" style="margin: 0px auto">
					<div class="customcard text-center">
						<div class="icon">
							<img src="images/icon41.png" width="70px">
						</div>
						<h2>Manage Conversion Funnel & Billing With Ease.</h2>
						<p class="p1">MIS and work queue capabilities help sales operations to be on top of the pipeline cases while giving overall picture to management on a click.</p>
						
					</div>
				</div>
				<!--<div class="col-12 text-center mt-5 mb-4">-->
				<!--	<button class="btn two"><span>Enroll With Us Today</span>-->
				<!--	</button>-->
				<!--</div>-->
			</div>
		</div>
		<div class="wave">
			<img src="images/wave2.png" class="waveimg img-fluid" style="height: max-content;">
		</div>
	</section>
	<section class="sectionFour py-5 bgBlueright" id="sectionFour" style="width: 100%">
		<div class="col-12 text-center">
			<h1 class="mb-2">How it Works</h1>
			<p class="mb-2">A infographic flowchart explaining our overall process</p>
			<img src="images/image19.png" class="img-fluid">
		</div>
		<div class="container"></div>
	</section>
	<section class="sectionTen py-5" id="sectionTen">
		<div class="container">
			<div class="col-12 text-center">
			    <img src="images/architecture.gif" class="img-fluid">
	    	</div>
	    </div>
	</section>
	<section class="sectionFive bgBluetop py-5" id="sectionFive">
		<div class="container">
			<div class="col-12 text-center">
				<h1 class="mb-2">Why DSA Stack ?</h1>
				<p class="mb-2">Features that resonates with your business requirements</p>
			</div>
			<div class="row">
				<div class="col-md-6 p-0" id="customBorder">
					<div class="col-12 my-5">
						<div class="d-flex ml-0" style="height: 100%">
							<div>
								<img src="images/icon43.png" width="48px">
							</div>
							<div class="ml-3">
								<h1 class="mb-1">Satisfied Partners. Consistent Business.</h1>
							</div>
						</div>
					</div>
					<div class="col-12 my-5">
						<div class="d-flex ml-0" style="height: 100%">
							<div>
								<img src="images/icon44.png" width="48px">
							</div>
							<div class="ml-3">
								<h1 class="mb-1">More ways to Promote. More Leads.</h1>
							</div>
						</div>
					</div>
					<div class="col-12 my-5">
						<div class="d-flex ml-0" style="height: 100%">
							<div>
								<img src="images/icon48.png" width="48px">
							</div>
							<div class="ml-3">
								<h1 class="mb-1">Clear Accountability between Partners and Teams.</h1>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 p-0">
					<div class="col-12 mt-5">
						<div class="d-flex ml-0" style="height: 100%">
							<div>
								<img src="images/icon46.png" width="48px">
							</div>
							<div class="ml-3">
								<h1 class="mb-1">Build trust with Lenders.</h1>
							</div>
						</div>
					</div>
					<div class="col-12 my-5">
						<div class="d-flex ml-0" style="height: 100%">
							<div>
								<img src="images/icon47.png" width="48px">
							</div>
							<div class="ml-3">
								<h1 class="mb-1">Acheive Higher conversion rate.</h1>
							</div>
						</div>
					</div>
					<div class="col-12 my-5">
						<div class="d-flex ml-0" style="height: 100%">
							<div>
								<img src="images/icon45.png" width="48px">
							</div>
							<div class="ml-3">
								<h1 class="mb-1">Peace of Mind in Operations and Finance.</h1>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="sectionSix bgBluegradient py-5" id="sectionSix">
		<div class="container">
			<div class="pricing1">
                  <div class="container">
                    <div class="row justify-content-center">
                      <div class="col-md-8 text-center">
                        <h1 class="text-white mb-1">Pricing</h1>
                        <p class=" text-white">We offer 100% satisafaction and Money back Guarantee</p>
          <!--              <div class="switcher-box mt-4 d-flex align-items-center justify-content-center">-->
          <!--                <span class="font-14 text-white font-weight-medium">MONTHLY</span>-->
          <!--                <div class="onoffswitch position-relative mx-2">-->
          <!--                  <input type="checkbox" name="onoffswitch1" class="onoffswitch-checkbox d-none" id="myonoffswitch1">-->
          <!--                  <label class="onoffswitch-label d-block overflow-hidden" for="myonoffswitch1">-->
    						<!--	<span class="onoffswitch-inner d-block"></span>-->
    						<!--	<span class="onoffswitch-switch d-block bg-white position-absolute"></span>-->
    						<!--</label>-->
          <!--                </div>-->
          <!--                <span class="font-14 text-white font-weight-medium">YEARLY</span>-->
          <!--              </div>-->
                      </div>
                    </div>
                    <!-- Row  -->
                    <div class="row mt-4">
                      <!-- Column -->
                      <div class="col-lg-4 col-md-6">
                        <div class="card text-center card-shadow on-hover border-0 mb-4">
                          <div class="card-body font-14">
                            <h5 class="mt-3 mb-1 font-weight-medium">BASIC</h5>
                            <h6 class="subtitle font-weight-normal">For Team of 10 Members</h6>
                            <span>Onetime Signup fee after 14 day Free Trial</span>
                            <div class="pricing mb-3">
                              <sup>₹</sup>
                              <span class="monthly display-5">5,000</span><br>
                              <span>Monthly fee: 5% of your Topline Earnings from Bank Payouts</span>
                            </div>
                            <ul class="list-inline">
                              <span class="font-weight-medium" style="color: #000;">FEATURES</span>
                              <li class="d-block py-2">Bank onboarding</li>
                              <li class="d-block py-2">Employee lead capture Module</li>
                              <li class="d-block py-2">Lead Processing Module</li>
                              <li class="d-block py-2">End to end Lead Tracking</li>
                              <li class="d-block py-2">MIS</li>
                            </ul>
                            <!--<div class="bottom-btn">-->
                            <!--  <a class="btn one btn-block" href="#f1"><span>Choose Plan</span></a>-->
                            <!--</div>-->
                          </div>
                        </div>
                      </div>
                      <!-- Column -->
                      <div class="col-lg-4 col-md-6">
                        <div class="card text-center card-shadow on-hover border-0 mb-4">
                          <div class="card-body font-14">
                            <span class="badge badge-inverse p-2 position-absolute price-badge font-weight-normal">Popular</span>
                            <h5 class="mt-3 mb-1 font-weight-medium">PRO</h5>
                            <h6 class="subtitle font-weight-normal">For Team of 200 Members</h6>
                            <span>Onetime Signup fee after 14 day Free Trial</span>
                            <div class="pricing mb-3">
                              <sup>₹</sup>
                              <span class="monthly display-5">25,000</span><br>
                              <span>Monthly fee: 5% of your Topline Earnings from Bank Payouts</span>
                            </div>
                            <ul class="list-inline">
                              <span class="font-weight-medium" style="color: #000;">FEATURES</span>
                              <li class="d-block py-2">Everything in BASIC plan plus</li>
                              <li class="d-block py-2">Channel Partner Module</li>
                              <li class="d-block py-2">Customer facing Module</li>
                              <li class="d-block py-2">Team Management</li>
                            </ul>
                            <!--<div class="bottom-btn">-->
                            <!--  <a class="btn one btn-block" href="#f1"><span>Choose Plan</span></a>-->
                            <!--</div>-->
                          </div>
                        </div>
                      </div>
                      <!-- Column -->
                      <div class="col-lg-4 col-md-6">
                        <div class="card text-center card-shadow on-hover border-0 mb-4">
                          <div class="card-body font-14">
                            <h5 class="mt-3 mb-1 font-weight-medium">ENTERPRISE</h5>
                            <h6 class="subtitle font-weight-normal">For Team of 200+ Members</h6>
                            <span>Onetime Signup fee after 14 day Free Trial</span>
                            <div class="pricing mb-3">
                              <sup>₹</sup>
                              <span class="monthly display-5">50,000</span><br>
                              <span>Monthly fee: 5% of your Topline Earnings from Bank Payouts</span>
                            </div>
                            <ul class="list-inline">
                              <span class="font-weight-medium" style="color: #000;">FEATURES</span>
                              <li class="d-block py-2">Everything in PRO Plan plus</li>
                              <li class="d-block py-2">Lender Portal Lead submission Automation(coming soon)</li>
                              <li class="d-block py-2">Lender Portal status fetch Automation(coming soon)</li>
                              <li class="d-block py-2">ERP(coming soon)</li>
                              <li class="d-block py-2">Dedicated Support Personnel</li>
                            </ul>
                            <!--<div class="bottom-btn">-->
                            <!--  <a class="btn one btn-block" href="#f1"><span>Choose Plan</span></a>-->
                            <!--</div>-->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
		</div>
	</section>
	<section class="sectionEight py-5" id="sectionEight" style="width: 100%">
		<div class="container">
			<div class="col-12 text-center">
				<h1 class="mb-2">Yes, I am Interested. Where to Start?</h1>
				<p class="mb-2">Now, you are asking the right question! ;)</p>
			</div>
			<div class="col-6 m-auto">
			<div class="stepstoFollow mt-5">
				<div class="my-4">
					<div class="numerAlign">
						<img src="images/number1.png" width="35px">
					</div>
					<div class="pl-5 pt-2">
						<h3 class="text-blue">Enquire by filling the form below</h3>
					</div>
				</div>
				<div class="my-4">
					<div class="numerAlign">
						<img src="images/number2.png" width="35px">
					</div>
					<div class="pl-5 pt-2">
						<h3 class="text-blue">Our Product Manager will do a demo</h3>
					</div>
				</div>
				<div class="my-4">
					<div class="numerAlign">
						<img src="images/number3.png" width="35px">
					</div>
					<div class="pl-5 pt-2">
						<h3 class="text-blue">Get trial access for a week</h3>
					</div>
				</div>
				<div class="mt-4">
					<div class="numerAlign">
						<img src="images/number4.png" width="35px">
					</div>
					<div class="pl-5 pt-2">
						<h3 class="text-blue">Decide and signup</h3>
					</div>
				</div>
				<div class="mt-4">
					<div class="numerAlign">
						<img src="images/number5.png" width="35px">
					</div>
					<div class="pl-5 pt-2">
						<h3 class="text-blue">Get your business future ready</h3>
					</div>
				</div>
			</div>
			<h3 class="mt-5"><img src="images/arrow.png" width="23%"><span class="ml-2 text-blue">Yeah, It's that simple!</span></h3>
			</div>
		</div>
	</section>
	<section class="sectionNine py-5" id="Contact-Form">
		<div class="container">
			<div class="col-12 text-center">
				<h1 class="mb-2">Request For A Free Demo</h1>
				<p class="mb-2">Lets us know a little about yourself and your preferred time for the demo</p>
			</div>
			<form id="fi-demo-form" data-parsley-validate="">
			    <input type="hidden" name="source" value="st">
			    <input type="hidden" name="link" value="https://loanwiser.in/Startups.php">
			<div class="col-lg-8 col-sm-12 m-auto">
				<div class="row">
					<div class="col-md-6 col-sm-12 form-group my-3">
						<label>Your Name *</label>
						<input class="form-control" type="text" id="name" name="name" placeholder="John Sample" required>
					</div>
					<div class="col-md-6 col-sm-12 form-group my-3">
						<label>Business/Company Name *</label>
						<input class="form-control" type="text" id="bussiness" name="bussiness" placeholder="ABC Corporation" required>
					</div>
					<div class="col-md-6 col-sm-12 form-group my-3">
						<label>Email *</label>
						<input class="form-control" type="text" data-parsley-type="email" id="email" name="email" placeholder="John@sample.com" required>
					</div>
					<div class="col-md-6 col-sm-12 form-group my-3">
						<label>Mobile Number *</label>
						<input class="form-control" type="text" id="mobilenum" name="mobilenum" placeholder="9448856666" required>
					</div>
					<div class="col-md-6 col-sm-12 form-group my-3">
						<label>Company Size *</label>
						<select class="form-control" name="companysize" id="companysize" required>
							<option value="" selected disabled>--Select--</option>
							<option value="1">Less than 50 Franchisee/End-Users</option>
							<option value="2">50 to 100</option>
							<option value="3">100 to 1000</option>
							<option value="4">1000 to 10,000</option>
							<option value="5">Greater than 10,000</option>
						</select>
					</div>
					<div class="col-md-6 col-sm-12 form-group my-3">
						<label>Preferred Date & Time for Demo *</label>
						<input class="form-control" type="text" name="date_time" placeholder="Select Date & Time.." id="flatpickrBasicDate" data-input required>
					</div>
					<div class="col-12 form-group my-3">
						<label>Message (if any) *</label>
						<textarea class="form-control" minlength="25" name="message" required></textarea>
					</div>
					<div class="col-12 text-center my-4">
						<button type="button" class="btn one fi-submit">Submit Now</button>
					</div>
				</div>
			</div>
			</form>
			<div class="col-12 text-center success-msg d-none">
				<p class="text-blue">
					<img src="images/green tick.png"><span class="ml-2">Your Meeting Scheduled Successfully, DSA Stack team will get in touch within 4 working Hours.</span>
				</p>
			</div>
			<div class="col-12 text-center error-msg d-none">
				<p class="text-blue">
					<img src="images/error.png"><span class="ml-2">Oops!, Please try again later..</span>
				</p>
			</div>
		</div>
	</section>
	<section class="sectionSeven py-5" id="sectionSeven">
		<div class="container pb-5">
			<div class="col-12 text-center">
				<h1 class="mb-2">Testimonials</h1>
				<p class="mb-2">What Our Partners Got To Say About Us</p>
			</div>
			<div id="carouselExampleIndicatorsTwo" class="carousel slide" data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators">
					<li data-target="#carouselExampleIndicatorsTwo" data-slide-to="0" class="active"></li>
					<!--<li data-target="#carouselExampleIndicatorsTwo" data-slide-to="1" class=""></li>-->
					<!--<li data-target="#carouselExampleIndicatorsTwo" data-slide-to="2" class=""></li>-->
				</ol>
				<!-- Wrapper for slides -->
				<div class="carousel-inner">
					<div class="carousel-item active">
						<div class="col-md-6 col-sm-12 m-auto">
							<div class="customcard my-4 row">
								<div class="col-md-2 col-sm-12 mb-2">
									<img src="images/profile.png" width="60px">
								</div>
								<div class="col-md-10 col-sm-12">
									<p class="p1 text-blue mb-0 font-weight-bold">Danushkodi</p>
									<p class="p1 text-blue mb-2">Freelance Loan Consultant</p>
									<p class="text-blue font-italic">I have been able to make more than ₹5000 per month on an average using DSA Stack Mobile App with very little effort, and it greatly helps me in achieving my financial goals.</p>
								</div>
							</div>
						</div>
					</div>
					<!--<div class="carousel-item">-->
					<!--	<div class="col-md-6 col-sm-12 m-auto">-->
					<!--		<div class="customcard my-4 row">-->
					<!--			<div class="col-md-2 col-sm-12 mb-2">-->
					<!--				<img src="images/profile.png" width="60px">-->
					<!--			</div>-->
					<!--			<div class="col-md-10 col-sm-12">-->
					<!--				<p class="p1 text-blue mb-0 font-weight-bold">Danushkodi</p>-->
					<!--				<p class="p1 text-blue mb-2">Freelance Loan Consultant</p>-->
					<!--				<p class="text-blue font-italic">I have been able to make more than ₹5000 per month on an average using DSA Stack Mobile App with very little effort, and it greatly helps me in achieving my financial goals.</p>-->
					<!--			</div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</div>-->
					<!--<div class="carousel-item">-->
					<!--	<div class="col-md-6 col-sm-12 m-auto">-->
					<!--		<div class="customcard my-4 row">-->
					<!--			<div class="col-md-2 col-sm-12 mb-2">-->
					<!--				<img src="images/profile.png" width="60px">-->
					<!--			</div>-->
					<!--			<div class="col-md-10 col-sm-12">-->
					<!--				<p class="p1 text-blue mb-0 font-weight-bold">Danushkodi</p>-->
					<!--				<p class="p1 text-blue mb-2">Freelance Loan Consultant</p>-->
					<!--				<p class="text-blue font-italic">I have been able to make more than ₹5000 per month on an average using DSA Stack Mobile App with very little effort, and it greatly helps me in achieving my financial goals.</p>-->
					<!--			</div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</div>-->
				</div>
			</div>
		</div>
	</section>
	<?php include "includes/footer.php" ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.min.js" crossorigin="anonymous"></script>
	<script>
		$("#flatpickrBasicDate").flatpickr({
	        enableTime: true,
	        dateFormat: "d-m-Y H:i K",
	        minDate: "today",
	        maxDate: new Date().fp_incr(30),
	        disableMobile: "true"
	       // defaultDate: ["today"]
	        });
	        $parsley = $('#fi-demo-form').parsley({
 	successClass: 'has-success',
 	errorClass: 'has-error',
 	excluded: "input[type=button], input[type=submit], input[type=reset], input[type=hidden], [disabled],  :hidden",
 	classHandler: function (el) {
 		//   el.$element.closest(".form-group").addClass('parsl-class');
 		return el.$element.closest(".form-group");
 	},
 	errorTemplate: "<span></span>",
 	errorsContainer: function (el) {
 		return el.$element.closest('.form-group');
 	}
 });
	   $(document).on('click','.fi-submit',function(){
	       if($parsley.validate())
	       {
	           var fid = $("#fi-demo-form")[0];
 		        var formData = new FormData(fid);
 		        $('.fi-submit').addClass("disabled");
 		        $.ajax({
 			type: "POST",
 			url: "includes/sendmail_requestDemo.php",
 			cache: false,
 			data: formData,
 			contentType: false,
 			processData: false,
 			success: function (result) {
 			    if(result == 0)
            {
                $(".success-msg").removeClass('d-none');
                $(".error-msg").addClass('d-none');
                $("#fi-demo-form")[0].reset();
                $('.fi-submit').removeClass("disabled");
                // $('.output-mail').html(`
                // <div class="alert alert-success">Thanks for your message, We will get back to you shortly</div>
                // `);
            }
            else
            {
                $(".success-msg").addClass('d-none');
                $(".error-msg").removeClass('d-none');
                $('.fi-submit').removeClass("disabled");
                // $('.output-mail').html(`
                // <div class="alert alert-danger">Oops!, Please try again later..</div>
                // `);
            }
            setTimeout(function(){ $(".success-msg").addClass('d-none');$(".error-msg").addClass('d-none'); }, 10000);
 			    
 			}
 		});
	       }
	   }) ;  
	   
	   $(".pricing1 .onoffswitch-label").click(function() {
        	$(".pricing1 .monthly, .pricing1 .yearly").toggle();
        });
	</script>
</body>

</html>